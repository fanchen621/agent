#!/usr/bin/env python3
"""
DragonFlow Schema Migration Tool
用法:
  python tools/migrate.py          # 探活端点 + 执行 auto_migrate
  python tools/migrate.py --dry   # 只显示缺失列，不执行
  python tools/migrate.py --probe  # 只探活数据源端点

示例:
  cd /root/.openclaw/workspace/quant/DragonFlow
  python tools/migrate.py
"""
import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(ROOT))

# ─── 端点探活 ────────────────────────────────────────────
def probe_endpoints():
    from feeds.proxy_engine import probe_validate_endpoints
    result = probe_validate_endpoints()
    print("\n╔══════════════════════════════════════╗")
    print("║       数据源端点探活报告              ║")
    print("╠══════════════════════════════════════╣")
    active = result["active"]
    print(f"║ 当前活跃端点: {active['name']:<20}║")
    print(f"║ 状态: {'✅ 可用' if active['ok'] else '❌ 失败':<24}║")
    print(f"║ 连续失败: {active['failures']} 次{' '*21}║")
    print("╠══════════════════════════════════════╣")
    print("║ 所有端点探活结果:                     ║")
    for r in result["results"]:
        icon = "✅" if r["ok"] else "❌"
        print(f"║   {icon} {r['name']:<30}║")
    print("╚══════════════════════════════════════╝")
    return result


# ─── Schema 迁移 ─────────────────────────────────────────
def run_migrate(dry: bool = False):
    from models import _auto_migrate, get_engine
    from sqlalchemy import inspect, text

    engine = get_engine()
    inspector = inspect(engine)

    from models import Base
    print("\n╔══════════════════════════════════════╗")
    print("║       Schema 迁移报告 (dry={})         ║".format(dry))
    print("╠══════════════════════════════════════╣")

    for table in sorted(Base.metadata.tables):
        if table.startswith("sqlite_"):
            continue
        try:
            actual = {c["name"] for c in inspector.get_columns(table)}
        except Exception:
            continue

        model = Base.metadata.tables[table]
        model_cols = {c.name for c in model.columns}
        missing = model_cols - actual

        if not missing:
            print(f"║ ✅ {table:<40}║")
        else:
            print(f"║ ⚠️  {table:<40}║")
            for col in sorted(missing):
                col_obj = model.columns[col]
                sqltype = str(col_obj.type)
                print(f"║    → 缺失: {col:<30} ({sqltype})║")
                if not dry:
                    # 执行 ALTER
                    if "INTEGER" in sqltype.upper():
                        sqldef = f"ADD COLUMN {col} INTEGER"
                    elif "FLOAT" in sqltype.upper() or "REAL" in sqltype.upper():
                        sqldef = f"ADD COLUMN {col} REAL"
                    elif "BOOLEAN" in sqltype.upper():
                        sqldef = f"ADD COLUMN {col} INTEGER DEFAULT 0"
                    elif "DATETIME" in sqltype.upper() or "DATE" in sqltype.upper():
                        sqldef = f"ADD COLUMN {col} TIMESTAMP"
                    else:
                        sqldef = f"ADD COLUMN {col} TEXT"
                    try:
                        with engine.connect() as conn:
                            conn.execute(text(f"ALTER TABLE {table} {sqldef}"))
                            conn.commit()
                        print(f"║       ✅ 已添加 {col}                 ║")
                    except Exception as e:
                        if "duplicate" in str(e).lower() or "already exists" in str(e).lower():
                            print(f"║       ⏭ 已存在，跳过                  ║")
                        else:
                            print(f"║       ❌ 失败: {str(e)[:28]} ║")

    print("╚══════════════════════════════════════╝")
    if dry:
        print("⚠️  Dry run 模式，未执行任何 ALTER")
    else:
        print("✅ 迁移完成")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DragonFlow 迁移工具")
    parser.add_argument("--dry", action="store_true", help="只显示缺失列，不执行ALTER")
    parser.add_argument("--probe", action="store_true", help="只探活数据源端点")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(message)s",
        datefmt="%H:%M:%S"
    )

    if args.probe:
        probe_endpoints()
    else:
        if not args.dry:
            print("=== 1. 探活数据源端点 ===")
        result = probe_endpoints()
        print("\n=== 2. Schema 迁移 ===")
        run_migrate(dry=args.dry)
