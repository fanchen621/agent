#!/usr/bin/env python3
"""DragonFlow Autopilot 服务入口"""
import sys, os
from pathlib import Path

ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(ROOT))

# SOCKS5_PROXY 由 proxy_engine.py 的 _get_static_socks5() 管理
# 如需启用SOCKS5，请在系统环境变量中设置: export SOCKS5_PROXY=socks5://user:pass@host:port
# 当前值由 proxy_engine.py 的 route_domain() 读取并处理不可用时自动降级

from engine.autopilot import get_runtime

if __name__ == "__main__":
    import time
    runtime = get_runtime(ROOT)
    runtime.start()
    print(f"[Autopilot] started at {ROOT}, PID={os.getpid()}")
    # 保持主线程存活
    while True:
        time.sleep(3600)
