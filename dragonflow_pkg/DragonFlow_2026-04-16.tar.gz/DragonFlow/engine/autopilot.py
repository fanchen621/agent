from __future__ import annotations

import datetime
import json
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional

from loguru import logger

from engine.evolution_mode import EvolutionModeRuntime
from engine.realtime_watch import RealtimeWatchEngine
from engine.simulator import TradeSimulator
from feeds.market_snapshot import build_market_env_data
from feeds.resilient import resilient_fetch_indices, resilient_fetch_stocks
from feeds.sentiment import get_market_sentiment, save_sentiment_snapshot
from models import Position, get_session
from openclaw_adapter import ensure_router_ready, is_trading_day, is_trading_hours, push_message, update_state
from selfheal.diagnostics import record_data_error, record_data_success, record_tick_latency
from selfheal.doctor import auto_heal
from strategy.emotion_cycle import get_emotion_cycle
from strategy.trade_rules import check_add_signal, check_buy_signal, check_sell_signal
from strategy.signal import TradePlan
from strategy.zone_classifier import classify_zone


class AutoPilotRuntime:
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.runtime_dir = base_dir / "data" / "runtime"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)

        self._stop_evt = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._broadcast: Optional[Callable[[str], None]] = None
        self._simulator = TradeSimulator()
        self._evolution_mode = EvolutionModeRuntime()
        self._watch_engine = RealtimeWatchEngine()

        self.current_zone = "unknown"
        self.current_emotion = "unknown"
        self.current_sentiment_modifier = 1.0
        self.tick_count = 0

        self.last_zone_check = 0.0
        self.last_buy_check = 0.0
        self.last_sentiment_check = 0.0
        self.last_live_watch_refresh = 0.0
        self.last_heal_check = 0.0

        self.executed_signals: set = set()
        self._trade_plans: List = []
        self._live_plans: List = []
        self._live_candidates: List[Dict] = []
        self._evolution_candidates: List[Dict] = []
        self._market_sentiment: Dict = {}

    def set_broadcast(self, fn: Callable[[str], None]):
        self._broadcast = fn

    def set_trade_plans(self, plans: List):
        self._trade_plans = list(plans)
        logger.info(f"[autopilot] loaded {len(plans)} scheduled plans")

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        if self.is_running:
            return
        try:
            ensure_router_ready()
        except Exception as exc:
            logger.debug(f"[autopilot] router probe failed: {exc}")
        try:
            maintenance = self._evolution_mode.run_startup_maintenance()
            if maintenance.get("details"):
                self._emit("evolution_maintenance", maintenance)
        except Exception as exc:
            logger.debug(f"[autopilot] evolution maintenance failed: {exc}")
        self._stop_evt.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="autopilot")
        self._thread.start()
        update_state(autopilot_running=True)
        logger.info("[autopilot] started")

    def stop(self):
        self._stop_evt.set()
        update_state(autopilot_running=False)
        logger.info("[autopilot] stopped")

    def _emit(self, event: str, payload: dict):
        if not self._broadcast:
            return
        try:
            self._broadcast(json.dumps({"event": event, "data": payload}, ensure_ascii=False, default=str))
        except Exception:
            pass

    def _loop(self):
        while not self._stop_evt.is_set():
            started = time.perf_counter()
            try:
                if is_trading_day() and is_trading_hours():
                    self._tick_trading()
                else:
                    self._tick_idle()
            except Exception as exc:
                logger.error(f"[autopilot] tick failed: {exc}")

            interval = 3.0 if (is_trading_day() and is_trading_hours()) else 60.0
            sleep_sec = max(0.1, interval - (time.perf_counter() - started))
            self._stop_evt.wait(timeout=sleep_sec)

    def _tick_trading(self):
        self.tick_count += 1
        now = time.time()
        tick_started = time.perf_counter()

        try:
            indices = resilient_fetch_indices()
            record_data_success("index")
        except Exception as exc:
            record_data_error("index", str(exc), "fetch_fail")
            return

        session = get_session()
        try:
            positions = session.query(Position).all()
        finally:
            session.close()

        rt_map = {}
        if positions:
            try:
                rt_map = resilient_fetch_stocks([pos.code for pos in positions])
                record_data_success("stock")
            except Exception as exc:
                record_data_error("stock", str(exc), "fetch_fail")
            self._simulator.update_positions_price(rt_map)

        if now - self.last_zone_check > 30:
            self._update_zone_emotion()
            self.last_zone_check = now

        if now - self.last_sentiment_check > 300:
            self._update_sentiment()
            self.last_sentiment_check = now

        if now - self.last_live_watch_refresh > 55:
            self._refresh_live_watch(force=True)
            self.last_live_watch_refresh = now

        self._check_sells(rt_map)

        if now - self.last_buy_check > 60:
            self._check_adds(rt_map)
            self._check_buys(rt_map)
            self.last_buy_check = now

        self._evolution_mode.tick(
            zone=self.current_zone,
            emotion=self.current_emotion,
            live_candidates=self._evolution_candidates or self._live_candidates,
            quote_map=rt_map,
            emit=self._emit,
        )

        if now - self.last_heal_check > 60:
            try:
                auto_heal()
            except Exception:
                pass
            self.last_heal_check = now

        elapsed_ms = (time.perf_counter() - tick_started) * 1000
        record_tick_latency(elapsed_ms)
        self._emit("market_tick", {
            "ts": datetime.datetime.now().strftime("%H:%M:%S"),
            "indices": indices,
            "zone": self.current_zone,
            "emotion": self.current_emotion,
            "sentiment": self._market_sentiment,
            "positions": self._get_positions_snapshot(),
            "live_candidates": self._live_candidates[:5],
            "live_candidate_count": len(self._live_candidates),
            "tick": self.tick_count,
            "tick_ms": round(elapsed_ms, 1),
        })

        if datetime.datetime.now().minute == 0 and datetime.datetime.now().second < 5:
            self.executed_signals.clear()

    def _tick_idle(self):
        now = time.time()
        if now - self.last_sentiment_check > 1800:
            self._update_sentiment()
            self.last_sentiment_check = now
        if now - self.last_heal_check > 21600:
            try:
                auto_heal()
            except Exception:
                pass
            self.last_heal_check = now

    def _update_zone_emotion(self):
        try:
            env_data = build_market_env_data()
            zone, notes = classify_zone(env_data)
            emotion = get_emotion_cycle(env_data.get("limit_up_count", 0))
            old_zone = self.current_zone

            self.current_zone = zone
            self.current_emotion = emotion
            update_state(current_zone=zone, current_emotion=emotion)

            if old_zone not in ("unknown", zone):
                message = f"zone shift {old_zone} -> {zone}"
                if notes:
                    message += f"\n{notes[0]}"
                push_message(message, title="DragonFlow Zone", urgent=(zone == "risk"))
        except Exception as exc:
            logger.debug(f"[autopilot] zone update failed: {exc}")

    def _update_sentiment(self):
        try:
            self._market_sentiment = get_market_sentiment()
            self.current_sentiment_modifier = float(self._market_sentiment.get("modifier", 1.0) or 1.0)
            save_sentiment_snapshot()
            self._emit("sentiment_update", self._market_sentiment)
        except Exception as exc:
            logger.debug(f"[autopilot] sentiment update failed: {exc}")

    def _refresh_live_watch(self, force: bool = False):
        snapshot = self._watch_engine.maybe_refresh(
            zone=self.current_zone,
            emotion=self.current_emotion,
            sentiment_modifier=self.current_sentiment_modifier,
            force=force,
        )
        self._live_plans = list(snapshot.get("plans", []))
        self._live_candidates = list(snapshot.get("candidates", []))
        self._evolution_candidates = list(snapshot.get("evolution_candidates", []))
        update_state(live_candidate_count=len(self._live_candidates))
        if self._live_candidates:
            self._emit("realtime_candidates", {
                "count": len(self._live_candidates),
                "candidates": self._live_candidates[:8],
            })

    def _get_active_trade_plans(self) -> List:
        def to_plan(p):
            if isinstance(p, dict):
                return TradePlan(
                    code=p.get("code",""), name=p.get("name",""), sector=p.get("sector",""),
                    zone=p.get("zone","neutral"), emotion=p.get("emotion","neutral"),
                    target_position_pct=float(p.get("target_position_pct",10)),
                    entry_price=float(p.get("entry_price",0)), add_price=float(p.get("add_price",0)),
                    stop_price=float(p.get("stop_price",0)), tp1_price=float(p.get("tp1_price",0)),
                    tp2_price=float(p.get("tp2_price",0)), hold_days_max=int(p.get("hold_days_max",3)),
                    pick_type=p.get("pick_type",""), score=float(p.get("score",0)),
                    reasons=p.get("reasons",[]), runtime_rules=p.get("runtime_rules",{}),
                    score_breakdown=p.get("score_breakdown",{}), source=p.get("source",""),
                )
            return p

        merged: Dict[str, object] = {}
        for plan in self._trade_plans:
            merged[plan.code] = plan
        for plan in self._live_plans:
            plan = to_plan(plan)
            prev = merged.get(plan.code)
            if prev is None or float(plan.score or 0) >= float(prev.score or 0):
                merged[plan.code] = plan
        return sorted(merged.values(), key=lambda item: float(item.score or 0), reverse=True)

    def _find_plan(self, code: str):
        for plan in self._get_active_trade_plans():
            if plan.code == code:
                return plan
        return None

    def _check_sells(self, rt_map: Dict[str, Dict]):
        session = get_session()
        try:
            positions = session.query(Position).all()
        finally:
            session.close()

        force_close = datetime.datetime.now().hour == 14 and datetime.datetime.now().minute >= 50
        for pos in positions:
            realtime = rt_map.get(pos.code, {})
            if not realtime:
                continue

            plan = self._find_plan(pos.code)
            pos_dict = {
                "code": pos.code,
                "name": pos.name,
                "buy_price": pos.buy_price,
                "shares": pos.shares,
                "buy_date": pos.buy_date,
                "hold_days": pos.hold_days or 0,
                "stop_loss": pos.stop_loss,
                "take_profit_1": pos.take_profit_1,
                "take_profit_2": pos.take_profit_2,
                "add_price": pos.add_price,
                "pick_type": (plan.pick_type if plan else pos.pick_type) or "",
                "score": float(plan.score if plan else 0.0),
                "runtime_rules": dict(plan.runtime_rules) if plan and plan.runtime_rules else {},
            }
            signal = check_sell_signal(
                pos_dict,
                realtime,
                self.current_zone,
                self.current_emotion,
                force_close=force_close,
            )
            if signal is None:
                continue

            sig_key = f"SELL:{signal.code}:{signal.signal_type}:{datetime.datetime.now():%H%M}"
            if sig_key in self.executed_signals:
                continue

            result = self._simulator.execute_signal(signal)
            if result:
                self.executed_signals.add(sig_key)
                self._notify_trade(result)
                self._emit("trade_signal", result)

    def _check_adds(self, rt_map: Dict[str, Dict]):
        if self.current_zone == "risk":
            return

        session = get_session()
        try:
            positions = session.query(Position).all()
        finally:
            session.close()

        if not positions:
            return

        missing_codes = [pos.code for pos in positions if pos.code not in rt_map]
        if missing_codes:
            rt_map.update(resilient_fetch_stocks(missing_codes))

        for pos in positions:
            realtime = rt_map.get(pos.code, {})
            if not realtime:
                continue

            plan = self._find_plan(pos.code)
            pos_dict = {
                "code": pos.code,
                "name": pos.name,
                "buy_price": pos.buy_price,
                "shares": pos.shares,
                "hold_days": pos.hold_days or 0,
                "stop_loss": pos.stop_loss,
                "take_profit_1": pos.take_profit_1,
                "take_profit_2": pos.take_profit_2,
                "add_price": pos.add_price,
                "pick_type": (plan.pick_type if plan else pos.pick_type) or "",
                "score": float(plan.score if plan else 0.0),
                "runtime_rules": dict(plan.runtime_rules) if plan and plan.runtime_rules else {},
            }
            signal = check_add_signal(pos_dict, realtime, self.current_zone, self.current_emotion)
            if signal is None:
                continue

            sig_key = f"ADD:{signal.code}:{datetime.datetime.now():%H%M}"
            if sig_key in self.executed_signals:
                continue

            result = self._simulator.execute_signal(signal)
            if result:
                self.executed_signals.add(sig_key)
                self._notify_trade(result)
                self._emit("trade_signal", result)

    def _check_buys(self, rt_map: Dict[str, Dict]):
        if self.current_zone == "risk":
            return

        active_plans = self._get_active_trade_plans()
        if not active_plans:
            return

        session = get_session()
        try:
            pos_count = session.query(Position).count()
            held_codes = {pos.code for pos in session.query(Position).all()}
        finally:
            session.close()

        plan_codes = [plan.code for plan in active_plans if plan.code not in held_codes]
        if not plan_codes:
            return

        quote_map = dict(rt_map)
        missing_codes = [code for code in plan_codes if code not in quote_map]
        if missing_codes:
            quote_map.update(resilient_fetch_stocks(missing_codes))

        for plan in active_plans:
            if plan.code in held_codes:
                continue
            realtime = quote_map.get(plan.code, {})
            if not realtime:
                continue

            signal = check_buy_signal(
                plan,
                realtime,
                self.current_zone,
                self.current_emotion,
                pos_count,
            )
            if signal is None:
                continue

            sig_key = f"BUY:{signal.code}:{datetime.datetime.now():%H%M}"
            if sig_key in self.executed_signals:
                continue

            result = self._simulator.execute_signal(signal)
            if result:
                self.executed_signals.add(sig_key)
                held_codes.add(signal.code)
                pos_count += 1
                self._notify_trade(result)
                self._emit("trade_signal", result)

    def _get_positions_snapshot(self) -> List[Dict]:
        session = get_session()
        try:
            return [{
                "code": pos.code,
                "name": pos.name,
                "buy_price": pos.buy_price,
                "current_price": pos.current_price,
                "shares": pos.shares,
                "pnl": pos.current_pnl,
                "pnl_pct": pos.current_pnl_pct,
                "hold_days": pos.hold_days,
                "strategy": pos.strategy,
                "stop_loss": pos.stop_loss,
                "tp1": pos.take_profit_1,
                "tp2": pos.take_profit_2,
            } for pos in session.query(Position).all()]
        finally:
            session.close()

    def _notify_trade(self, trade: Dict):
        action = trade.get("action", "")
        code = trade.get("code", "")
        name = trade.get("name", "")
        price = trade.get("price", 0.0)
        shares = trade.get("shares", 0)
        signal_type = trade.get("signal_type", "")

        if action == "BUY":
            message = (
                f"sim buy {code} {name}\n"
                f"- {price:.2f} x {shares}\n"
                f"- signal: {signal_type}"
            )
        else:
            pnl = float(trade.get("pnl", 0.0) or 0.0)
            pnl_pct = float(trade.get("pnl_pct", 0.0) or 0.0)
            message = (
                f"sim sell {code} {name}\n"
                f"- {price:.2f} x {shares}\n"
                f"- pnl: {pnl:+.0f} ({pnl_pct:+.2f}%)\n"
                f"- signal: {signal_type}"
            )
        push_message(message, title="DragonFlow Trade", urgent=(action == "BUY"))


_RUNTIME: Optional[AutoPilotRuntime] = None


def get_runtime(base_dir: Optional[Path] = None) -> AutoPilotRuntime:
    global _RUNTIME
    if _RUNTIME is None:
        if base_dir is None:
            base_dir = Path(__file__).parent.parent
        _RUNTIME = AutoPilotRuntime(base_dir)
    return _RUNTIME
