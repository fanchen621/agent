from __future__ import annotations

import datetime
from typing import Optional

from loguru import logger

from config import TRADE_RULES
from models import Position, TradeRecord, get_session
from strategy.signal import TradeSignal
from strategy.trade_rules import is_allowed_code


BUY_FEE_RATE = TRADE_RULES["buy_fee_rate"]
SELL_FEE_RATE = TRADE_RULES["sell_fee_rate"]


def _signal_is_add(signal: TradeSignal) -> bool:
    return signal.signal_type in ("ADD_POSITION", "加仓", "鍔犱粨")


class TradeSimulator:
    def execute_signal(self, signal: TradeSignal) -> Optional[dict]:
        if not is_allowed_code(signal.code):
            logger.warning(f"[sim] reject non-main-board code {signal.code}")
            return None
        if signal.direction == "BUY":
            return self._execute_buy(signal)
        return self._execute_sell(signal)

    def _execute_buy(self, signal: TradeSignal) -> Optional[dict]:
        session = get_session()
        try:
            pos = session.query(Position).filter_by(code=signal.code).first()
            if pos and not _signal_is_add(signal):
                logger.info(f"[sim] skip duplicate buy for {signal.code}")
                return None

            amount = round(signal.price * signal.shares, 2)
            fee = round(amount * BUY_FEE_RATE, 2)
            total = round(amount + fee, 2)

            if pos and _signal_is_add(signal):
                old_shares = int(pos.shares or 0)
                old_cost = float(pos.cost or 0.0)
                new_shares = old_shares + signal.shares
                new_cost = round(old_cost + total, 2)
                avg_price = round(new_cost / new_shares, 4) if new_shares > 0 else signal.price

                pos.shares = new_shares
                pos.cost = new_cost
                pos.buy_price = avg_price
                pos.current_price = signal.price
                pos.stop_loss = signal.stop_price or pos.stop_loss or round(
                    avg_price * (1 + float(signal.runtime_rules.get("stop_loss_pct", TRADE_RULES["stop_loss_pct"]))),
                    2,
                )
                pos.take_profit_1 = signal.tp1_price or round(
                    avg_price * (1 + float(signal.runtime_rules.get("take_profit_1_pct", TRADE_RULES["take_profit_1_pct"]))),
                    2,
                )
                pos.take_profit_2 = signal.tp2_price or round(
                    avg_price * (1 + float(signal.runtime_rules.get("take_profit_2_pct", TRADE_RULES["take_profit_2_pct"]))),
                    2,
                )
                pos.add_price = signal.add_price or round(
                    avg_price * (1 + float(signal.runtime_rules.get("add_trigger_pct", TRADE_RULES["add_trigger_pct"]))),
                    2,
                )
                pos.reason = signal.signal_reason
            else:
                pos = Position(
                    code=signal.code,
                    name=signal.name,
                    buy_date=datetime.date.today(),
                    buy_time=signal.timestamp,
                    buy_price=signal.price,
                    shares=signal.shares,
                    cost=total,
                    current_price=signal.price,
                    current_pnl=0.0,
                    current_pnl_pct=0.0,
                    stop_loss=signal.stop_price or round(
                        signal.price * (1 + float(signal.runtime_rules.get("stop_loss_pct", TRADE_RULES["stop_loss_pct"]))),
                        2,
                    ),
                    take_profit_1=signal.tp1_price or round(
                        signal.price * (1 + float(signal.runtime_rules.get("take_profit_1_pct", TRADE_RULES["take_profit_1_pct"]))),
                        2,
                    ),
                    take_profit_2=signal.tp2_price or round(
                        signal.price * (1 + float(signal.runtime_rules.get("take_profit_2_pct", TRADE_RULES["take_profit_2_pct"]))),
                        2,
                    ),
                    add_price=signal.add_price or round(
                        signal.price * (1 + float(signal.runtime_rules.get("add_trigger_pct", TRADE_RULES["add_trigger_pct"]))),
                        2,
                    ),
                    strategy=signal.signal_type,
                    pick_type=signal.pick_type,
                    reason=signal.signal_reason,
                    hold_days=0,
                )
                session.add(pos)

            session.add(TradeRecord(
                date=datetime.date.today(),
                code=signal.code,
                name=signal.name,
                direction="BUY",
                price=signal.price,
                shares=signal.shares,
                amount=total,
                timestamp=signal.timestamp,
                signal_type=signal.signal_type,
                signal_reason=signal.signal_reason,
                minute_price=signal.minute_price,
                volume_ratio=signal.volume_ratio,
                zone=signal.zone,
                emotion=signal.emotion,
                zt_count_at=signal.zt_count,
                strategy_ver=signal.strategy_ver,
            ))
            session.commit()

            return {
                "action": "BUY",
                "code": signal.code,
                "name": signal.name,
                "price": signal.price,
                "shares": signal.shares,
                "amount": amount,
                "fee": fee,
                "total": total,
                "signal_type": signal.signal_type,
                "timestamp": str(signal.timestamp),
            }
        except Exception as exc:
            session.rollback()
            logger.error(f"[sim] buy failed for {signal.code}: {exc}")
            return None
        finally:
            session.close()

    def _execute_sell(self, signal: TradeSignal) -> Optional[dict]:
        session = get_session()
        try:
            pos = session.query(Position).filter_by(code=signal.code).first()
            if not pos:
                logger.warning(f"[sim] sell without position {signal.code}")
                return None

            sell_shares = min(int(signal.shares or 0), int(pos.shares or 0))
            if sell_shares <= 0:
                return None

            gross_amount = round(signal.price * sell_shares, 2)
            fee = round(gross_amount * SELL_FEE_RATE, 2)
            sell_amount = round(gross_amount - fee, 2)

            cost_per_share = float(pos.cost or 0.0) / float(pos.shares or 1)
            cost_sold = round(cost_per_share * sell_shares, 2)
            pnl = round(sell_amount - cost_sold, 2)
            pnl_pct = round(pnl / cost_sold * 100, 2) if cost_sold > 0 else 0.0
            hold_minutes = int((signal.timestamp - pos.buy_time).total_seconds() / 60) if pos.buy_time else 0

            session.add(TradeRecord(
                date=datetime.date.today(),
                code=signal.code,
                name=signal.name,
                direction="SELL",
                price=signal.price,
                shares=sell_shares,
                amount=sell_amount,
                timestamp=signal.timestamp,
                signal_type=signal.signal_type,
                signal_reason=signal.signal_reason,
                minute_price=signal.minute_price,
                volume_ratio=signal.volume_ratio,
                buy_price=pos.buy_price,
                pnl=pnl,
                pnl_pct=pnl_pct,
                hold_minutes=hold_minutes,
                zone=signal.zone,
                emotion=signal.emotion,
                strategy_ver=signal.strategy_ver,
            ))

            remaining = int(pos.shares or 0) - sell_shares
            if remaining <= 0:
                session.delete(pos)
            else:
                pos.shares = remaining
                pos.cost = round(cost_per_share * remaining, 2)
                pos.current_price = signal.price
                if signal.signal_type == "TAKE_PROFIT_1":
                    # Prevent repeated tp1 execution after a partial scale-out.
                    pos.take_profit_1 = 0.0
                if _signal_is_add(signal):
                    pos.add_price = 0.0

            session.commit()

            return {
                "action": "SELL",
                "code": signal.code,
                "name": signal.name,
                "price": signal.price,
                "shares": sell_shares,
                "sell_amount": sell_amount,
                "fee": fee,
                "pnl": pnl,
                "pnl_pct": pnl_pct,
                "hold_minutes": hold_minutes,
                "signal_type": signal.signal_type,
                "timestamp": str(signal.timestamp),
            }
        except Exception as exc:
            session.rollback()
            logger.error(f"[sim] sell failed for {signal.code}: {exc}")
            return None
        finally:
            session.close()

    def update_positions_price(self, realtime_map: dict):
        session = get_session()
        try:
            for pos in session.query(Position).all():
                realtime = realtime_map.get(pos.code, {})
                if not realtime:
                    continue
                current_price = float(realtime.get("price", pos.buy_price) or pos.buy_price)
                cost_per_share = float(pos.cost or 0.0) / float(pos.shares or 1)
                pos.current_price = current_price
                pos.current_pnl = round((current_price - cost_per_share) * float(pos.shares or 0), 2)
                pos.current_pnl_pct = round((current_price / float(pos.buy_price or 1) - 1) * 100, 2)
            session.commit()
        except Exception as exc:
            session.rollback()
            logger.debug(f"[sim] update position price failed: {exc}")
        finally:
            session.close()

    def update_hold_days(self):
        session = get_session()
        try:
            today = datetime.date.today()
            for pos in session.query(Position).all():
                if pos.buy_date:
                    pos.hold_days = (today - pos.buy_date).days
            session.commit()
        except Exception:
            session.rollback()
        finally:
            session.close()
