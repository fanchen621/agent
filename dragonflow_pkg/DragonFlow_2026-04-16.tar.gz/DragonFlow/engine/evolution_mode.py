from __future__ import annotations

import datetime
import math
import time
from collections import Counter, defaultdict
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List

from loguru import logger

from config import EVOLUTION_MODE, SELFHEAL_CONFIG
from feeds.resilient import resilient_fetch_stocks
from models import (
    EvolutionCycle,
    EvolutionLog,
    EvolutionPaperPosition,
    EvolutionPaperTrade,
    MarketSnapshot,
    SystemHealthLog,
    get_session,
)
from openclaw_adapter import next_trading_day, update_state


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _blend(previous: float, target: float, rate: float) -> float:
    rate = _clamp(rate, 0.0, 1.0)
    return previous + (target - previous) * rate


def _mean(values: Iterable[float], default: float = 0.0) -> float:
    numbers = [float(v) for v in values]
    if not numbers:
        return default
    return sum(numbers) / len(numbers)


def _median(values: Iterable[float], default: float = 0.0) -> float:
    numbers = sorted(float(v) for v in values)
    if not numbers:
        return default
    mid = len(numbers) // 2
    if len(numbers) % 2 == 1:
        return numbers[mid]
    return (numbers[mid - 1] + numbers[mid]) / 2.0


def _normalize_trend_ratio(value: Any, default: float = 0.0) -> float:
    numeric = _safe_float(value, default)
    if numeric > 1.5:
        numeric = numeric / 100.0
    return _clamp(numeric, 0.0, 1.0)


def _format_trend_ratio(value: Any) -> str:
    return f"{_normalize_trend_ratio(value) * 100:.0f}%"


def _normalize_factor_value(name: str, value: Any) -> float:
    numeric = _safe_float(value)
    if name in {"multi_factor_score", "adaptive_score", "effective_score", "base_score"}:
        return _clamp((numeric - 65.0) / 15.0, -2.0, 2.0)
    if name.startswith("mf_"):
        return _clamp((numeric - 5.0) / 2.5, -2.0, 2.0)
    if name == "route_weight":
        return _clamp((numeric - 1.0) / 0.1, -2.0, 2.0)
    if name == "institutional_penalty":
        return _clamp(numeric / 4.0, -2.0, 2.0)
    if name in {"regime", "fundamentals", "capital_flow", "sentiment_factor", "chip_factor", "ensemble_bonus"}:
        return _clamp(numeric / 6.0, -2.0, 2.0)
    return _clamp(numeric / 10.0, -2.0, 2.0)


def _now() -> datetime.datetime:
    return datetime.datetime.now()


def _bucket(value: float, edges: list[tuple[float, str]], fallback: str = "--") -> str:
    for ceiling, label in edges:
        if value <= ceiling:
            return label
    return fallback


def _top_values(counter: Counter, limit: int) -> list[str]:
    return [key for key, _ in counter.most_common(limit) if key]


def _time_from_hhmm(value: str) -> datetime.time:
    hour_str, minute_str = str(value).split(":", 1)
    return datetime.time(int(hour_str), int(minute_str))


def _cycle_repair_reasons(
    cycle: Any,
    *,
    actual_buy_count: int,
    actual_sell_count: int,
    actual_open_positions: int,
    archived: bool,
) -> list[str]:
    reasons: list[str] = []
    if _safe_int(getattr(cycle, "buy_count", 0)) != int(actual_buy_count):
        reasons.append("buy_count_mismatch")
    if _safe_int(getattr(cycle, "sell_count", 0)) != int(actual_sell_count):
        reasons.append("sell_count_mismatch")
    if _safe_int(getattr(cycle, "open_positions", 0)) != int(actual_open_positions):
        reasons.append("open_position_mismatch")
    if getattr(cycle, "status", "") != "completed" and actual_sell_count > 0 and actual_open_positions <= 0:
        reasons.append("needs_finalize")
    if getattr(cycle, "status", "") == "completed" and not getattr(cycle, "end_date", None):
        reasons.append("missing_end_date")
    if actual_sell_count > 0 and not archived:
        reasons.append("missing_archive")
    if actual_sell_count > 0 and not (getattr(cycle, "analysis", None) or "").strip():
        reasons.append("missing_analysis")
    return reasons


def _default_profile() -> Dict[str, Any]:
    return {
        "version": "bootstrap",
        "score_floor": float(EVOLUTION_MODE["default_score_floor"]),
        "volume_ratio_floor": float(EVOLUTION_MODE["default_volume_ratio_floor"]),
        "turnover_floor": float(EVOLUTION_MODE["default_turnover_floor"]),
        "trend_floor": _normalize_trend_ratio(EVOLUTION_MODE.get("default_trend_floor"), 0.35),
        "confidence_floor": float(EVOLUTION_MODE["default_confidence_floor"]),
        "max_distance_to_high": float(EVOLUTION_MODE["default_max_distance_to_high"]),
        "preferred_pick_types": [],
        "avoid_pick_types": [],
        "preferred_zones": [],
        "preferred_emotions": [],
        "pick_type_bias": {},
        "factor_bias": {},
        "exploration_rate": float(EVOLUTION_MODE.get("default_exploration_rate", 0.35)),
        "max_code_repeat": int(EVOLUTION_MODE.get("default_max_code_repeat", 2)),
        "last_state": "bootstrap",
    }


def _profile_tags(profile: Dict[str, Any]) -> list[str]:
    tags: list[str] = []
    if not profile:
        return tags
    for key in profile.get("preferred_pick_types", [])[:2]:
        tags.append(f"偏好 {key}")
    for key in profile.get("avoid_pick_types", [])[:2]:
        tags.append(f"回避 {key}")
    if profile.get("preferred_zones"):
        tags.append("区间 " + "/".join(profile["preferred_zones"][:2]))
    if profile.get("score_floor"):
        tags.append(f"分数>={_safe_float(profile['score_floor']):.0f}")
    if profile.get("volume_ratio_floor"):
        tags.append(f"量比>={_safe_float(profile['volume_ratio_floor']):.1f}")
    if profile.get("confidence_floor"):
        tags.append(f"可信>={_safe_float(profile['confidence_floor']) * 100:.0f}%")
    if profile.get("exploration_rate") is not None:
        tags.append(f"explore {(_safe_float(profile['exploration_rate']) * 100):.0f}%")
    if profile.get("max_code_repeat") is not None:
        tags.append(f"repeat x{_safe_int(profile['max_code_repeat'], 1)}")
    return tags[:6]


def _build_recent_trade_payload(trade: EvolutionPaperTrade) -> Dict[str, Any]:
    return {
        "time": trade.timestamp.strftime("%H:%M:%S") if trade.timestamp else "",
        "code": trade.code,
        "name": trade.name,
        "direction": trade.direction,
        "price": float(trade.price or 0.0),
        "pnl": float(trade.pnl or 0.0),
        "pnl_pct": float(trade.pnl_pct or 0.0),
        "phase": trade.phase or "",
        "pick_type": trade.pick_type or "",
    }


def get_evolution_mode_status(limit_patterns: int = 6, limit_trades: int = 8) -> Dict[str, Any]:
    session = get_session()
    try:
        cycle = session.query(EvolutionCycle).order_by(EvolutionCycle.cycle_no.desc()).first()
        if cycle is None:
            profile = _default_profile()
            return {
                "enabled": bool(EVOLUTION_MODE.get("enabled", True)),
                "cycle_no": 0,
                "phase": "idle",
                "phase_label": "待启动",
                "buy_target": int(EVOLUTION_MODE["target_buy_trades_per_day"]),
                "sell_target": int(EVOLUTION_MODE["target_sell_trades_per_day"]),
                "buy_count": 0,
                "sell_count": 0,
                "open_positions": 0,
                "realized_pnl": 0.0,
                "win_rate": 0.0,
                "profit_ratio": 0.0,
                "strategy_profile": profile,
                "strategy_tags": _profile_tags(profile),
                "patterns": [],
                "analysis": "",
                "recent_trades": [],
            }

        profile = dict(cycle.strategy_profile or {})
        patterns = list(cycle.learned_patterns or [])[:limit_patterns]
        recent_trades = session.query(EvolutionPaperTrade).filter(
            EvolutionPaperTrade.cycle_no == cycle.cycle_no
        ).order_by(EvolutionPaperTrade.timestamp.desc()).limit(limit_trades).all()
        open_positions = session.query(EvolutionPaperPosition).filter(
            EvolutionPaperPosition.cycle_no == cycle.cycle_no,
            EvolutionPaperPosition.status == "open",
        ).count()
        phase_label_map = {
            "buy_day": "第1天买入实验",
            "sell_day": "第2天卖出实验",
            "completed": "本轮已完成",
            "analyzing": "盘后归因中",
        }
        return {
            "enabled": bool(EVOLUTION_MODE.get("enabled", True)),
            "cycle_no": int(cycle.cycle_no or 0),
            "phase": cycle.status or "idle",
            "phase_label": phase_label_map.get(cycle.status or "", cycle.status or "idle"),
            "start_date": str(cycle.start_date) if cycle.start_date else "",
            "sell_date": str(cycle.sell_date) if cycle.sell_date else "",
            "end_date": str(cycle.end_date) if cycle.end_date else "",
            "buy_target": int(cycle.buy_target or 0),
            "sell_target": int(cycle.sell_target or 0),
            "buy_count": int(cycle.buy_count or 0),
            "sell_count": int(cycle.sell_count or 0),
            "open_positions": int(open_positions),
            "realized_pnl": float(cycle.realized_pnl or 0.0),
            "win_rate": float(cycle.win_rate or 0.0),
            "profit_ratio": float(cycle.profit_ratio or 0.0),
            "strategy_profile": profile,
            "strategy_tags": _profile_tags(profile),
            "patterns": patterns,
            "analysis": cycle.analysis or "",
            "recent_trades": [_build_recent_trade_payload(item) for item in recent_trades],
            "updated_at": str(cycle.updated_at) if cycle.updated_at else "",
        }
    finally:
        session.close()


class EvolutionModeRuntime:
    def __init__(self):
        self.enabled = bool(EVOLUTION_MODE.get("enabled", True))
        self.action_interval_sec = int(EVOLUTION_MODE["action_interval_sec"])
        self.buy_target = int(EVOLUTION_MODE["target_buy_trades_per_day"])
        self.sell_target = int(EVOLUTION_MODE["target_sell_trades_per_day"])
        self.base_trade_shares = int(EVOLUTION_MODE["base_trade_shares"])
        self.max_candidates_per_tick = int(EVOLUTION_MODE["max_candidates_per_tick"])
        self.candidate_memory_limit = int(EVOLUTION_MODE.get("candidate_memory_limit", 80))
        self.candidate_memory_ttl_sec = int(EVOLUTION_MODE.get("candidate_memory_ttl_sec", 1800))
        self.recent_cycle_window = int(EVOLUTION_MODE.get("recent_cycle_window", 5))
        self.force_flatten_time = _time_from_hhmm(str(EVOLUTION_MODE["force_flatten_time"]))
        self._last_action_ts = 0.0
        self._last_emit_ts = 0.0
        self._last_snapshot_ts = 0.0
        self._candidate_memory: dict[str, Dict[str, Any]] = {}
        self._maintenance_done = False
        self._maintenance_report: Dict[str, Any] = {}

    def tick(
        self,
        zone: str,
        emotion: str,
        live_candidates: List[Dict[str, Any]],
        quote_map: Dict[str, Dict[str, Any]],
        emit,
    ) -> None:
        if not self.enabled:
            return

        now = _now()
        if not self._maintenance_done:
            self.run_startup_maintenance(today=now.date())
        self._remember_candidates(live_candidates, now=now)
        self._finalize_stale_cycle(today=now.date())
        changed = False
        cycle = self._ensure_active_cycle(today=now.date())
        phase = self._phase_for(cycle, today=now.date())

        if phase == "buy_day":
            changed = self._maybe_execute_buy_batch(
                cycle_no=int(cycle.cycle_no),
                now=now,
                zone=zone,
                emotion=emotion,
                live_candidates=live_candidates,
            )
        elif phase == "sell_day":
            changed = self._maybe_execute_sell_batch(
                cycle_no=int(cycle.cycle_no),
                now=now,
                zone=zone,
                emotion=emotion,
                live_candidates=live_candidates,
                quote_map=quote_map,
            )

        if phase == "sell_day":
            self._maybe_finalize_cycle(cycle_no=int(cycle.cycle_no), today=now.date())

        status = get_evolution_mode_status()
        update_state(
            evolution_cycle=status.get("cycle_no", 0),
            evolution_phase=status.get("phase", "idle"),
            evolution_buy_count=status.get("buy_count", 0),
            evolution_sell_count=status.get("sell_count", 0),
            evolution_open_positions=status.get("open_positions", 0),
        )

        if emit and (changed or time.time() - self._last_emit_ts >= 5.0):
            try:
                emit("evolution_mode", status)
            except Exception as exc:
                logger.debug(f"[evolution_mode] emit failed: {exc}")
            self._last_emit_ts = time.time()

        if changed or time.time() - self._last_snapshot_ts >= 15.0:
            self._save_snapshot(status)
            self._last_snapshot_ts = time.time()

    def _remember_candidates(self, live_candidates: List[Dict[str, Any]], now: datetime.datetime) -> None:
        cutoff = now.timestamp() - float(self.candidate_memory_ttl_sec)
        fresh: dict[str, Dict[str, Any]] = {}
        for code, item in self._candidate_memory.items():
            if _safe_float(item.get("_memory_last_seen_ts")) >= cutoff:
                fresh[code] = item
        self._candidate_memory = fresh

        for raw in live_candidates or []:
            code = str(raw.get("code", "") or "")
            if not code:
                continue
            previous = dict(self._candidate_memory.get(code, {}))
            merged = dict(previous)
            merged.update(dict(raw))
            merged["_memory_first_seen_ts"] = _safe_float(previous.get("_memory_first_seen_ts"), now.timestamp())
            merged["_memory_seen_count"] = _safe_int(previous.get("_memory_seen_count"), 0) + 1
            merged["_memory_last_seen_ts"] = now.timestamp()
            self._candidate_memory[code] = merged

        if len(self._candidate_memory) > self.candidate_memory_limit:
            ranked = sorted(
                self._candidate_memory.items(),
                key=lambda item: (
                    _safe_float(item[1].get("_memory_last_seen_ts")),
                    _safe_float(item[1].get("score")),
                ),
                reverse=True,
            )[: self.candidate_memory_limit]
            self._candidate_memory = dict(ranked)

    def _candidate_pool(self, live_candidates: List[Dict[str, Any]]) -> list[Dict[str, Any]]:
        combined: dict[str, Dict[str, Any]] = {}
        for item in live_candidates or []:
            code = str(item.get("code", "") or "")
            if code:
                combined[code] = dict(item)
        for code, item in self._candidate_memory.items():
            if code not in combined:
                combined[code] = dict(item)
        ranked = sorted(
            combined.values(),
            key=lambda item: (
                _safe_float(item.get("_memory_last_seen_ts")),
                _safe_float(item.get("score")),
                _safe_float(item.get("multi_factor_score")),
            ),
            reverse=True,
        )
        return ranked[: max(self.max_candidates_per_tick * 4, len(live_candidates or []))]

    def _finalize_stale_cycle(self, today: datetime.date) -> None:
        session = get_session()
        cycle_no = 0
        try:
            cycle = session.query(EvolutionCycle).filter(
                EvolutionCycle.status.in_(["sell_day", "analyzing"])
            ).order_by(EvolutionCycle.cycle_no.desc()).first()
            if cycle is None:
                return
            open_positions = session.query(EvolutionPaperPosition).filter(
                EvolutionPaperPosition.cycle_no == cycle.cycle_no,
                EvolutionPaperPosition.status == "open",
            ).count()
            if open_positions > 0 or int(cycle.buy_count or 0) <= 0:
                return
            cycle_no = int(cycle.cycle_no or 0)
        finally:
            session.close()

        if cycle_no > 0:
            self._maybe_finalize_cycle(cycle_no=cycle_no, today=today)

    def run_startup_maintenance(self, today: datetime.date | None = None, force: bool = False) -> Dict[str, Any]:
        if self._maintenance_done and not force:
            return dict(self._maintenance_report)
        report = self._repair_legacy_cycles(today=today or _now().date())
        self._maintenance_done = True
        self._maintenance_report = dict(report)
        return report

    def _repair_legacy_cycles(self, today: datetime.date) -> Dict[str, Any]:
        session = get_session()
        report: Dict[str, Any] = {
            "ran_at": str(_now()),
            "scanned": 0,
            "repaired": 0,
            "archived": 0,
            "finalized": 0,
            "pruned": {},
            "details": [],
        }
        try:
            archived_cycles = self._load_archived_cycle_nos(session)
            existing_versions = {
                str(item.version or "")
                for item in session.query(EvolutionLog).all()
                if getattr(item, "version", None)
            }
            cycles = session.query(EvolutionCycle).order_by(EvolutionCycle.cycle_no.asc()).all()
            report["scanned"] = len(cycles)

            for cycle in cycles:
                cycle_no = int(cycle.cycle_no or 0)
                if cycle_no <= 0:
                    continue
                buys = session.query(EvolutionPaperTrade).filter(
                    EvolutionPaperTrade.cycle_no == cycle_no,
                    EvolutionPaperTrade.direction == "BUY",
                ).order_by(EvolutionPaperTrade.timestamp.asc()).all()
                sells = session.query(EvolutionPaperTrade).filter(
                    EvolutionPaperTrade.cycle_no == cycle_no,
                    EvolutionPaperTrade.direction == "SELL",
                ).order_by(EvolutionPaperTrade.timestamp.asc()).all()
                positions = session.query(EvolutionPaperPosition).filter(
                    EvolutionPaperPosition.cycle_no == cycle_no,
                ).all()
                sell_slot_ts = {
                    str(item.slot_id or ""): item.timestamp
                    for item in sells
                    if item.slot_id
                }
                repaired = False
                for pos in positions:
                    slot_id = str(pos.slot_id or "")
                    if slot_id and slot_id in sell_slot_ts and pos.status != "closed":
                        pos.status = "closed"
                        pos.closed_at = sell_slot_ts[slot_id]
                        repaired = True

                actual_open_positions = sum(1 for pos in positions if str(pos.status or "open") == "open")
                actual_buy_count = len(buys)
                actual_sell_count = len(sells)
                reasons = _cycle_repair_reasons(
                    cycle,
                    actual_buy_count=actual_buy_count,
                    actual_sell_count=actual_sell_count,
                    actual_open_positions=actual_open_positions,
                    archived=(cycle_no in archived_cycles),
                )
                if not reasons:
                    continue

                stored_buy_count = _safe_int(getattr(cycle, "buy_count", 0))
                stored_sell_count = _safe_int(getattr(cycle, "sell_count", 0))
                stored_open_positions = _safe_int(getattr(cycle, "open_positions", 0))
                cycle.buy_count = actual_buy_count
                cycle.sell_count = actual_sell_count
                cycle.open_positions = actual_open_positions
                cycle.updated_at = _now()
                repaired = True

                finalized = False
                archive_added = False
                previous_profile = dict(cycle.strategy_profile or {}) or _default_profile()
                profile = previous_profile
                patterns = list(cycle.learned_patterns or [])
                summary: Dict[str, Any] = {
                    "trades": actual_sell_count,
                    "raw_trades": actual_sell_count,
                    "normalized_trades": actual_sell_count,
                    "state": "maintenance",
                    "total_pnl": round(_safe_float(cycle.realized_pnl), 2),
                }
                analysis_text = str(cycle.analysis or "").strip()

                if actual_open_positions <= 0 and actual_sell_count > 0:
                    profile, patterns, analysis_text, summary = self._build_cycle_learning(sells, previous_profile)
                    factor_update = self._update_factor_learning(sells)
                    if factor_update:
                        summary["factor_update"] = factor_update
                    last_sell_date = max(
                        [
                            item.timestamp.date()
                            for item in sells
                            if getattr(item, "timestamp", None) is not None
                        ]
                        or [cycle.sell_date or today]
                    )
                    cycle.status = "completed"
                    cycle.end_date = last_sell_date
                    cycle.realized_pnl = round(summary["total_pnl"], 2)
                    cycle.win_rate = round(summary["win_rate"], 4)
                    cycle.profit_ratio = round(summary["profit_ratio"], 2)
                    cycle.strategy_profile = profile
                    cycle.learned_patterns = patterns
                    finalized = True
                elif actual_open_positions <= 0 and actual_buy_count > 0 and actual_sell_count <= 0:
                    cycle.status = "completed"
                    cycle.end_date = cycle.sell_date or today
                    analysis_text = analysis_text or "maintenance archived cycle without sell records"
                    summary = {
                        "trades": 0,
                        "raw_trades": 0,
                        "normalized_trades": 0,
                        "state": "archived_without_sells",
                        "total_pnl": 0.0,
                    }
                    finalized = True

                migration_lines = [
                    "maintenance repair: legacy cycle cleaned",
                    "repair reasons: " + ", ".join(reasons),
                    f"stored counts -> buy:{stored_buy_count} "
                    f"sell:{stored_sell_count} open:{stored_open_positions}",
                    f"actual counts -> buy:{actual_buy_count} sell:{actual_sell_count} open:{actual_open_positions}",
                ]
                if analysis_text:
                    analysis_text = "\n".join(migration_lines + [analysis_text])
                else:
                    analysis_text = "\n".join(migration_lines)
                cycle.analysis = analysis_text

                archive_payload = {
                    "cycle_no": cycle_no,
                    "status": cycle.status,
                    "start_date": str(cycle.start_date or ""),
                    "sell_date": str(cycle.sell_date or ""),
                    "end_date": str(cycle.end_date or ""),
                    "buy_count": actual_buy_count,
                    "sell_count": actual_sell_count,
                    "open_positions": actual_open_positions,
                    "repair_reasons": reasons,
                    "summary": summary,
                    "patterns": patterns[:10],
                    "strategy_profile": profile,
                    "analysis": analysis_text,
                    "archived_at": str(_now()),
                }

                if cycle_no not in archived_cycles:
                    session.add(MarketSnapshot(
                        snapshot_type="evo_cycle_archive",
                        timestamp=_now(),
                        date=today,
                        data=archive_payload,
                    ))
                    archived_cycles.add(cycle_no)
                    archive_added = True

                log_version = f"cycle_repair_{cycle_no}"
                if log_version not in existing_versions:
                    session.add(EvolutionLog(
                        version=log_version,
                        trigger_reason=f"legacy cycle cleanup {cycle_no}",
                        old_params=previous_profile,
                        new_params=profile,
                        analysis=analysis_text,
                        performance_before={
                            "cycle_no": cycle_no,
                            "buy_count": actual_buy_count,
                            "sell_count": actual_sell_count,
                            "open_positions": actual_open_positions,
                            "repair_reasons": reasons,
                        },
                        performance_after=summary,
                        approved=True,
                    ))
                    existing_versions.add(log_version)

                report["repaired"] += 1 if repaired else 0
                report["finalized"] += 1 if finalized else 0
                report["archived"] += 1 if archive_added else 0
                report["details"].append({
                    "cycle_no": cycle_no,
                    "status": cycle.status,
                    "repair_reasons": reasons,
                    "buy_count": actual_buy_count,
                    "sell_count": actual_sell_count,
                    "open_positions": actual_open_positions,
                    "finalized": finalized,
                    "archived": archive_added,
                })

            report["pruned"] = self._prune_runtime_history(session)
            if report["details"] or any(int(v or 0) > 0 for v in report["pruned"].values()):
                session.add(MarketSnapshot(
                    snapshot_type="evo_maintenance",
                    timestamp=_now(),
                    date=today,
                    data=report,
                ))
            session.commit()
            if report["details"] or any(int(v or 0) > 0 for v in report["pruned"].values()):
                logger.info(
                    f"[evolution_mode] startup maintenance repaired={report['repaired']} "
                    f"finalized={report['finalized']} archived={report['archived']} "
                    f"pruned={report['pruned']}"
                )
        except Exception as exc:
            session.rollback()
            logger.error(f"[evolution_mode] startup maintenance failed: {exc}")
            report["error"] = str(exc)
        finally:
            session.close()
        return report

    def _prune_runtime_history(self, session) -> Dict[str, int]:
        pruned: Dict[str, int] = {}
        snapshot_rules = {
            "realtime_watch": int(SELFHEAL_CONFIG.get("keep_realtime_watch_snapshots", 1800)),
            "evolution_mode": int(SELFHEAL_CONFIG.get("keep_evolution_mode_snapshots", 1200)),
            "dynamic_backtest": int(SELFHEAL_CONFIG.get("keep_dynamic_backtest_snapshots", 180)),
            "daily_backtest_report": int(SELFHEAL_CONFIG.get("keep_dynamic_backtest_snapshots", 180)),
            "adaptive_factor_state": int(SELFHEAL_CONFIG.get("keep_adaptive_factor_snapshots", 120)),
            "evo_maintenance": int(SELFHEAL_CONFIG.get("keep_maintenance_snapshots", 60)),
        }
        for snapshot_type, keep in snapshot_rules.items():
            keep = max(1, int(keep))
            stale_ids = [
                row[0]
                for row in session.query(MarketSnapshot.id)
                .filter(MarketSnapshot.snapshot_type == snapshot_type)
                .order_by(MarketSnapshot.timestamp.desc(), MarketSnapshot.id.desc())
                .offset(keep)
                .all()
            ]
            if not stale_ids:
                pruned[snapshot_type] = 0
                continue
            deleted = session.query(MarketSnapshot).filter(
                MarketSnapshot.id.in_(stale_ids)
            ).delete(synchronize_session=False)
            pruned[snapshot_type] = int(deleted or 0)

        health_keep_days = max(1, int(SELFHEAL_CONFIG.get("keep_health_log_days", 30)))
        health_cutoff = _now() - datetime.timedelta(days=health_keep_days)
        deleted_health = session.query(SystemHealthLog).filter(
            SystemHealthLog.timestamp < health_cutoff
        ).delete(synchronize_session=False)
        pruned["system_health_logs"] = int(deleted_health or 0)

        try:
            from feeds.data_router import _cache as router_cache

            router_cache.clear_stale(max_age_seconds=86400 * 7)
        except Exception as exc:
            logger.debug(f"[evolution_mode] router cache prune failed: {exc}")

        return pruned

    def _load_archived_cycle_nos(self, session) -> set[int]:
        archived: set[int] = set()
        try:
            rows = session.query(MarketSnapshot).filter(
                MarketSnapshot.snapshot_type == "evo_cycle_archive",
            ).all()
            for row in rows:
                data = dict(row.data or {})
                cycle_no = _safe_int(data.get("cycle_no"))
                if cycle_no > 0:
                    archived.add(cycle_no)
        except Exception as exc:
            logger.debug(f"[evolution_mode] load archived cycles failed: {exc}")
        return archived

    def _cycle_exposure(self, session, cycle_no: int) -> tuple[Counter, Counter]:
        code_counter: Counter = Counter()
        pick_type_counter: Counter = Counter()
        buys = session.query(EvolutionPaperTrade).filter(
            EvolutionPaperTrade.cycle_no == cycle_no,
            EvolutionPaperTrade.direction == "BUY",
        ).all()
        for trade in buys:
            if trade.code:
                code_counter[str(trade.code)] += 1
            if trade.pick_type:
                pick_type_counter[str(trade.pick_type)] += 1
        return code_counter, pick_type_counter

    def _repeat_cap(self, profile: Dict[str, Any]) -> int:
        return max(1, _safe_int(profile.get("max_code_repeat"), int(EVOLUTION_MODE.get("default_max_code_repeat", 2))))

    def _ensure_active_cycle(self, today: datetime.date) -> EvolutionCycle:
        session = get_session()
        try:
            cycle = session.query(EvolutionCycle).filter(
                EvolutionCycle.status.in_(["buy_day", "sell_day", "analyzing"])
            ).order_by(EvolutionCycle.cycle_no.desc()).first()
            if cycle is not None:
                expected = self._phase_for(cycle, today=today)
                if cycle.status != expected and cycle.status != "completed":
                    cycle.status = expected
                    cycle.updated_at = _now()
                    session.commit()
                    session.refresh(cycle)
                return cycle

            last_cycle = session.query(EvolutionCycle).order_by(EvolutionCycle.cycle_no.desc()).first()
            cycle_no = int(last_cycle.cycle_no or 0) + 1 if last_cycle else 1
            profile = dict(last_cycle.strategy_profile or {}) if last_cycle and last_cycle.strategy_profile else _default_profile()
            cycle = EvolutionCycle(
                cycle_no=cycle_no,
                status="buy_day",
                start_date=today,
                sell_date=next_trading_day(today),
                buy_target=self.buy_target,
                sell_target=self.sell_target,
                strategy_profile=profile,
                learned_patterns=[],
            )
            session.add(cycle)
            session.commit()
            session.refresh(cycle)
            logger.info(f"[evolution_mode] created cycle {cycle_no} {cycle.start_date}->{cycle.sell_date}")
            return cycle
        finally:
            session.close()

    def _phase_for(self, cycle: EvolutionCycle, today: datetime.date) -> str:
        if cycle.status == "completed":
            return "completed"
        if today <= cycle.start_date:
            return "buy_day"
        if today >= cycle.sell_date:
            return "sell_day"
        return "buy_day"

    def _ready_for_action(self) -> bool:
        return time.time() - self._last_action_ts >= self.action_interval_sec

    def _slots_this_tick(self, remaining: int, now: datetime.datetime) -> int:
        if remaining <= 0:
            return 0
        end_dt = datetime.datetime.combine(now.date(), self.force_flatten_time)
        if now >= end_dt:
            return remaining
        seconds_left = max(1, int((end_dt - now).total_seconds()))
        windows_left = max(1, math.ceil(seconds_left / self.action_interval_sec))
        return max(1, math.ceil(remaining / windows_left))

    def _maybe_execute_buy_batch(
        self,
        cycle_no: int,
        now: datetime.datetime,
        zone: str,
        emotion: str,
        live_candidates: List[Dict[str, Any]],
    ) -> bool:
        candidate_pool = self._candidate_pool(live_candidates)
        if not self._ready_for_action() or not candidate_pool:
            return False

        session = get_session()
        try:
            cycle = session.query(EvolutionCycle).filter_by(cycle_no=cycle_no).first()
            if cycle is None or cycle.status == "completed":
                return False

            remaining = max(0, int(cycle.buy_target or self.buy_target) - int(cycle.buy_count or 0))
            if remaining <= 0:
                return False

            profile = dict(cycle.strategy_profile or {}) or _default_profile()
            code_exposure, pick_type_exposure = self._cycle_exposure(session, cycle_no)
            repeat_cap = self._repeat_cap(profile)
            ranked = self._rank_candidates(
                candidates=candidate_pool,
                profile=profile,
                zone=zone,
                emotion=emotion,
                code_exposure=code_exposure,
                pick_type_exposure=pick_type_exposure,
            )
            if not ranked:
                return False

            available_capacity = sum(
                max(0, repeat_cap - code_exposure[str(item.get("code", "") or "")])
                for item in ranked
                if item.get("code")
            )
            remaining = min(remaining, max(0, available_capacity))
            if remaining <= 0:
                return False

            batch = self._slots_this_tick(remaining=remaining, now=now)
            selected: list[Dict[str, Any]] = []
            batch_code_counter: Counter = Counter()

            for candidate in ranked:
                code = str(candidate.get("code", "") or "")
                if not code or batch_code_counter[code] > 0:
                    continue
                if code_exposure[code] >= repeat_cap:
                    continue
                selected.append(candidate)
                batch_code_counter[code] += 1
                if len(selected) >= batch:
                    break

            if len(selected) < batch:
                for candidate in ranked:
                    code = str(candidate.get("code", "") or "")
                    if not code:
                        continue
                    if code_exposure[code] + batch_code_counter[code] >= repeat_cap:
                        continue
                    selected.append(candidate)
                    batch_code_counter[code] += 1
                    if len(selected) >= batch:
                        break

            if not selected:
                return False

            created = 0
            for candidate in selected:
                price = _safe_float(candidate.get("entry_price") or candidate.get("price"))
                if price <= 0:
                    continue

                slot_seq = int(cycle.buy_count or 0) + created + 1
                slot_id = f"C{cycle.cycle_no:04d}-S{slot_seq:04d}"
                context = self._build_buy_context(candidate, zone=zone, emotion=emotion)
                effective_score = _safe_float(candidate.get("_effective_score"), _safe_float(candidate.get("score")))
                strategy_tag = self._strategy_tag(profile)

                session.add(EvolutionPaperPosition(
                    cycle_no=cycle.cycle_no,
                    slot_id=slot_id,
                    code=str(candidate.get("code", "")),
                    name=str(candidate.get("name", "")),
                    buy_date=now.date(),
                    planned_sell_date=cycle.sell_date,
                    buy_timestamp=now,
                    buy_price=price,
                    shares=self.base_trade_shares,
                    strategy_tag=strategy_tag,
                    pick_type=str(candidate.get("pick_type", "") or ""),
                    base_score=_safe_float(candidate.get("score")),
                    effective_score=effective_score,
                    zone=zone,
                    emotion=emotion,
                    status="open",
                    context=context,
                ))
                session.add(EvolutionPaperTrade(
                    cycle_no=cycle.cycle_no,
                    slot_id=slot_id,
                    date=now.date(),
                    code=str(candidate.get("code", "")),
                    name=str(candidate.get("name", "")),
                    direction="BUY",
                    phase="buy_day",
                    price=price,
                    shares=self.base_trade_shares,
                    amount=round(price * self.base_trade_shares, 2),
                    timestamp=now,
                    signal_type="EVOLUTION_BUY",
                    strategy_tag=strategy_tag,
                    pick_type=str(candidate.get("pick_type", "") or ""),
                    zone=zone,
                    emotion=emotion,
                    score=effective_score,
                    context=context,
                ))
                created += 1
                code_exposure[str(candidate.get("code", "") or "")] += 1
                pick_type = str(candidate.get("pick_type", "") or "")
                if pick_type:
                    pick_type_exposure[pick_type] += 1

            if created <= 0:
                return False

            cycle.buy_count = int(cycle.buy_count or 0) + created
            cycle.open_positions = int(cycle.open_positions or 0) + created
            cycle.status = "buy_day"
            cycle.last_action_at = now
            cycle.updated_at = now
            session.commit()
            self._last_action_ts = time.time()
            logger.info(f"[evolution_mode] cycle={cycle_no} buy +{created} total={cycle.buy_count}/{cycle.buy_target}")
            return True
        except Exception as exc:
            session.rollback()
            logger.error(f"[evolution_mode] buy batch failed: {exc}")
            return False
        finally:
            session.close()

    def _maybe_execute_sell_batch(
        self,
        cycle_no: int,
        now: datetime.datetime,
        zone: str,
        emotion: str,
        live_candidates: List[Dict[str, Any]],
        quote_map: Dict[str, Dict[str, Any]],
    ) -> bool:
        if not self._ready_for_action():
            return False

        session = get_session()
        try:
            cycle = session.query(EvolutionCycle).filter_by(cycle_no=cycle_no).first()
            if cycle is None or cycle.status == "completed":
                return False

            positions = session.query(EvolutionPaperPosition).filter(
                EvolutionPaperPosition.cycle_no == cycle_no,
                EvolutionPaperPosition.status == "open",
            ).all()
            if not positions:
                return False

            # 卖出所有已买仓位，不受sell_target限制
            target_total = int(cycle.buy_count or 0)
            remaining = max(0, target_total - int(cycle.sell_count or 0))
            if remaining <= 0:
                return False

            live_map = {
                str(item.get("code", "")): {
                    "price": _safe_float(item.get("entry_price") or item.get("price")),
                    "volume_ratio": _safe_float(item.get("volume_ratio")),
                    "change_pct": _safe_float(item.get("change_pct")),
                }
                for item in live_candidates
                if item.get("code")
            }
            merged_quotes = dict(live_map)
            merged_quotes.update(quote_map or {})
            missing_codes = sorted({pos.code for pos in positions if pos.code and pos.code not in merged_quotes})
            if missing_codes:
                try:
                    merged_quotes.update(resilient_fetch_stocks(missing_codes))
                except Exception as exc:
                    logger.debug(f"[evolution_mode] fetch sell quotes failed: {exc}")

            profile = dict(cycle.strategy_profile or {}) or _default_profile()
            ranked_positions = self._rank_positions_for_exit(
                positions=positions,
                quote_map=merged_quotes,
                profile=profile,
                zone=zone,
            )
            if not ranked_positions:
                return False

            batch = self._slots_this_tick(remaining=remaining, now=now)
            closed = 0
            realized_pnl = 0.0
            for item in ranked_positions[:batch]:
                pos = item["position"]
                quote = item["quote"]
                price = _safe_float(quote.get("price"), _safe_float(pos.buy_price))
                amount = round(price * int(pos.shares or 0), 2)
                pnl = round((price - _safe_float(pos.buy_price)) * int(pos.shares or 0), 2)
                pnl_pct = round((price / max(_safe_float(pos.buy_price), 0.0001) - 1.0) * 100.0, 2)
                context = dict(pos.context or {})
                context["exit_rank"] = round(_safe_float(item.get("urgency")), 3)
                context["exit_volume_ratio"] = _safe_float(quote.get("volume_ratio"))

                session.add(EvolutionPaperTrade(
                    cycle_no=cycle.cycle_no,
                    slot_id=pos.slot_id,
                    date=now.date(),
                    code=pos.code,
                    name=pos.name,
                    direction="SELL",
                    phase="sell_day",
                    price=price,
                    shares=int(pos.shares or 0),
                    amount=amount,
                    timestamp=now,
                    signal_type="EVOLUTION_SELL",
                    strategy_tag=pos.strategy_tag,
                    pick_type=pos.pick_type,
                    zone=zone,
                    emotion=emotion,
                    score=_safe_float(pos.effective_score),
                    pnl=pnl,
                    pnl_pct=pnl_pct,
                    context=context,
                ))
                pos.status = "closed"
                pos.closed_at = now
                closed += 1
                realized_pnl += pnl

            if closed <= 0:
                return False

            cycle.sell_count = int(cycle.sell_count or 0) + closed
            cycle.open_positions = max(0, int(cycle.open_positions or 0) - closed)
            cycle.realized_pnl = round(_safe_float(cycle.realized_pnl) + realized_pnl, 2)
            cycle.status = "sell_day"
            cycle.last_action_at = now
            cycle.updated_at = now
            session.commit()
            self._last_action_ts = time.time()
            logger.info(f"[evolution_mode] cycle={cycle_no} sell +{closed} total={cycle.sell_count}/{target_total}")
            return True
        except Exception as exc:
            session.rollback()
            logger.error(f"[evolution_mode] sell batch failed: {exc}")
            return False
        finally:
            session.close()

    def _factor_bias_bonus(self, candidate: Dict[str, Any], profile: Dict[str, Any]) -> tuple[float, list[str]]:
        breakdown = dict(candidate.get("breakdown") or {})
        learned_weights = dict(profile.get("factor_bias") or {})
        bonus = 0.0
        notes: list[str] = []
        for name, weight in learned_weights.items():
            numeric_weight = _safe_float(weight)
            if abs(numeric_weight) < 0.05 or name not in breakdown:
                continue
            aligned = _normalize_factor_value(name, breakdown.get(name)) * numeric_weight
            if abs(aligned) < 0.12:
                continue
            contribution = _clamp(aligned * 1.6, -2.5, 2.5)
            bonus += contribution
            if len(notes) < 3 and abs(contribution) >= 0.6:
                notes.append(f"{name}:{contribution:+.1f}")
        return bonus, notes

    def _rank_candidates(
        self,
        candidates: List[Dict[str, Any]],
        profile: Dict[str, Any],
        zone: str,
        emotion: str,
        code_exposure: Counter | None = None,
        pick_type_exposure: Counter | None = None,
    ) -> list[Dict[str, Any]]:
        code_exposure = Counter(code_exposure or {})
        pick_type_exposure = Counter(pick_type_exposure or {})
        ranked: list[Dict[str, Any]] = []
        exploration_rate = _clamp(
            _safe_float(profile.get("exploration_rate"), float(EVOLUTION_MODE.get("default_exploration_rate", 0.35))),
            0.05,
            0.8,
        )
        softener = 1.0 - exploration_rate * 0.3

        for item in candidates[: max(len(candidates), self.max_candidates_per_tick)]:
            candidate = dict(item)
            code = str(candidate.get("code", "") or "")
            base_score = _safe_float(candidate.get("score"))
            pick_type = str(candidate.get("pick_type", "") or "")
            volume_ratio = _safe_float(candidate.get("volume_ratio"))
            turnover_pct = _safe_float(candidate.get("turnover_pct"))
            trend_alignment = _normalize_trend_ratio(candidate.get("trend_alignment"))
            confidence = _safe_float(candidate.get("data_confidence"), 0.72)
            distance_to_high = _safe_float(candidate.get("distance_to_high_20d_pct"))
            bias = 0.0
            notes: list[str] = []

            if pick_type and pick_type in profile.get("preferred_pick_types", []):
                bias += 3.5
                notes.append(f"prefer:{pick_type}")
            if pick_type and pick_type in profile.get("avoid_pick_types", []):
                bias -= 4.5
                notes.append(f"avoid:{pick_type}")
            if zone and zone in profile.get("preferred_zones", []):
                bias += 1.5
            if emotion and emotion in profile.get("preferred_emotions", []):
                bias += 1.0

            type_bias = _safe_float((profile.get("pick_type_bias") or {}).get(pick_type))
            if abs(type_bias) > 0.05:
                bias += _clamp(type_bias * 2.0, -4.0, 4.0)
                if abs(type_bias) >= 0.35:
                    notes.append(f"type:{type_bias:+.1f}")

            factor_bonus, factor_notes = self._factor_bias_bonus(candidate, profile)
            bias += factor_bonus
            notes.extend(factor_notes)

            score_floor = _safe_float(profile.get("score_floor"), _safe_float(EVOLUTION_MODE["default_score_floor"]))
            if base_score < score_floor:
                bias -= min(8.0, (score_floor - base_score) * 0.6) * softener
                notes.append(f"score<{score_floor:.0f}")

            volume_floor = _safe_float(profile.get("volume_ratio_floor"), _safe_float(EVOLUTION_MODE["default_volume_ratio_floor"]))
            if volume_ratio < volume_floor:
                bias -= min(4.5, (volume_floor - volume_ratio) * 1.8) * softener
                notes.append(f"vr<{volume_floor:.1f}")

            turnover_floor = _safe_float(profile.get("turnover_floor"), _safe_float(EVOLUTION_MODE["default_turnover_floor"]))
            if turnover_pct < turnover_floor:
                bias -= min(3.5, (turnover_floor - turnover_pct) * 0.6) * softener
                notes.append(f"turn<{turnover_floor:.1f}")

            trend_floor = _normalize_trend_ratio(
                profile.get("trend_floor"),
                _normalize_trend_ratio(EVOLUTION_MODE.get("default_trend_floor"), 0.35),
            )
            if trend_alignment < trend_floor:
                bias -= min(4.0, (trend_floor - trend_alignment) / 0.15) * softener
                notes.append(f"trend<{_format_trend_ratio(trend_floor)}")

            confidence_floor = _safe_float(profile.get("confidence_floor"), _safe_float(EVOLUTION_MODE["default_confidence_floor"]))
            if confidence < confidence_floor:
                bias -= min(4.0, (confidence_floor - confidence) * 12.0) * softener
                notes.append(f"conf<{confidence_floor:.2f}")

            max_distance = _safe_float(profile.get("max_distance_to_high"), _safe_float(EVOLUTION_MODE["default_max_distance_to_high"]))
            if distance_to_high > max_distance:
                bias -= min(3.0, (distance_to_high - max_distance) / 4.0) * softener
                notes.append(f"far_high>{max_distance:.0f}")

            if code and code_exposure[code] <= 0:
                novelty_bonus = 1.4 + exploration_rate * 2.0
                if _safe_int(candidate.get("_memory_seen_count"), 1) <= 1:
                    novelty_bonus += 0.6
                bias += novelty_bonus
                notes.append("novel")
            elif code and code_exposure[code] > 0:
                repeat_penalty = min(8.0, code_exposure[code] * (3.5 + exploration_rate * 3.0))
                bias -= repeat_penalty
                notes.append(f"repeat:{code_exposure[code]}")

            if pick_type and pick_type_exposure[pick_type] > 0:
                crowd_penalty = min(3.5, pick_type_exposure[pick_type] * (0.8 + exploration_rate))
                bias -= crowd_penalty
                notes.append(f"crowd:{pick_type_exposure[pick_type]}")

            candidate["_effective_score"] = round(base_score + bias, 2)
            candidate["_bias_notes"] = notes[:8]
            ranked.append(candidate)

        ranked.sort(
            key=lambda item: (
                _safe_float(item.get("_effective_score")),
                _safe_float(item.get("multi_factor_score")),
                _safe_float(item.get("score")),
            ),
            reverse=True,
        )
        return ranked[: max(self.max_candidates_per_tick * 4, len(ranked))]

    def _rank_positions_for_exit(
        self,
        positions: List[EvolutionPaperPosition],
        quote_map: Dict[str, Dict[str, Any]],
        profile: Dict[str, Any],
        zone: str,
    ) -> list[Dict[str, Any]]:
        ranked: list[Dict[str, Any]] = []
        for pos in positions:
            quote = dict(quote_map.get(pos.code, {}) or {})
            price = _safe_float(quote.get("price"), _safe_float(pos.buy_price))
            volume_ratio = _safe_float(quote.get("volume_ratio"))
            pnl_pct = (price / max(_safe_float(pos.buy_price), 0.0001) - 1.0) * 100.0
            urgency = 0.0

            if zone == "risk":
                urgency += 6.0
            if pnl_pct <= -2.0:
                urgency += 5.0
            elif pnl_pct <= -0.5:
                urgency += 3.0
            elif pnl_pct >= 3.0:
                urgency -= min(2.5, pnl_pct / 3.5)

            if pos.pick_type and pos.pick_type in profile.get("avoid_pick_types", []):
                urgency += 2.0

            if volume_ratio > 0 and volume_ratio < _safe_float(profile.get("volume_ratio_floor"), 1.6):
                urgency += 1.5

            ranked.append({
                "position": pos,
                "quote": quote,
                "urgency": urgency,
            })

        ranked.sort(key=lambda item: item["urgency"], reverse=True)
        return ranked

    def _build_buy_context(self, candidate: Dict[str, Any], zone: str, emotion: str) -> Dict[str, Any]:
        return {
            "code": str(candidate.get("code", "") or ""),
            "base_score": _safe_float(candidate.get("score")),
            "effective_score": _safe_float(candidate.get("_effective_score"), _safe_float(candidate.get("score"))),
            "pick_type": str(candidate.get("pick_type", "") or ""),
            "volume_ratio": _safe_float(candidate.get("volume_ratio")),
            "turnover_pct": _safe_float(candidate.get("turnover_pct")),
            "distance_to_high_20d_pct": _safe_float(candidate.get("distance_to_high_20d_pct")),
            "range_position_pct": _safe_float(candidate.get("range_position_pct")),
            "trend_alignment": _normalize_trend_ratio(candidate.get("trend_alignment")),
            "board_height": _safe_int(candidate.get("board_height")),
            "data_confidence": _safe_float(candidate.get("data_confidence"), 0.72),
            "zone": zone,
            "emotion": emotion,
            "memory_seen_count": _safe_int(candidate.get("_memory_seen_count"), 1),
            "bias_notes": list(candidate.get("_bias_notes", [])),
            "breakdown": dict(candidate.get("breakdown") or {}),
        }

    def _strategy_tag(self, profile: Dict[str, Any]) -> str:
        preferred = "-".join(profile.get("preferred_pick_types", [])[:2]).strip("-")
        return preferred or "adaptive_cycle"

    def _merge_trade_contexts(self, contexts: List[Dict[str, Any]]) -> Dict[str, Any]:
        merged: Dict[str, Any] = {}
        numeric_fields: dict[str, list[float]] = defaultdict(list)
        breakdown_numeric: dict[str, list[float]] = defaultdict(list)
        breakdown_static: Dict[str, Any] = {}

        for raw in contexts:
            ctx = dict(raw or {})
            for key, value in ctx.items():
                if key == "breakdown":
                    for name, item in dict(value or {}).items():
                        if isinstance(item, bool):
                            continue
                        if isinstance(item, (int, float)):
                            breakdown_numeric[str(name)].append(float(item))
                        elif name not in breakdown_static or breakdown_static[name] in ("", None):
                            breakdown_static[str(name)] = item
                    continue
                if isinstance(value, bool):
                    continue
                if isinstance(value, (int, float)):
                    numeric_fields[str(key)].append(float(value))
                elif key not in merged or merged[key] in ("", None, []):
                    merged[str(key)] = value

        for key, values in numeric_fields.items():
            merged[key] = round(sum(values) / max(1, len(values)), 4)

        breakdown = dict(breakdown_static)
        for key, values in breakdown_numeric.items():
            breakdown[key] = round(sum(values) / max(1, len(values)), 4)
        if breakdown:
            merged["breakdown"] = breakdown
        return merged

    def _normalize_cycle_trades(self, sells: List[EvolutionPaperTrade]) -> tuple[list[Any], Dict[str, Any]]:
        grouped: dict[tuple[str, str, str, str], list[EvolutionPaperTrade]] = defaultdict(list)
        raw_trades = len(sells or [])
        for idx, trade in enumerate(sells or []):
            ctx = dict(trade.context or {})
            code = str(trade.code or ctx.get("code") or "").strip()
            pick_type = str(trade.pick_type or ctx.get("pick_type") or "").strip()
            zone = str(trade.zone or ctx.get("zone") or "").strip()
            emotion = str(trade.emotion or ctx.get("emotion") or "").strip()
            grouped[(code or f"__row_{idx}", pick_type, zone, emotion)].append(trade)

        normalized: list[Any] = []
        repeat_hotspots: list[str] = []
        max_group = 0
        for items in grouped.values():
            first = items[0]
            max_group = max(max_group, len(items))
            merged_context = self._merge_trade_contexts([dict(item.context or {}) for item in items])
            merged_context.setdefault("code", str(first.code or ""))
            merged_context.setdefault("pick_type", str(first.pick_type or ""))
            merged_context.setdefault("zone", str(first.zone or ""))
            merged_context.setdefault("emotion", str(first.emotion or ""))
            merged_context["sample_repeat_count"] = len(items)
            merged_context["trend_alignment"] = _normalize_trend_ratio(merged_context.get("trend_alignment"))

            normalized.append(SimpleNamespace(
                code=str(first.code or ""),
                name=str(getattr(first, "name", "") or ""),
                direction=str(getattr(first, "direction", "SELL") or "SELL"),
                pick_type=str(first.pick_type or merged_context.get("pick_type") or ""),
                pnl=round(sum(_safe_float(item.pnl) for item in items), 2),
                pnl_pct=round(_mean([_safe_float(item.pnl_pct) for item in items], 0.0), 2),
                zone=str(first.zone or merged_context.get("zone") or ""),
                emotion=str(first.emotion or merged_context.get("emotion") or ""),
                context=merged_context,
                slot_id=str(getattr(first, "slot_id", "") or ""),
                timestamp=getattr(first, "timestamp", None),
            ))

            if len(items) > 1 and first.code:
                repeat_hotspots.append(
                    f"{first.code}x{len(items)}:{str(first.pick_type or merged_context.get('pick_type') or '--')}"
                )

        dominant_code_share = (max_group / raw_trades) if raw_trades else 0.0
        compression_ratio = (len(normalized) / raw_trades) if raw_trades else 1.0
        stats = {
            "raw_trades": raw_trades,
            "normalized_trades": len(normalized),
            "dominant_code_share": round(dominant_code_share, 4),
            "compression_ratio": round(compression_ratio, 4),
            "repeat_hotspots": repeat_hotspots[:5],
        }
        return normalized, stats

    def _update_factor_learning(self, sells: List[EvolutionPaperTrade]) -> Dict[str, Any]:
        normalized_sells, _ = self._normalize_cycle_trades(sells)
        trade_details: list[Dict[str, Any]] = []
        for trade in normalized_sells:
            ctx = dict(trade.context or {})
            breakdown = dict(ctx.get("breakdown") or {})
            if not breakdown:
                continue
            trade_details.append({
                "code": trade.code,
                "pnl_pct": _safe_float(trade.pnl_pct),
                "pnl": _safe_float(trade.pnl),
                "pick_type": trade.pick_type or "",
                "zone": trade.zone or "",
                "factor_scores": breakdown,
            })

        if not trade_details:
            return {}

        try:
            from evolution.optimizer import update_adaptive_factor_tracker

            return update_adaptive_factor_tracker(
                trade_details,
                source="evolution_mode_cycle",
            )
        except Exception as exc:
            logger.debug(f"[evolution_mode] factor learning update failed: {exc}")
            return {}

    def _maybe_finalize_cycle(self, cycle_no: int, today: datetime.date) -> None:
        session = get_session()
        try:
            cycle = session.query(EvolutionCycle).filter_by(cycle_no=cycle_no).first()
            if cycle is None or cycle.status == "completed":
                return

            open_positions = session.query(EvolutionPaperPosition).filter(
                EvolutionPaperPosition.cycle_no == cycle_no,
                EvolutionPaperPosition.status == "open",
            ).count()
            if open_positions > 0:
                cycle.open_positions = int(open_positions)
                session.commit()
                return

            sells = session.query(EvolutionPaperTrade).filter(
                EvolutionPaperTrade.cycle_no == cycle_no,
                EvolutionPaperTrade.direction == "SELL",
            ).order_by(EvolutionPaperTrade.timestamp.asc()).all()
            if not sells:
                return

            cycle.status = "analyzing"
            session.commit()

            previous_profile = dict(cycle.strategy_profile or {}) or _default_profile()
            profile, patterns, analysis_text, summary = self._build_cycle_learning(
                sells=sells,
                previous_profile=previous_profile,
            )
            factor_update = self._update_factor_learning(sells)
            if factor_update:
                summary["factor_update"] = factor_update
                top = factor_update.get("top_factors") or []
                noise = factor_update.get("noise_factors") or []
                extra_lines: list[str] = []
                if top:
                    extra_lines.append(
                        "top factors: " + ", ".join(
                            f"{name}({effect:+.2f})"
                            for name, effect, _ in top[:3]
                        )
                    )
                if noise:
                    extra_lines.append(
                        "noise factors: " + ", ".join(
                            f"{name}({effect:+.2f})"
                            for name, effect, _ in noise
                        )
                    )
                if extra_lines:
                    analysis_text = analysis_text + "\n" + "\n".join(extra_lines)
            cycle.status = "completed"
            cycle.end_date = today
            cycle.open_positions = 0
            cycle.realized_pnl = round(summary["total_pnl"], 2)
            cycle.win_rate = round(summary["win_rate"], 4)
            cycle.profit_ratio = round(summary["profit_ratio"], 2)
            cycle.strategy_profile = profile
            cycle.learned_patterns = patterns
            cycle.analysis = analysis_text
            cycle.updated_at = _now()

            session.add(EvolutionLog(
                version=f"cycle_{cycle_no}",
                trigger_reason=f"evolution mode cycle {cycle_no}",
                old_params=previous_profile,
                new_params=profile,
                analysis=analysis_text,
                performance_before={
                    "cycle_no": cycle_no,
                    "trades": len(sells),
                    "buy_count": int(cycle.buy_count or 0),
                    "sell_count": int(cycle.sell_count or 0),
                },
                performance_after=summary,
                approved=True,
            ))
            session.commit()
            logger.info(
                f"[evolution_mode] cycle={cycle_no} completed "
                f"trades={summary['trades']} wr={summary['win_rate'] * 100:.1f}% "
                f"pr={summary['profit_ratio']:.2f} pnl={summary['total_pnl']:+.2f}"
            )
        except Exception as exc:
            session.rollback()
            logger.error(f"[evolution_mode] finalize failed: {exc}")
        finally:
            session.close()

    def _build_cycle_learning(
        self,
        sells: List[EvolutionPaperTrade],
        previous_profile: Dict[str, Any],
    ) -> tuple[Dict[str, Any], list[Dict[str, Any]], str, Dict[str, Any]]:
        trades, normalization = self._normalize_cycle_trades(sells)
        raw_total = int(normalization.get("raw_trades", len(sells or [])))
        total = len(trades)
        wins = [trade for trade in trades if _safe_float(trade.pnl) > 0]
        losses = [trade for trade in trades if _safe_float(trade.pnl) <= 0]
        win_rate = len(wins) / total if total else 0.0
        avg_win = sum(_safe_float(trade.pnl_pct) for trade in wins) / len(wins) if wins else 0.0
        avg_loss = sum(abs(_safe_float(trade.pnl_pct)) for trade in losses) / len(losses) if losses else 0.0
        profit_ratio = (avg_win / avg_loss) if avg_loss > 0 else 0.0
        total_pnl = sum(_safe_float(trade.pnl) for trade in trades)
        unique_codes = len({str(trade.code or "") for trade in trades if trade.code})
        diversity_ratio = unique_codes / total if total else 0.0
        dominant_code_share = _safe_float(normalization.get("dominant_code_share"))
        elite_size = max(1, int(total * float(EVOLUTION_MODE["analysis_focus_ratio"])))
        ranked_by_pnl = sorted(trades, key=lambda item: _safe_float(item.pnl_pct), reverse=True)
        elite = ranked_by_pnl[:elite_size]
        laggards = ranked_by_pnl[-elite_size:]
        elite_contexts = [dict(item.context or {}) for item in elite]
        weak_contexts = [dict(item.context or {}) for item in laggards]
        sample_weight = _clamp(total / 24.0, 0.2, 1.0)

        if total_pnl < 0 or win_rate < 0.45 or diversity_ratio < 0.4 or dominant_code_share > 0.34:
            state = "recover"
        elif win_rate >= 0.58 and profit_ratio >= 1.2 and total_pnl > 0 and diversity_ratio >= 0.55:
            state = "refine"
        else:
            state = "stabilize"

        def _ctx_values(source: list[dict], name: str, normalizer=None) -> list[float]:
            values: list[float] = []
            for item in source:
                if item.get(name) is None:
                    continue
                value = _safe_float(item.get(name))
                if normalizer is not None:
                    value = normalizer(value)
                values.append(value)
            return values

        def _adaptive_floor(
            profile_key: str,
            ctx_name: str,
            default: float,
            low: float,
            high: float,
            margin: float,
            normalizer=None,
        ) -> float:
            previous = _safe_float(previous_profile.get(profile_key), default)
            if normalizer is not None:
                previous = normalizer(previous)
            win_median = _median(_ctx_values([dict(trade.context or {}) for trade in wins], ctx_name, normalizer), default)
            lose_median = _median(_ctx_values([dict(trade.context or {}) for trade in losses], ctx_name, normalizer), default)
            elite_median = _median(_ctx_values(elite_contexts, ctx_name, normalizer), win_median)

            if state == "recover":
                target = min(previous - margin * 0.45, win_median - margin)
            elif state == "refine":
                target = elite_median - margin * 0.35
            else:
                target = (elite_median * 0.65) + (lose_median * 0.35) - margin * 0.6
            return round(_clamp(_blend(previous, target, sample_weight * 0.55), low, high), 3)

        def _adaptive_ceiling(
            profile_key: str,
            ctx_name: str,
            default: float,
            low: float,
            high: float,
            margin: float,
            normalizer=None,
        ) -> float:
            previous = _safe_float(previous_profile.get(profile_key), default)
            if normalizer is not None:
                previous = normalizer(previous)
            win_median = _median(_ctx_values([dict(trade.context or {}) for trade in wins], ctx_name, normalizer), default)
            lose_median = _median(_ctx_values([dict(trade.context or {}) for trade in losses], ctx_name, normalizer), default)
            elite_median = _median(_ctx_values(elite_contexts, ctx_name, normalizer), win_median)
            if state == "recover":
                target = max(previous + margin * 0.6, elite_median + margin)
            elif state == "refine":
                target = elite_median + margin * 0.3
            else:
                target = (elite_median * 0.65) + (lose_median * 0.35) + margin * 0.45
            return round(_clamp(_blend(previous, target, sample_weight * 0.5), low, high), 3)

        pick_type_stats: dict[str, dict[str, float]] = defaultdict(lambda: {
            "samples": 0,
            "wins": 0,
            "pnl_pct_sum": 0.0,
        })
        zone_stats: dict[str, dict[str, float]] = defaultdict(lambda: {"samples": 0, "pnl_pct_sum": 0.0})
        emotion_stats: dict[str, dict[str, float]] = defaultdict(lambda: {"samples": 0, "pnl_pct_sum": 0.0})
        factor_stats: dict[str, dict[str, float]] = defaultdict(lambda: {
            "samples": 0,
            "wins": 0,
            "losses": 0,
            "win_sum": 0.0,
            "loss_sum": 0.0,
        })

        for trade in trades:
            ctx = dict(trade.context or {})
            pick_type = str(trade.pick_type or ctx.get("pick_type") or "")
            if pick_type:
                stat = pick_type_stats[pick_type]
                stat["samples"] += 1
                stat["pnl_pct_sum"] += _safe_float(trade.pnl_pct)
                if _safe_float(trade.pnl) > 0:
                    stat["wins"] += 1

            if trade.zone:
                zone_stats[str(trade.zone)]["samples"] += 1
                zone_stats[str(trade.zone)]["pnl_pct_sum"] += _safe_float(trade.pnl_pct)
            if trade.emotion:
                emotion_stats[str(trade.emotion)]["samples"] += 1
                emotion_stats[str(trade.emotion)]["pnl_pct_sum"] += _safe_float(trade.pnl_pct)

            breakdown = dict(ctx.get("breakdown") or {})
            for name, value in breakdown.items():
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    continue
                stat = factor_stats[name]
                stat["samples"] += 1
                normalized = _normalize_factor_value(name, value)
                if _safe_float(trade.pnl) > 0:
                    stat["wins"] += 1
                    stat["win_sum"] += normalized
                else:
                    stat["losses"] += 1
                    stat["loss_sum"] += normalized

        prev_type_bias = dict(previous_profile.get("pick_type_bias") or {})
        pick_type_bias: dict[str, float] = {}
        for name, stat in pick_type_stats.items():
            samples = max(1, int(stat["samples"]))
            wr = _safe_float(stat["wins"]) / samples
            avg_pnl_pct = _safe_float(stat["pnl_pct_sum"]) / samples
            signal = ((wr - 0.5) * 2.2) + (avg_pnl_pct / 3.0)
            signal *= min(1.0, math.log(samples + 1) / math.log(8))
            blended = _blend(_safe_float(prev_type_bias.get(name)), signal, sample_weight * 0.6)
            blended = _clamp(blended, -1.6, 1.6)
            if abs(blended) >= 0.08:
                pick_type_bias[name] = round(blended, 3)

        sorted_type_bias = sorted(pick_type_bias.items(), key=lambda item: item[1], reverse=True)
        preferred_pick_types = [
            name for name, score in sorted_type_bias
            if score > 0.18
        ][: int(EVOLUTION_MODE["profile_top_pick_types"])]
        avoid_pick_types = [
            name for name, score in sorted(pick_type_bias.items(), key=lambda item: item[1])
            if score < -0.18
        ][: int(EVOLUTION_MODE["profile_top_pick_types"])]

        prev_factor_bias = dict(previous_profile.get("factor_bias") or {})
        factor_bias: dict[str, float] = {}
        factor_rows: list[dict[str, Any]] = []
        min_factor_samples = max(4, int(EVOLUTION_MODE["min_group_sample"]) // 2)
        for name, stat in factor_stats.items():
            samples = int(stat["samples"])
            if samples < min_factor_samples:
                continue
            win_avg = _safe_float(stat["win_sum"]) / max(1, int(stat["wins"]))
            loss_avg = _safe_float(stat["loss_sum"]) / max(1, int(stat["losses"]))
            signal = (win_avg - loss_avg) * min(1.0, math.log(samples + 1) / math.log(10))
            blended = _blend(_safe_float(prev_factor_bias.get(name)), signal, sample_weight * 0.45)
            blended = _clamp(blended, -1.25, 1.25)
            if abs(blended) >= 0.05:
                factor_bias[name] = round(blended, 3)
            factor_rows.append({
                "dimension": "factor",
                "value": name,
                "samples": samples,
                "win_rate": round(_safe_float(stat["wins"]) / samples, 3),
                "avg_pnl_pct": round((win_avg - loss_avg) * 2.0, 2),
                "bias": "prefer" if blended >= 0 else "avoid",
                "score": round(blended, 3),
            })

        preferred_zones = [
            name for name, stat in sorted(
                zone_stats.items(),
                key=lambda item: (_safe_float(item[1]["pnl_pct_sum"]) / max(1, int(item[1]["samples"])), int(item[1]["samples"])),
                reverse=True,
            )
            if int(stat["samples"]) >= 2 and (_safe_float(stat["pnl_pct_sum"]) / max(1, int(stat["samples"]))) >= 0
        ][: int(EVOLUTION_MODE["profile_top_zones"])]
        preferred_emotions = [
            name for name, stat in sorted(
                emotion_stats.items(),
                key=lambda item: (_safe_float(item[1]["pnl_pct_sum"]) / max(1, int(item[1]["samples"])), int(item[1]["samples"])),
                reverse=True,
            )
            if int(stat["samples"]) >= 2 and (_safe_float(stat["pnl_pct_sum"]) / max(1, int(stat["samples"]))) >= 0
        ][: int(EVOLUTION_MODE["profile_top_emotions"])]

        previous_exploration = _safe_float(
            previous_profile.get("exploration_rate"),
            float(EVOLUTION_MODE.get("default_exploration_rate", 0.35)),
        )
        concentration_penalty = max(0.0, dominant_code_share - 0.2)
        if state == "recover":
            target_exploration = min(
                0.82,
                previous_exploration + 0.15 + max(0.0, 0.55 - diversity_ratio) + concentration_penalty * 0.9,
            )
        elif state == "refine":
            target_exploration = max(0.12, previous_exploration - 0.08)
        else:
            target_exploration = 0.30 + max(0.0, 0.55 - diversity_ratio) * 0.2 + concentration_penalty * 0.35
        exploration_rate = round(_clamp(_blend(previous_exploration, target_exploration, sample_weight * 0.65), 0.1, 0.8), 3)
        max_code_repeat = 1 if (state == "recover" or diversity_ratio < 0.55 or dominant_code_share > 0.34) else 2

        profile = {
            "version": f"adaptive_t{total}_u{unique_codes}_r{raw_total}",
            "score_floor": _adaptive_floor(
                "score_floor",
                "base_score",
                _safe_float(EVOLUTION_MODE["default_score_floor"]),
                54.0,
                82.0,
                4.0,
            ),
            "volume_ratio_floor": _adaptive_floor(
                "volume_ratio_floor",
                "volume_ratio",
                _safe_float(EVOLUTION_MODE["default_volume_ratio_floor"]),
                0.9,
                4.0,
                0.25,
            ),
            "turnover_floor": _adaptive_floor(
                "turnover_floor",
                "turnover_pct",
                _safe_float(EVOLUTION_MODE["default_turnover_floor"]),
                1.0,
                12.0,
                0.35,
            ),
            "trend_floor": _adaptive_floor(
                "trend_floor",
                "trend_alignment",
                _normalize_trend_ratio(EVOLUTION_MODE.get("default_trend_floor"), 0.35),
                0.15,
                0.85,
                0.06,
                normalizer=_normalize_trend_ratio,
            ),
            "confidence_floor": _adaptive_floor(
                "confidence_floor",
                "data_confidence",
                _safe_float(EVOLUTION_MODE["default_confidence_floor"]),
                0.35,
                0.9,
                0.03,
            ),
            "max_distance_to_high": _adaptive_ceiling(
                "max_distance_to_high",
                "distance_to_high_20d_pct",
                _safe_float(EVOLUTION_MODE["default_max_distance_to_high"]),
                6.0,
                35.0,
                1.5,
            ),
            "preferred_pick_types": preferred_pick_types,
            "avoid_pick_types": avoid_pick_types,
            "preferred_zones": preferred_zones,
            "preferred_emotions": preferred_emotions,
            "pick_type_bias": pick_type_bias,
            "factor_bias": factor_bias,
            "exploration_rate": exploration_rate,
            "max_code_repeat": max_code_repeat,
            "last_state": state,
        }

        patterns = self._summarize_patterns(trades)
        patterns.extend(sorted(factor_rows, key=lambda item: abs(_safe_float(item["score"])), reverse=True)[:4])
        patterns.sort(key=lambda item: abs(_safe_float(item.get("score"))), reverse=True)
        patterns = patterns[:10]

        top_factor_msgs = [
            f"{name}:{value:+.2f}"
            for name, value in sorted(factor_bias.items(), key=lambda item: abs(item[1]), reverse=True)[:4]
        ]
        analysis_lines = [
            f"raw trades: {raw_total}",
            f"normalized trades: {total}",
            f"unique codes: {unique_codes}",
            f"diversity ratio: {diversity_ratio:.2f}",
            f"dominant code share: {dominant_code_share:.2f}",
            f"state: {state}",
            f"win rate: {win_rate * 100:.1f}%",
            f"profit ratio: {profit_ratio:.2f}",
            f"realized pnl: {total_pnl:+.2f}",
            f"exploration rate: {exploration_rate:.2f}",
            f"max code repeat: {max_code_repeat}",
            f"repeat hotspots: {', '.join(normalization.get('repeat_hotspots') or []) if normalization.get('repeat_hotspots') else 'none'}",
            f"preferred pick types: {', '.join(preferred_pick_types) if preferred_pick_types else 'none'}",
            f"avoid pick types: {', '.join(avoid_pick_types) if avoid_pick_types else 'none'}",
            f"factor bias: {', '.join(top_factor_msgs) if top_factor_msgs else 'none'}",
            f"new score floor: {profile['score_floor']:.1f}",
            f"new volume floor: {profile['volume_ratio_floor']:.2f}",
            f"new trend floor: {_format_trend_ratio(profile['trend_floor'])}",
            f"new confidence floor: {profile['confidence_floor']:.2f}",
        ]
        summary = {
            "trades": total,
            "raw_trades": raw_total,
            "normalized_trades": total,
            "unique_codes": unique_codes,
            "diversity_ratio": round(diversity_ratio, 4),
            "dominant_code_share": round(dominant_code_share, 4),
            "compression_ratio": normalization.get("compression_ratio", 1.0),
            "win_rate": round(win_rate, 4),
            "profit_ratio": round(profit_ratio, 2),
            "total_pnl": round(total_pnl, 2),
            "avg_win_pct": round(avg_win, 2),
            "avg_loss_pct": round(avg_loss, 2),
            "state": state,
            "repeat_hotspots": list(normalization.get("repeat_hotspots") or []),
        }
        return profile, patterns, "\n".join(analysis_lines), summary

    def _summarize_patterns(self, trades: List[EvolutionPaperTrade]) -> list[Dict[str, Any]]:
        metrics: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: {
            "samples": 0,
            "wins": 0,
            "pnl_pct_sum": 0.0,
        })
        for trade in trades:
            ctx = dict(trade.context or {})
            keys = [
                ("pick_type", str(trade.pick_type or ctx.get("pick_type") or "--")),
                ("zone", str(trade.zone or ctx.get("zone") or "--")),
                ("emotion", str(trade.emotion or ctx.get("emotion") or "--")),
                ("score_band", _bucket(_safe_float(ctx.get("base_score")), [(75, "<75"), (82, "75-82"), (88, "82-88"), (999, "88+")], "88+")),
                ("vr_band", _bucket(_safe_float(ctx.get("volume_ratio")), [(1.5, "<1.5"), (2.4, "1.5-2.4"), (3.5, "2.4-3.5"), (999, "3.5+")], "3.5+")),
            ]
            for dim, value in keys:
                stat = metrics[(dim, value)]
                stat["samples"] += 1
                if _safe_float(trade.pnl) > 0:
                    stat["wins"] += 1
                stat["pnl_pct_sum"] += _safe_float(trade.pnl_pct)

        rows: list[Dict[str, Any]] = []
        min_group_sample = int(EVOLUTION_MODE["min_group_sample"])
        for (dim, value), stat in metrics.items():
            samples = int(stat["samples"])
            if samples < min_group_sample:
                continue
            avg_pnl_pct = stat["pnl_pct_sum"] / samples if samples else 0.0
            win_rate = stat["wins"] / samples if samples else 0.0
            score = avg_pnl_pct * (0.6 + win_rate) * math.log(samples + 1)
            rows.append({
                "dimension": dim,
                "value": value,
                "samples": samples,
                "win_rate": round(win_rate, 3),
                "avg_pnl_pct": round(avg_pnl_pct, 2),
                "bias": "prefer" if avg_pnl_pct >= 0 else "avoid",
                "score": round(score, 3),
            })

        rows.sort(key=lambda item: abs(_safe_float(item["score"])), reverse=True)
        return rows[:8]

    def _save_snapshot(self, payload: Dict[str, Any]) -> None:
        session = get_session()
        try:
            session.add(MarketSnapshot(
                snapshot_type="evolution_mode",
                timestamp=_now(),
                date=_now().date(),
                data=payload,
            ))
            session.commit()
        except Exception as exc:
            session.rollback()
            logger.debug(f"[evolution_mode] snapshot save failed: {exc}")
        finally:
            session.close()
