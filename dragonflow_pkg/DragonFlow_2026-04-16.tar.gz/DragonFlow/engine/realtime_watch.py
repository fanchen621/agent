from __future__ import annotations

import datetime
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# 让 DragonFlow 根目录可被导入
_engine_dir = Path(__file__).parent.resolve()
_root_dir = _engine_dir.parent
if str(_root_dir) not in sys.path:
    sys.path.insert(0, str(_root_dir))

from loguru import logger

from feeds.akshare_data import compute_stock_features, get_all_stocks_spot, get_stock_advanced_factors, get_zt_pool
from feeds.resilient import resilient_fetch_stocks
from models import MarketSnapshot, Position, WatchList, get_session
from strategy.adaptive_selector import build_candidate, rank_candidates
from strategy.trade_rules import build_trade_plan


class RealtimeWatchEngine:
    def __init__(
        self,
        refresh_interval: int = 10,
        spot_limit: int = 180,
        feature_limit: int = 70,
        advanced_limit: int = 18,
        candidate_limit: int = 8,
        exploration_limit: int = 24,
    ):
        self.refresh_interval = refresh_interval
        self.spot_limit = spot_limit
        self.feature_limit = feature_limit
        self.advanced_limit = advanced_limit
        self.candidate_limit = candidate_limit
        self.exploration_limit = max(exploration_limit, candidate_limit)
        self.last_refresh_at = 0.0
        self._latest: Dict = {}
        self._feature_cache: Dict[str, Tuple[float, Dict]] = {}
        self._refresh_latency_ms = 0.0
        self._slow_refresh_streak = 0

    @property
    def latest(self) -> Dict:
        return dict(self._latest)

    def maybe_refresh(
        self,
        zone: str,
        emotion: str,
        sentiment_modifier: float = 1.0,
        force: bool = False,
    ) -> Dict:
        now = time.time()
        if not force and now - self.last_refresh_at < self.refresh_interval:
            return self.latest
        snapshot = self.refresh(zone=zone, emotion=emotion, sentiment_modifier=sentiment_modifier)
        self.last_refresh_at = now
        return snapshot

    def refresh(
        self,
        zone: str,
        emotion: str,
        sentiment_modifier: float = 1.0,
    ) -> Dict:
        start = time.perf_counter()
        board_map = self._load_board_map()
        watch_entries, positions = self._load_db_context()
        row_map = self._load_market_rows(board_map, watch_entries, positions)
        feature_map = self._load_feature_map(row_map, watch_entries, positions, board_map)

        candidates = []
        for code, row in row_map.items():
            features = feature_map.get(code, {})
            board_height = int(board_map.get(code, {}).get("board_height", 0))
            is_limit_up = int(board_map.get(code, {}).get("is_limit_up", 0))
            theme_rank = int(board_map.get(code, {}).get("theme_rank", 3))
            factor_blob = dict(features)
            factor_blob["turnover_pct"] = float(row.get("turnover_pct", 0.0) or 0.0)
            factor_blob["volume_ratio"] = float(row.get("volume_ratio", 0.0) or 0.0)
            if factor_blob.get("stock_activity_score", 0) == 0:
                activity_score = 0.0
                activity_score += min(float(factor_blob.get("volatility_20d_pct", 0.0) or 0.0) / 1.2, 4.0)
                activity_score += min(float(factor_blob["turnover_pct"]) / 4.0, 3.0)
                factor_blob["stock_activity_score"] = round(activity_score, 2)
            candidate = build_candidate(
                code=code,
                name=row.get("name", ""),
                sector=row.get("sector", ""),
                close=row.get("price", 0.0),
                change_pct=row.get("change_pct", 0.0),
                volume_ratio=row.get("volume_ratio", 0.0),
                turnover_pct=row.get("turnover_pct", 0.0),
                breakout_20d=features.get("breakout_20d", 0),
                from_60d_low_pct=features.get("from_60d_low_pct", 0.0),
                board_height=board_height,
                is_limit_up=is_limit_up,
                is_one_wall=1 if is_limit_up and float(row.get("turnover_pct", 0.0) or 0.0) < 2.5 else 0,
                theme_rank=theme_rank,
                amount_100m=self._to_amount_100m(row.get("amount", 0.0)),
                distance_to_high_20d_pct=features.get("distance_to_high_20d_pct", 0.0),
                range_position_pct=features.get("range_position_pct", 0.0),
                base_tightness_pct=features.get("base_tightness_pct", 0.0),
                vol_contraction_ratio=features.get("vol_contraction_ratio", 0.0),
                ma10=features.get("ma10", 0.0),
                ma20=features.get("ma20", 0.0),
                ma20_slope_pct=features.get("ma20_slope_pct", 0.0),
                trend_alignment=features.get("trend_alignment", 0.0),
                setup_quality=features.get("setup_quality", 0.0),
                factors=factor_blob,
            )
            candidates.append(candidate)

        picks = rank_candidates(
            candidates=candidates,
            zone=zone,
            emotion=emotion,
            sentiment_modifier=sentiment_modifier,
            live_mode=True,
            limit=self.candidate_limit,
        )

        exploration_picks, exploration_floor = self._rank_exploration_picks(
            candidates=candidates,
            zone=zone,
            emotion=emotion,
            sentiment_modifier=sentiment_modifier,
        )

        def _build_plan(pick, source: str):
            return build_trade_plan(
                stock=pick.stock,
                zone=zone,
                emotion=emotion,
                pick_type=pick.pick_type,
                score=pick.score,
                reasons=pick.reasons,
                breakdown=pick.breakdown,
                source=source,
            )

        live_plans = [_build_plan(pick, "realtime_watch") for pick in picks]
        live_plan_map = {plan.code: plan for plan in live_plans}

        def _to_candidate_row(pick, plan, source: str):
            return {
                "code": pick.stock.code,
                "name": pick.stock.name,
                "pct": pick.stock.change_pct,
                "change_pct": pick.stock.change_pct,
                "price": pick.stock.close,
                "amount_100m": pick.stock.amount_100m,
                "pick_type": pick.pick_type,
                "score": pick.score,
                "source": source,
                "entry_price": plan.entry_price,
                "stop_price": plan.stop_price,
                "tp1_price": plan.tp1_price,
                "tp2_price": plan.tp2_price,
                "volume_ratio": pick.stock.volume_ratio,
                "turnover_pct": pick.stock.turnover_pct,
                "from_60d_low_pct": pick.stock.from_60d_low_pct,
                "distance_to_high_20d_pct": pick.stock.distance_to_high_20d_pct,
                "range_position_pct": pick.stock.range_position_pct,
                "base_tightness_pct": pick.stock.base_tightness_pct,
                "vol_contraction_ratio": pick.stock.vol_contraction_ratio,
                "trend_alignment": pick.stock.trend_alignment,
                "main_net_inflow_20d_100m": pick.stock.factors.get("main_net_inflow_20d_100m", 0.0),
                "pe_ttm": pick.stock.factors.get("pe_ttm", 0.0),
                "comment_score": pick.stock.factors.get("comment_score", 0.0),
                "chip_concentration_pct": pick.stock.factors.get("chip_concentration_pct", 0.0),
                "stock_sentiment_rsi": pick.stock.factors.get("stock_sentiment_rsi", 0.0),
                "board_height": pick.stock.board_height,
                "multi_factor_score": pick.breakdown.get("multi_factor_score", 0.0),
                "multi_factor_grade": pick.breakdown.get("multi_factor_grade", ""),
                "target_position_pct": plan.target_position_pct,
                "hold_days_max": plan.hold_days_max,
                "source_name": row_map.get(pick.stock.code, {}).get("source_name", ""),
                "data_confidence": row_map.get(pick.stock.code, {}).get("data_confidence", 0.0),
                "consensus_gap_pct": row_map.get(pick.stock.code, {}).get("consensus_gap_pct"),
                "quote_age_sec": row_map.get(pick.stock.code, {}).get("quote_age_sec", 0.0),
                "reason": " | ".join(pick.reasons[:4]),
                "breakdown": pick.breakdown,
            }

        candidate_rows = [
            _to_candidate_row(pick, plan, "realtime_watch")
            for pick, plan in zip(picks, live_plans)
        ]

        evolution_rows = []
        seen_codes = set()
        for pick in exploration_picks:
            plan = live_plan_map.get(pick.stock.code) or _build_plan(pick, "evolution_watch")
            evolution_rows.append(_to_candidate_row(pick, plan, "evolution_watch"))
            seen_codes.add(pick.stock.code)

        snapshot = {
            "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "zone": zone,
            "emotion": emotion,
            "candidate_count": len(candidate_rows),
            "evolution_candidate_count": len(evolution_rows),
            "exploration_floor": exploration_floor,
            "universe_size": len(candidates),
            "watchlist_size": len(watch_entries),
            "position_size": len(positions),
            "feature_limit_used": self._effective_feature_limit(),
            "advanced_limit_used": self._effective_advanced_limit(),
            "candidates": candidate_rows,
            "evolution_candidates": evolution_rows,
            "plans": live_plans,
            "latency_ms": round((time.perf_counter() - start) * 1000, 1),
        }
        self._latest = snapshot
        self._refresh_latency_ms = float(snapshot["latency_ms"])
        if self._refresh_latency_ms >= 45000:
            self._slow_refresh_streak += 1
        else:
            self._slow_refresh_streak = 0
        self._save_snapshot({
            "ts": snapshot["ts"],
            "zone": snapshot["zone"],
            "emotion": snapshot["emotion"],
            "candidate_count": snapshot["candidate_count"],
            "universe_size": snapshot["universe_size"],
            "watchlist_size": snapshot["watchlist_size"],
            "position_size": snapshot["position_size"],
            "candidates": candidate_rows,
            "evolution_candidate_count": len(evolution_rows),
            "exploration_floor": exploration_floor,
            "feature_limit_used": snapshot["feature_limit_used"],
            "advanced_limit_used": snapshot["advanced_limit_used"],
            "plan_count": len(live_plans),
            "latency_ms": snapshot["latency_ms"],
        }, zone, emotion)
        logger.info(
            f"[realtime_watch] {len(candidate_rows)} live / {len(evolution_rows)} evolution candidates "
            f"from {len(candidates)} symbols in {snapshot['latency_ms']:.1f}ms "
            f"(feature={snapshot['feature_limit_used']} adv={snapshot['advanced_limit_used']})"
        )
        return snapshot

    def _load_db_context(self) -> Tuple[List[WatchList], List[Position]]:
        session = get_session()
        try:
            today = datetime.date.today()
            watch_entries = session.query(WatchList).filter_by(date=today).filter(
                WatchList.status.in_(["pending", "watching"])
            ).all()
            positions = session.query(Position).all()
            return watch_entries, positions
        finally:
            session.close()

    def _load_board_map(self) -> Dict[str, Dict]:
        board_map: Dict[str, Dict] = {}
        zt_df = get_zt_pool()
        if zt_df.empty:
            return board_map

        code_col = "代码" if "代码" in zt_df.columns else ("code" if "code" in zt_df.columns else None)
        name_col = "名称" if "名称" in zt_df.columns else ("name" if "name" in zt_df.columns else None)
        if code_col is None:
            return board_map

        board_col = None
        for col in ("连板数", "连板天数", "days", "连续涨停天数"):
            if col in zt_df.columns:
                board_col = col
                break

        sorted_rows = []
        for _, row in zt_df.iterrows():
            code = str(row.get(code_col, "")).replace("sh", "").replace("sz", "")
            if not code:
                continue
            board_height = int(float(row.get(board_col, 1) or 1)) if board_col else 1
            sorted_rows.append((code, board_height, str(row.get(name_col, ""))))

        sorted_rows.sort(key=lambda item: item[1], reverse=True)
        for idx, (code, board_height, name) in enumerate(sorted_rows, start=1):
            board_map[code] = {
                "board_height": board_height,
                "is_limit_up": 1,
                "theme_rank": min(idx, 5),
                "name": name,
            }
        return board_map

    def _load_market_rows(
        self,
        board_map: Dict[str, Dict],
        watch_entries: List[WatchList],
        positions: List[Position],
    ) -> Dict[str, Dict]:
        row_map: Dict[str, Dict] = {}

        def merge_rows(rows):
            for row in rows:
                code = str(row.get("code", "")).replace("sh", "").replace("sz", "")
                if not code:
                    continue
                existing = row_map.get(code, {})
                confidence = row.get("data_confidence", existing.get("data_confidence", 0.72))
                gap_pct = row.get("consensus_gap_pct", existing.get("consensus_gap_pct"))
                row_map[code] = {
                    "code": code,
                    "name": row.get("name") or existing.get("name", ""),
                    "price": float(row.get("price", existing.get("price", 0)) or 0),
                    "change_pct": float(row.get("change_pct", existing.get("change_pct", 0)) or 0),
                    "volume_ratio": float(row.get("volume_ratio", existing.get("volume_ratio", 0)) or 0),
                    "turnover_pct": float(row.get("turnover_pct", existing.get("turnover_pct", 0)) or 0),
                    "amount": float(row.get("amount", existing.get("amount", 0)) or 0),
                    "sector": row.get("sector") or existing.get("sector", ""),
                    "source_name": row.get("source_name") or existing.get("source_name", "spot_aggregate"),
                    "data_confidence": float(confidence or 0.72),
                    "consensus_gap_pct": None if gap_pct is None else float(gap_pct),
                    "quote_age_sec": float(row.get("quote_age_sec", existing.get("quote_age_sec", 0)) or 0),
                }

        spot_amount = get_all_stocks_spot(limit=self.spot_limit, sort_field="f6")
        if not spot_amount.empty:
            merge_rows(spot_amount.to_dict(orient="records"))

        spot_change = get_all_stocks_spot(limit=max(80, self.spot_limit // 2), sort_field="f3")
        if not spot_change.empty:
            merge_rows(spot_change.to_dict(orient="records"))

        spot_turnover = get_all_stocks_spot(limit=max(80, self.spot_limit // 2), sort_field="f8")
        if not spot_turnover.empty:
            merge_rows(spot_turnover.to_dict(orient="records"))

        focus_codes = {
            entry.code.replace("sh", "").replace("sz", "") for entry in watch_entries
        }
        focus_codes.update(pos.code.replace("sh", "").replace("sz", "") for pos in positions)
        focus_codes.update(board_map.keys())

        missing_codes = [code for code in focus_codes if code and code not in row_map]
        if missing_codes:
            realtime_map = resilient_fetch_stocks(missing_codes)
            merge_rows(realtime_map.values())

        return row_map

    def _load_feature_map(
        self,
        row_map: Dict[str, Dict],
        watch_entries: List[WatchList],
        positions: List[Position],
        board_map: Dict[str, Dict],
    ) -> Dict[str, Dict]:
        feature_limit = self._effective_feature_limit()
        advanced_limit = self._effective_advanced_limit()
        priority_codes: List[str] = []
        for entry in watch_entries:
            code = entry.code.replace("sh", "").replace("sz", "")
            if code and code not in priority_codes:
                priority_codes.append(code)
        for pos in positions:
            code = pos.code.replace("sh", "").replace("sz", "")
            if code and code not in priority_codes:
                priority_codes.append(code)
        for code in sorted(board_map, key=lambda item: board_map[item].get("board_height", 0), reverse=True):
            if code not in priority_codes:
                priority_codes.append(code)

        sorted_rows = sorted(
            row_map.values(),
            key=lambda row: (
                float(row.get("change_pct", 0) or 0),
                float(row.get("amount", 0) or 0),
            ),
            reverse=True,
        )
        for row in sorted_rows:
            code = str(row.get("code", ""))
            if code and code not in priority_codes:
                priority_codes.append(code)

        feature_map: Dict[str, Dict] = {}
        for idx, code in enumerate(priority_codes[: feature_limit]):
            feature = self._get_cached_feature(code, row_map.get(code, {}))
            if feature:
                if idx < advanced_limit:
                    feature.update(get_stock_advanced_factors(code, row_map.get(code, {}).get("name", "")))
                feature_map[code] = feature
        return feature_map

    def _effective_feature_limit(self) -> int:
        base = max(1, int(self.feature_limit))
        if self._slow_refresh_streak >= 2 or self._refresh_latency_ms >= 90000:
            return min(base, max(16, int(base * 0.5)))
        if self._refresh_latency_ms >= 45000:
            return min(base, max(24, int(base * 0.7)))
        return base

    def _effective_advanced_limit(self) -> int:
        base = max(1, int(self.advanced_limit))
        if self._slow_refresh_streak >= 2 or self._refresh_latency_ms >= 90000:
            return min(base, max(6, int(base * 0.45)))
        if self._refresh_latency_ms >= 45000:
            return min(base, max(8, int(base * 0.7)))
        return base

    def _rank_exploration_picks(
        self,
        candidates,
        zone: str,
        emotion: str,
        sentiment_modifier: float,
    ):
        from config import BUY_MIN_SCORE

        base_floor = max(54.0, float(BUY_MIN_SCORE) - 10.0)
        floors = [
            base_floor,
            max(48.0, base_floor - 6.0),
            max(42.0, base_floor - 12.0),
        ]
        for idx, floor in enumerate(floors):
            picks = rank_candidates(
                candidates=candidates,
                zone=zone,
                emotion=emotion,
                sentiment_modifier=sentiment_modifier,
                live_mode=True,
                limit=self.exploration_limit,
                score_floor_override=floor,
                quiet=idx < len(floors) - 1,
            )
            if picks:
                if idx > 0:
                    logger.info(
                        f"[realtime_watch] evolution fallback floor={floor:.1f} "
                        f"recovered {len(picks)} picks"
                    )
                return picks, floor

        logger.info(
            "[realtime_watch] no evolution candidates after fallback "
            + ",".join(f"{floor:.1f}" for floor in floors)
        )
        return [], floors[-1]

    def _get_cached_feature(self, code: str, row: Dict) -> Optional[Dict]:
        now = time.time()
        cached = self._feature_cache.get(code)
        if cached and now - cached[0] < 600:
            return cached[1]

        feature = compute_stock_features(
            code,
            current_price=float(row.get("price", 0.0) or 0.0),
            current_change_pct=float(row.get("change_pct", 0.0) or 0.0),
        )
        if feature:
            self._feature_cache[code] = (now, feature)
        return feature

    def _save_snapshot(self, snapshot: Dict, zone: str, emotion: str) -> None:
        session = get_session()
        try:
            session.add(MarketSnapshot(
                snapshot_type="realtime_watch",
                timestamp=datetime.datetime.now(),
                date=datetime.date.today(),
                zone=zone,
                emotion=emotion,
                data=snapshot,
            ))
            session.commit()
        except Exception as exc:
            session.rollback()
            logger.debug(f"[realtime_watch] snapshot save failed: {exc}")
        finally:
            session.close()

    @staticmethod
    def _to_amount_100m(amount: float) -> float:
        amount_value = float(amount or 0.0)
        return round(amount_value / 1e8, 2) if amount_value > 1e6 else round(amount_value, 2)

if __name__ == "__main__":
    import time, signal, json, urllib.request

    watch = RealtimeWatchEngine()
    logger.info("[realtime_watch] 启动独立监控模式")

    def shutdown(*a):
        logger.info("[realtime_watch] 收到停止信号，退出")
        exit(0)
    signal.signal(signal.SIGTERM, shutdown)

    def get_zone_emotion():
        """从DragonFlow API获取当前zone/emotion（由scheduler写入）"""
        try:
            req = urllib.request.Request(
                "http://127.0.0.1:8099/api/state",
                headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                state = json.loads(resp.read())
            return (
                state.get("current_zone", "attack"),
                state.get("current_emotion", "neutral"),
            )
        except Exception as exc:
            logger.debug(f"[realtime_watch] get_zone_emotion失败: {exc}")
            return "attack", "neutral"

    while True:
        try:
            zone, emotion = get_zone_emotion()
            snapshot = watch.maybe_refresh(zone=zone, emotion=emotion)
            if snapshot:
                candidates = snapshot.get("candidates", [])
                logger.info(f"[realtime_watch] zone={zone} emotion={emotion} 候选:{len(candidates)}")
            else:
                logger.debug("[realtime_watch] maybe_refresh返回空")
        except Exception as exc:
            logger.error(f"[realtime_watch] 刷新异常: {exc}")
        time.sleep(300)
