from __future__ import annotations

import asyncio
import datetime
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import List, Optional

# 确保父目录在 sys.path（修复 systemd 启动时 ModuleNotFoundError: engine）
_FILE_DIR = Path(__file__).resolve().parent
DRAGONFLOW_ROOT = _FILE_DIR.parent
if str(DRAGONFLOW_ROOT) not in sys.path:
    sys.path.insert(0, str(DRAGONFLOW_ROOT))

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from loguru import logger

from engine.autopilot import get_runtime
from models import MarketSnapshot, Position, TradeRecord, WatchList, get_session
from openclaw_adapter import get_dashboard_url, register_ws_broadcast


app = FastAPI(title="DragonFlow", version="2.2")

_ws_clients: List[WebSocket] = []
_main_loop: Optional[asyncio.AbstractEventLoop] = None

# 简易内存缓存（减少重复查询和外部API调用）
_cache: dict = {}
SNAPSHOT_TTL_SECONDS = 2.0


def _cached(key: str, ttl: float, fn):
    import time
    now = time.time()
    if key in _cache:
        ts, val = _cache[key]
        if now - ts < ttl:
            return val
    val = fn()
    _cache[key] = (now, val)
    return val


def _warm_dashboard_caches():
    from feeds.market_snapshot import build_analysis_snapshot

    try:
        _cached("snapshot", SNAPSHOT_TTL_SECONDS, build_analysis_snapshot)
    except Exception as exc:
        logger.debug(f"[startup] snapshot warmup failed: {exc}")


async def ws_broadcast(message: str):
    dead = []
    for ws in _ws_clients:
        try:
            await ws.send_text(message)
        except Exception:
            dead.append(ws)
    for ws in dead:
        if ws in _ws_clients:
            _ws_clients.remove(ws)


def _threadsafe_broadcast(message: str):
    if _main_loop is None:
        return
    try:
        asyncio.run_coroutine_threadsafe(ws_broadcast(message), _main_loop)
    except Exception:
        pass


register_ws_broadcast(ws_broadcast)


@app.on_event("startup")
async def on_startup():
    global _main_loop
    _main_loop = asyncio.get_running_loop()
    try:
        get_runtime().set_broadcast(_threadsafe_broadcast)
    except Exception as exc:
        logger.warning(f"[startup] autopilot broadcast bind failed: {exc}")
    if os.environ.get("DRAGONFLOW_ENABLE_SCHEDULER", "0") == "1":
        try:
            from scheduler import start_scheduler
            start_scheduler()
        except Exception as exc:
            logger.error(f"[startup] scheduler start failed: {exc}")
    logger.info("[DragonFlow Dashboard] 启动完成")


@app.on_event("startup")
async def warm_dashboard_caches_on_startup():
    await asyncio.to_thread(_warm_dashboard_caches)


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    _ws_clients.append(ws)
    logger.info(f"[ws] connected clients={len(_ws_clients)}")
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        if ws in _ws_clients:
            _ws_clients.remove(ws)
        logger.info(f"[ws] disconnected clients={len(_ws_clients)}")


@app.get("/", response_class=HTMLResponse)
async def dashboard():
    html_path = Path(__file__).parent / "templates" / "dashboard.html"
    if html_path.exists():
        return html_path.read_text(encoding="utf-8")
    return "<h1>DragonFlow Dashboard</h1>"


def _latest_realtime_watch(session) -> dict:
    snapshot = session.query(MarketSnapshot).filter(
        MarketSnapshot.snapshot_type == "realtime_watch"
    ).order_by(MarketSnapshot.timestamp.desc()).first()
    return snapshot.data if snapshot and snapshot.data else {}


def _positions_payload() -> list:
    session = get_session()
    try:
        return [{
            "code": pos.code,
            "name": pos.name,
            "buy_price": pos.buy_price,
            "current_price": pos.current_price,
            "shares": pos.shares,
            "pnl": pos.current_pnl,
            "pnl_pct": pos.current_pnl_pct,
            "hold_days": pos.hold_days,
            "strategy": pos.strategy,
            "pick_type": pos.pick_type,
            "reason": pos.reason,
            "stop_loss": pos.stop_loss,
            "tp1": pos.take_profit_1,
            "tp2": pos.take_profit_2,
        } for pos in session.query(Position).all()]
    finally:
        session.close()


def _trades_payload(limit: int = 12) -> list:
    session = get_session()
    try:
        trades = session.query(TradeRecord).order_by(TradeRecord.timestamp.desc()).limit(limit).all()
        return [{
            "date": str(trade.date),
            "code": trade.code,
            "name": trade.name,
            "direction": trade.direction,
            "price": trade.price,
            "shares": trade.shares,
            "pnl": trade.pnl,
            "pnl_pct": trade.pnl_pct,
            "signal_type": trade.signal_type,
            "zone": trade.zone,
        } for trade in trades]
    finally:
        session.close()


def _watchlist_payload() -> list:
    session = get_session()
    try:
        today = datetime.date.today()
        entries = session.query(WatchList).filter(
            WatchList.date >= today
        ).order_by(WatchList.date.desc(), WatchList.score.desc()).all()
        realtime = _latest_realtime_watch(session)
        merged = []
        seen = set()
        for item in realtime.get("candidates", []):
            code = item.get("code", "")
            if not code or code in seen:
                continue
            merged.append({
                **item,
                "status": "live",
                "source": "realtime_watch",
                "date": today.isoformat(),
                "code": code,
            })
            seen.add(code)
        for entry in entries:
            if entry.code in seen:
                continue
            merged.append({
                "date": str(entry.date),
                "code": entry.code,
                "name": entry.name,
                "pick_type": entry.pick_type,
                "score": entry.score,
                "entry_price": entry.entry_price,
                "stop_price": entry.stop_price,
                "tp1_price": entry.tp1_price,
                "tp2_price": entry.tp2_price,
                "reason": entry.reason,
                "volume_ratio": entry.volume_ratio,
                "turnover_pct": entry.turnover_pct,
                "from_60d_low_pct": entry.from_60d_low_pct,
                "status": entry.status,
                "source": entry.source,
            })
            seen.add(entry.code)
        return merged
    finally:
        session.close()


# ─── 兼容接口 ────────────────────────────────────────────────────────────────

@app.get("/api/status")
async def api_status():
    from openclaw_adapter import get_state
    state = get_state()
    session = get_session()
    try:
        realtime = _latest_realtime_watch(session)
        state["live_candidate_count"] = len(realtime.get("candidates", []))
        state["dashboard_url"] = get_dashboard_url()
        return state
    finally:
        session.close()


@app.get("/api/positions")
async def api_positions():
    return _positions_payload()


@app.get("/api/trades")
async def api_trades(limit: int = 50):
    return _trades_payload(limit)


@app.get("/api/realtime_candidates")
async def api_realtime_candidates():
    session = get_session()
    try:
        return _latest_realtime_watch(session).get("candidates", [])
    finally:
        session.close()


@app.get("/api/watchlist")
async def api_watchlist():
    return _watchlist_payload()


@app.get("/api/stats")
async def api_stats():
    from evolution.statistics import get_recent_stats
    return _cached("stats", 10.0, lambda: get_recent_stats(20))


@app.get("/api/evolution")
async def api_evolution():
    from evolution.optimizer import get_evolution_history
    return _cached("evolution", 30.0, lambda: get_evolution_history(20))


@app.get("/api/evolution_mode")
async def api_evolution_mode():
    from engine.evolution_mode import get_evolution_mode_status
    return _cached("evolution_mode", 2.0, get_evolution_mode_status)


@app.get("/api/backtest_status")
async def api_backtest_status():
    from evolution.optimizer import get_dynamic_backtest_status
    return _cached("bt_status", 10.0, get_dynamic_backtest_status)


@app.get("/api/backtest_report")
async def api_backtest_report():
    """最近的每日回测报告（由调度任务写入 data/reports/ 目录）。"""
    try:
        from evolution.optimizer import get_latest_backtest_report
        return get_latest_backtest_report() or {"message": "no backtest report yet"}
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/snapshot")
async def api_snapshot():
    from feeds.market_snapshot import build_analysis_snapshot

    def _build():
        try:
            return build_analysis_snapshot()
        except Exception:
            return {
                "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "source": "analysis_fallback",
                "indices": [],
                "zt_stats": {},
                "breadth": {},
                "main_flow_100m": 0.0,
                "sector_flow_top5": [],
            }

    snapshot = await asyncio.to_thread(lambda: _cached("snapshot", SNAPSHOT_TTL_SECONDS, _build))
    session = get_session()
    try:
        realtime = _latest_realtime_watch(session)
        snapshot["live_candidate_count"] = len(realtime.get("candidates", []))
        snapshot["live_candidates"] = realtime.get("candidates", [])[:8]
        return snapshot
    finally:
        session.close()


@app.get("/api/sentiment")
async def api_sentiment():
    from feeds.sentiment import get_market_sentiment
    return _cached("sentiment", 60.0, get_market_sentiment)


@app.get("/api/health")
async def api_health():
    from selfheal.diagnostics import run_health_check
    return _cached("health", 30.0, run_health_check)


@app.get("/api/sources")
async def api_sources():
    from feeds.proxy_engine import get_pool_status
    from feeds.resilient import get_active_sources, get_all_source_status, get_latest_data_quality
    from feeds.data_router import get_router
    router = get_router()
    return {
        "active": get_active_sources(),
        "sources": get_all_source_status(),
        "quality": get_latest_data_quality(),
        "proxy_pool": get_pool_status(),
        "data_router": router.get_status(),
    }


@app.get("/api/knowledge")
async def api_knowledge(limit: int = 30):
    from intelligence.knowledge_base import get_recent_knowledge
    return get_recent_knowledge(limit=limit)


@app.get("/api/sectors")
async def api_sectors():
    from feeds.akshare_data import get_sector_flow
    return _cached("sectors", 60.0, get_sector_flow)


# ─── 聚合接口：一次请求拉全部数据 ─────────────────────────────────────────────

@app.get("/api/dashboard")
async def api_dashboard():
    """
    聚合接口：Dashboard 轮询只需调用此一个接口，
    避免并行 11 个请求造成的延迟和抖动。
    """
    from evolution.statistics import get_recent_stats
    from evolution.optimizer import get_dynamic_backtest_status, get_evolution_history
    from engine.evolution_mode import get_evolution_mode_status
    from feeds.market_snapshot import build_analysis_snapshot
    from feeds.sentiment import get_market_sentiment
    from openclaw_adapter import get_state
    from selfheal.diagnostics import run_health_check

    def _gather_sync():
        result: dict = {}
        session = get_session()
        try:
            realtime = _latest_realtime_watch(session)
        finally:
            session.close()

        def _safe(label, fn, default):
            try:
                return fn()
            except Exception as exc:
                logger.debug(f"[api/dashboard] {label} failed: {exc}")
                return default

        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = {
                "status": pool.submit(_safe, "status", get_state, {}),
                "snapshot": pool.submit(
                    _safe,
                    "snapshot",
                    lambda: _cached("snapshot", SNAPSHOT_TTL_SECONDS, build_analysis_snapshot),
                    {"indices": [], "zt_stats": {}, "breadth": {}, "main_flow_100m": 0.0},
                ),
                "sentiment": pool.submit(
                    _safe,
                    "sentiment",
                    lambda: _cached("sentiment", 60.0, get_market_sentiment),
                    {},
                ),
                "positions": pool.submit(_safe, "positions", _positions_payload, []),
                "trades": pool.submit(_safe, "trades", lambda: _trades_payload(12), []),
                "watchlist": pool.submit(_safe, "watchlist", _watchlist_payload, []),
                "stats": pool.submit(
                    _safe,
                    "stats",
                    lambda: _cached("stats", 10.0, lambda: get_recent_stats(20)),
                    [],
                ),
                "backtest_status": pool.submit(
                    _safe,
                    "bt_status",
                    lambda: _cached("bt_status", 10.0, get_dynamic_backtest_status),
                    {},
                ),
                "evolution": pool.submit(
                    _safe,
                    "evolution",
                    lambda: _cached("evolution", 30.0, lambda: get_evolution_history(10)),
                    [],
                ),
                "evolution_mode": pool.submit(
                    _safe,
                    "evolution_mode",
                    lambda: _cached("evolution_mode", 2.0, get_evolution_mode_status),
                    {},
                ),
                "health": pool.submit(
                    _safe,
                    "health",
                    lambda: _cached("health", 30.0, run_health_check),
                    {},
                ),
            }
            for key, future in futures.items():
                result[key] = future.result()

        result["status"]["live_candidate_count"] = len(realtime.get("candidates", []))
        result["status"]["dashboard_url"] = get_dashboard_url()
        result["snapshot"]["live_candidate_count"] = len(realtime.get("candidates", []))
        result["realtime_candidates"] = realtime.get("candidates", [])
        result["ts"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return result

    payload = await asyncio.to_thread(_gather_sync)
    return JSONResponse(payload)


@app.get("/api/state")
async def api_state():
    """读取实时盯盘状态（由 realtime_watch.py 写入）"""
    state_file = DRAGONFLOW_ROOT / "data" / ".live_state.json"
    if state_file.exists():
        import json
        try:
            with open(state_file, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"error": "invalid state file"}
    return {"error": "no state file"}
