"""
多因子综合评分系统
═══════════════════════════════════════════════════════════════════════════
在 adaptive_selector 技术面评分基础上，叠加以下 11 个维度的加分/减分：

  1. 舆论 (sentiment)          - 雪球/股吧/东财评论 RSI、看多看空比
  2. 基本面 (fundamentals)     - ROE、营收增速、净利润增速、毛利率
  3. 筹码峰 (chip distribution) - 筹码集中度、距主力成本距离
  4. 股东人数 (shareholder)    - 股东户数变化率（减少为正面）
  5. 市盈率 (valuation)        - PE_TTM、PB、行业相对估值
  6. 近期利好/利空 (news)      - 公告事件、研报评级变化
  7. 股性 (personality)        - 历史波动率、换手活跃度、与大盘相关性
  8. 技术指标 (technical)      - 均线多头排列、MACD金叉、KDJ、RSI
  9. 行业增长逻辑 (industry)   - 行业景气度、订单、产能利用率
 10. 题材/板块 (theme/sector)  - 板块排名、资金流入、题材热度
 11. 主力持仓 (institutional)  - 北向资金持股、机构持股、龙虎榜、主力净流

每个维度独立打分 0-10，最终合成 multi_factor_score 0-100
再与 adaptive_selector 的 route_score 做加权融合（权重 55:45）

因子数据来源优先级：
  - stock.factors 字典（由 feeds/akshare_data 的 get_stock_advanced_factors 填充）
  - 无数据时降级为中性分 5.0，避免因数据缺失而误杀好票
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from loguru import logger


@dataclass
class FactorScore:
    name: str
    score: float          # 0-10
    weight: float         # 合成权重
    note: str = ""        # 解读说明


@dataclass
class MultiFactorResult:
    total_score: float                    # 0-100 综合得分
    grade: str                             # S/A/B/C/D
    factors: List[FactorScore] = field(default_factory=list)
    highlights: List[str] = field(default_factory=list)   # 利好亮点
    warnings: List[str] = field(default_factory=list)     # 风险提示
    recommendation: str = ""               # 最终建议


def _safe(factors: Dict, key: str, default: float = 0.0) -> float:
    try:
        v = factors.get(key, default)
        if v is None:
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def _clamp(v: float, lo: float = 0.0, hi: float = 10.0) -> float:
    return max(lo, min(hi, v))


# ─── 1. 舆论评分 ──────────────────────────────────────────────────────────────

def score_sentiment(factors: Dict) -> FactorScore:
    """
    股吧/雪球/东财评论的情绪 RSI。
    RSI 0.40-0.72 → 健康活跃（最高分）
    RSI < 0.25 或 > 0.85 → 极端（减分）
    """
    rsi = _safe(factors, "stock_sentiment_rsi", 0.5)
    comment_score = _safe(factors, "comment_score", 0.0)
    sentiment_adj = _safe(factors, "stock_sentiment_adj", 0.0)

    base = 5.0
    note_parts = []
    if 0.4 <= rsi <= 0.72:
        base += 2.5
        note_parts.append("情绪健康")
    elif 0.72 < rsi <= 0.85:
        base += 0.5
        note_parts.append("偏乐观")
    elif 0.25 <= rsi < 0.4:
        base += 1.2
        note_parts.append("偏悲观(反转机会)")
    elif rsi > 0.85:
        base -= 3.0
        note_parts.append("过度乐观")
    elif rsi < 0.25:
        base -= 1.0
        note_parts.append("极度恐慌")

    if comment_score > 15:
        base += 1.5
        note_parts.append("评论活跃")
    elif comment_score < -10:
        base -= 1.5
        note_parts.append("评论负面")

    if sentiment_adj > 3:
        base += 1.0
    elif sentiment_adj < -3:
        base -= 1.0

    return FactorScore(
        name="舆论",
        score=_clamp(base),
        weight=0.08,
        note=";".join(note_parts) or f"RSI={rsi:.2f}",
    )


# ─── 2. 基本面评分 ────────────────────────────────────────────────────────────

def score_fundamentals(factors: Dict) -> FactorScore:
    """
    ROE, 营收增速, 净利润增速, 毛利率
    短线对基本面不敏感，但至少需保证没有暴雷风险。
    """
    roe = _safe(factors, "roe_weighted", 0.0)
    revenue_yoy = _safe(factors, "revenue_yoy_pct", 0.0)
    profit_yoy = _safe(factors, "net_profit_yoy_pct", 0.0)
    gross_margin = _safe(factors, "gross_margin_pct", 0.0)

    base = 5.0
    notes = []
    if roe >= 15:
        base += 2.0; notes.append(f"ROE {roe:.1f}%优")
    elif roe >= 8:
        base += 1.0; notes.append(f"ROE {roe:.1f}%良")
    elif 0 < roe < 3:
        base -= 1.5; notes.append(f"ROE {roe:.1f}%弱")
    elif roe < 0:
        base -= 3.0; notes.append("亏损")

    if revenue_yoy >= 30:
        base += 1.5; notes.append(f"营收+{revenue_yoy:.0f}%")
    elif revenue_yoy >= 10:
        base += 0.5
    elif revenue_yoy < -10:
        base -= 1.5; notes.append("营收下滑")

    if profit_yoy >= 50:
        base += 1.8; notes.append(f"净利+{profit_yoy:.0f}%")
    elif profit_yoy >= 20:
        base += 0.8
    elif profit_yoy < -20:
        base -= 2.0; notes.append("净利下滑")

    if gross_margin >= 35:
        base += 0.5

    return FactorScore(
        name="基本面",
        score=_clamp(base),
        weight=0.10,
        note="; ".join(notes) or "基本面中性",
    )


# ─── 3. 筹码峰评分 ────────────────────────────────────────────────────────────

def score_chip_distribution(factors: Dict) -> FactorScore:
    """
    筹码集中度 + 距主力成本距离
    集中度高、距成本近 → 上涨阻力小
    """
    concentration = _safe(factors, "chip_concentration_pct", 0.0)
    distance = abs(_safe(factors, "chip_distance_pct", 0.0))
    cost_area = _safe(factors, "chip_cost_area_pct", 0.0)

    base = 5.0
    notes = []
    if concentration >= 45:
        base += 3.0; notes.append("筹码高度集中")
    elif concentration >= 30:
        base += 1.8; notes.append("筹码较集中")
    elif concentration < 15:
        base -= 1.5; notes.append("筹码分散")

    if distance <= 3:
        base += 2.0; notes.append("贴近成本")
    elif distance <= 8:
        base += 1.0
    elif distance >= 20:
        base -= 2.0; notes.append("远离成本")

    if 0 < cost_area <= 10:
        base += 1.0

    return FactorScore(
        name="筹码峰",
        score=_clamp(base),
        weight=0.09,
        note="; ".join(notes) or f"集中度 {concentration:.1f}%",
    )


# ─── 4. 股东人数评分 ──────────────────────────────────────────────────────────

def score_shareholder(factors: Dict) -> FactorScore:
    """
    股东户数减少 → 筹码向少数人集中 → 看多
    """
    change = _safe(factors, "holder_change_pct", 0.0)    # 较上季变化%
    holder_count = _safe(factors, "holder_count_10k", 0.0)  # 股东数(万)

    base = 5.0
    notes = []
    if change <= -10:
        base += 3.0; notes.append(f"股东数{change:.1f}%大减")
    elif change <= -3:
        base += 1.5; notes.append(f"股东数{change:.1f}%减少")
    elif change >= 15:
        base -= 2.5; notes.append(f"股东数+{change:.1f}%分散")
    elif change >= 5:
        base -= 1.0

    if 0 < holder_count <= 3:
        base += 1.0; notes.append("小盘筹码")
    elif holder_count > 15:
        base -= 0.5

    return FactorScore(
        name="股东人数",
        score=_clamp(base),
        weight=0.06,
        note="; ".join(notes) or "股东稳定",
    )


# ─── 5. 市盈率评分 ────────────────────────────────────────────────────────────

def score_valuation(factors: Dict) -> FactorScore:
    """
    PE_TTM + PB + 相对行业PE分位
    """
    pe = _safe(factors, "pe_ttm", 0.0)
    pb = _safe(factors, "pb", 0.0)
    industry_pe_percentile = _safe(factors, "industry_pe_percentile", 0.5)

    base = 5.0
    notes = []
    if 0 < pe <= 15:
        base += 2.5; notes.append(f"PE {pe:.0f}低估")
    elif 15 < pe <= 30:
        base += 1.5; notes.append(f"PE {pe:.0f}合理")
    elif 30 < pe <= 60:
        base += 0.2
    elif 60 < pe <= 120:
        base -= 1.5; notes.append(f"PE {pe:.0f}偏高")
    elif pe > 120:
        base -= 3.0; notes.append(f"PE {pe:.0f}泡沫")
    elif pe <= 0:
        base -= 2.5; notes.append("亏损无PE")

    if 0 < pb <= 2.5:
        base += 1.0
    elif pb > 10:
        base -= 1.5

    if industry_pe_percentile < 0.3:
        base += 1.0; notes.append("行业低估")
    elif industry_pe_percentile > 0.8:
        base -= 1.0

    return FactorScore(
        name="市盈率",
        score=_clamp(base),
        weight=0.07,
        note="; ".join(notes) or f"PE={pe:.1f}",
    )


# ─── 6. 近期利好/利空评分 ─────────────────────────────────────────────────────

def score_news_events(factors: Dict) -> FactorScore:
    """
    近 30 天公告事件、研报评级变化、订单公告等
    """
    positive = _safe(factors, "positive_news_count_30d", 0.0)
    negative = _safe(factors, "negative_news_count_30d", 0.0)
    rating_upgrade = _safe(factors, "rating_upgrades_30d", 0.0)
    rating_downgrade = _safe(factors, "rating_downgrades_30d", 0.0)
    big_order_count = _safe(factors, "big_order_announcements", 0.0)

    base = 5.0
    notes = []
    net_news = positive - negative
    if net_news >= 3:
        base += 2.5; notes.append(f"利好+{int(positive)}")
    elif net_news >= 1:
        base += 1.2
    elif net_news <= -3:
        base -= 2.5; notes.append(f"利空+{int(negative)}")
    elif net_news <= -1:
        base -= 1.2

    if rating_upgrade > 0:
        base += min(rating_upgrade * 0.8, 2.0); notes.append(f"上调评级{int(rating_upgrade)}")
    if rating_downgrade > 0:
        base -= min(rating_downgrade * 1.0, 2.5); notes.append(f"下调评级{int(rating_downgrade)}")
    if big_order_count > 0:
        base += min(big_order_count * 0.6, 1.5); notes.append("大订单")

    return FactorScore(
        name="利好利空",
        score=_clamp(base),
        weight=0.09,
        note="; ".join(notes) or "无重大事件",
    )


# ─── 7. 股性评分 ──────────────────────────────────────────────────────────────

def score_personality(factors: Dict) -> FactorScore:
    """
    历史活跃度、波动率、β系数、涨停敢死队关注度
    """
    activity = _safe(factors, "stock_activity_score", 0.0)
    volatility = _safe(factors, "volatility_20d_pct", 0.0)
    beta = _safe(factors, "beta_60d", 1.0)
    lhb_count = _safe(factors, "lhb_count_20d", 0.0)
    limit_up_20d = _safe(factors, "limit_up_count_20d", 0.0)

    base = 5.0
    notes = []
    if activity >= 7:
        base += 2.5; notes.append("股性活跃")
    elif activity >= 4:
        base += 1.2
    elif activity < 2:
        base -= 1.5; notes.append("股性呆滞")

    if 2.5 <= volatility <= 5.5:
        base += 1.0
    elif volatility > 8:
        base -= 1.0

    if 0.9 <= beta <= 1.6:
        base += 0.5

    if lhb_count >= 2:
        base += 1.5; notes.append(f"龙虎榜{int(lhb_count)}次")
    elif lhb_count >= 1:
        base += 0.8

    if limit_up_20d >= 3:
        base += 1.2; notes.append(f"20日{int(limit_up_20d)}涨停")

    return FactorScore(
        name="股性",
        score=_clamp(base),
        weight=0.08,
        note="; ".join(notes) or f"活跃度 {activity:.1f}",
    )


# ─── 8. 技术指标评分 ──────────────────────────────────────────────────────────

def score_technical(factors: Dict, stock) -> FactorScore:
    """
    均线多头、MACD金叉、KDJ、RSI、布林位置
    """
    trend_alignment = float(getattr(stock, "trend_alignment", 0) or 0)
    ma20_slope = float(getattr(stock, "ma20_slope_pct", 0) or 0)
    ma10 = float(getattr(stock, "ma10", 0) or 0)
    ma20 = float(getattr(stock, "ma20", 0) or 0)
    close = float(getattr(stock, "close", 0) or 0)
    macd_golden = _safe(factors, "macd_golden_cross", 0.0)
    macd_hist = _safe(factors, "macd_histogram", 0.0)
    kdj_j = _safe(factors, "kdj_j", 50.0)
    rsi14 = _safe(factors, "rsi_14", 50.0)
    breakout = int(getattr(stock, "breakout_20d", 0) or 0)

    base = 5.0
    notes = []

    # 均线多头排列
    if close > ma10 > ma20 > 0 and ma20_slope > 0.3:
        base += 2.5; notes.append("均线多头")
    elif close > ma20 > 0:
        base += 1.2
    elif 0 < close < ma20:
        base -= 1.5; notes.append("跌破20日")

    if trend_alignment >= 0.75:
        base += 1.0
    elif trend_alignment < 0.3:
        base -= 1.0

    # MACD
    if macd_golden > 0:
        base += 1.8; notes.append("MACD金叉")
    elif macd_hist > 0:
        base += 0.5
    elif macd_hist < -0.1:
        base -= 1.0

    # KDJ
    if 20 <= kdj_j <= 80:
        base += 0.5
    elif kdj_j > 90:
        base -= 1.5; notes.append("KDJ超买")
    elif kdj_j < 10:
        base += 1.0; notes.append("KDJ超卖")

    # RSI
    if 40 <= rsi14 <= 65:
        base += 0.8
    elif rsi14 > 80:
        base -= 1.5; notes.append("RSI超买")
    elif rsi14 < 25:
        base += 0.8

    # 突破
    if breakout == 1:
        base += 1.2; notes.append("突破20日")

    return FactorScore(
        name="技术指标",
        score=_clamp(base),
        weight=0.12,
        note="; ".join(notes) or "技术面中性",
    )


# ─── 9. 行业增长逻辑评分 ──────────────────────────────────────────────────────

def score_industry(factors: Dict) -> FactorScore:
    """
    行业景气度、订单增速、需求/供给缺口
    """
    prosperity = _safe(factors, "industry_prosperity", 5.0)        # 景气度 0-10
    order_growth = _safe(factors, "industry_order_yoy_pct", 0.0)    # 订单增速
    supply_gap = _safe(factors, "industry_supply_gap_pct", 0.0)     # 供需缺口
    cycle_phase = factors.get("industry_cycle_phase", "")           # expansion/peak/recession/recovery

    base = 5.0
    notes = []
    if prosperity >= 7:
        base += 2.0; notes.append(f"景气度{prosperity:.1f}")
    elif prosperity >= 5.5:
        base += 0.8
    elif prosperity < 3:
        base -= 2.0; notes.append("景气差")

    if order_growth >= 25:
        base += 2.0; notes.append(f"订单+{order_growth:.0f}%")
    elif order_growth >= 10:
        base += 1.0
    elif order_growth < -10:
        base -= 1.5

    if supply_gap >= 5:
        base += 1.5; notes.append("供需紧张")
    elif supply_gap <= -10:
        base -= 1.0

    if cycle_phase in ("expansion", "recovery"):
        base += 1.0; notes.append(f"{cycle_phase}期")
    elif cycle_phase == "recession":
        base -= 1.5

    return FactorScore(
        name="行业逻辑",
        score=_clamp(base),
        weight=0.10,
        note="; ".join(notes) or "行业平稳",
    )


# ─── 10. 题材/板块走势评分 ────────────────────────────────────────────────────

def score_theme_sector(factors: Dict, stock) -> FactorScore:
    """
    板块资金流入、题材排名、板块内强度排名
    """
    theme_rank = int(getattr(stock, "theme_rank", 3) or 3)
    sector_flow = _safe(factors, "sector_net_flow_100m", 0.0)     # 板块主力净流入(亿)
    sector_change_pct = _safe(factors, "sector_change_pct", 0.0)  # 板块涨幅%
    intra_sector_rank = _safe(factors, "intra_sector_rank", 10)   # 板块内排名
    theme_hotness = _safe(factors, "theme_hotness_score", 5.0)    # 题材热度 0-10

    base = 5.0
    notes = []
    if theme_rank == 1:
        base += 2.5; notes.append("题材龙头")
    elif theme_rank <= 3:
        base += 1.5; notes.append(f"题材前{theme_rank}")
    elif theme_rank >= 5:
        base -= 1.0

    if sector_flow >= 10:
        base += 1.8; notes.append(f"板块+{sector_flow:.0f}亿")
    elif sector_flow >= 3:
        base += 0.8
    elif sector_flow <= -10:
        base -= 2.0; notes.append("板块资金流出")

    if sector_change_pct >= 3:
        base += 1.0
    elif sector_change_pct < -2:
        base -= 1.0

    if intra_sector_rank <= 3:
        base += 1.5; notes.append(f"板块前{int(intra_sector_rank)}")
    elif intra_sector_rank > 20:
        base -= 0.5

    if theme_hotness >= 7:
        base += 1.0

    return FactorScore(
        name="题材板块",
        score=_clamp(base),
        weight=0.11,
        note="; ".join(notes) or f"题材rank {theme_rank}",
    )


# ─── 11. 主力持仓评分 ────────────────────────────────────────────────────────

def score_institutional(factors: Dict) -> FactorScore:
    """
    北向资金持股、机构持股、龙虎榜机构净买入、20 日主力净流
    """
    north_hold_pct = _safe(factors, "north_hold_pct", 0.0)
    north_hold_change = _safe(factors, "north_hold_change_pct", 0.0)
    institution_hold_pct = _safe(factors, "institution_hold_pct", 0.0)
    lhb_inst_net = _safe(factors, "lhb_inst_net_100m", 0.0)
    main_inflow_20d = _safe(factors, "main_net_inflow_20d_100m", 0.0)
    main_inflow_days = _safe(factors, "main_inflow_days_20d", 0.0)

    base = 5.0
    notes = []
    if north_hold_change >= 2:
        base += 2.0; notes.append(f"北向+{north_hold_change:.1f}%")
    elif north_hold_change >= 0.5:
        base += 1.0
    elif north_hold_change <= -2:
        base -= 1.5; notes.append(f"北向{north_hold_change:.1f}%")

    if north_hold_pct >= 3:
        base += 0.8
    if institution_hold_pct >= 15:
        base += 1.0; notes.append(f"机构{institution_hold_pct:.0f}%")

    if lhb_inst_net >= 2:
        base += 2.0; notes.append(f"机构买{lhb_inst_net:.1f}亿")
    elif lhb_inst_net <= -2:
        base -= 2.0; notes.append("机构卖")

    if main_inflow_20d >= 5:
        base += 1.5; notes.append(f"主力+{main_inflow_20d:.0f}亿")
    elif main_inflow_20d >= 1:
        base += 0.5
    elif main_inflow_20d <= -5:
        base -= 2.0

    if main_inflow_days >= 12:
        base += 0.8

    return FactorScore(
        name="主力持仓",
        score=_clamp(base),
        weight=0.10,
        note="; ".join(notes) or "主力观望",
    )


# ─── 综合计算 ────────────────────────────────────────────────────────────────

def _grade(score: float) -> str:
    if score >= 85: return "S"
    if score >= 75: return "A"
    if score >= 65: return "B"
    if score >= 55: return "C"
    return "D"


def _try_load_adaptive_multipliers() -> Optional[Dict[str, float]]:
    try:
        from evolution.optimizer import get_adaptive_factor_multipliers

        multipliers = get_adaptive_factor_multipliers()
        if multipliers and len(multipliers) >= 3:
            return {
                str(name): float(value)
                for name, value in multipliers.items()
                if name
            }
    except Exception:
        pass
    return None


def _apply_adaptive_multipliers(scores: List[FactorScore], multipliers: Dict[str, float]) -> None:
    touched = False
    for score in scores:
        if score.name not in multipliers:
            continue
        score.weight = max(0.01, float(score.weight) * float(multipliers[score.name]))
        touched = True
    if not touched:
        return
    total = sum(item.weight for item in scores) or 1.0
    for item in scores:
        item.weight = float(item.weight) / total


def compute_multi_factor_score(stock, factors: Optional[Dict] = None) -> MultiFactorResult:
    """
    综合评分主入口。
    - stock: StockCandidate 实例
    - factors: 可选的 factor 字典，默认读取 stock.factors
    """
    f = factors if factors is not None else (getattr(stock, "factors", {}) or {})

    scores: List[FactorScore] = [
        score_sentiment(f),
        score_fundamentals(f),
        score_chip_distribution(f),
        score_shareholder(f),
        score_valuation(f),
        score_news_events(f),
        score_personality(f),
        score_technical(f, stock),
        score_industry(f),
        score_theme_sector(f, stock),
        score_institutional(f),
    ]

    # 权重总和约为 1.0
    adaptive_multipliers = _try_load_adaptive_multipliers()
    if adaptive_multipliers:
        _apply_adaptive_multipliers(scores, adaptive_multipliers)

    total_weight = sum(s.weight for s in scores) or 1.0
    weighted = sum(s.score * s.weight for s in scores) / total_weight
    # 归一化到 0-100
    total_score = round(weighted * 10.0, 2)

    highlights: List[str] = []
    warnings: List[str] = []
    for s in scores:
        if s.score >= 8.0:
            highlights.append(f"{s.name}强({s.score:.1f}): {s.note}")
        elif s.score <= 3.5:
            warnings.append(f"{s.name}弱({s.score:.1f}): {s.note}")

    grade = _grade(total_score)
    if grade in ("S", "A"):
        rec = "强烈关注，符合多因子共振逻辑"
    elif grade == "B":
        rec = "可纳入观察，需技术面配合"
    elif grade == "C":
        rec = "中性，暂不介入"
    else:
        rec = "回避，多因子共振偏弱"

    return MultiFactorResult(
        total_score=total_score,
        grade=grade,
        factors=scores,
        highlights=highlights[:5],
        warnings=warnings[:5],
        recommendation=rec,
    )


def blend_with_adaptive(route_score: float, multi_score: float,
                         multi_weight: float = 0.45) -> float:
    """
    将 adaptive_selector 的 route_score (0-99) 与 multi_factor 的 0-100 分做加权融合。
    默认多因子权重 0.45，技术路由权重 0.55 —— 技术面仍为主导，多因子作为增强/滤波。
    """
    mw = max(0.0, min(1.0, multi_weight))
    return round(route_score * (1 - mw) + multi_score * mw, 2)
