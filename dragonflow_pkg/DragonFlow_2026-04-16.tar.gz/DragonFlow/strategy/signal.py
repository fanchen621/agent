from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class StockCandidate:
    code: str
    name: str
    sector: str
    close: float
    change_pct: float
    volume_ratio: float
    turnover_pct: float
    breakout_20d: int
    from_60d_low_pct: float
    board_height: int
    is_limit_up: int
    is_one_wall: int
    theme_rank: int
    amount_100m: float
    distance_to_high_20d_pct: float = 0.0
    range_position_pct: float = 0.0
    base_tightness_pct: float = 0.0
    vol_contraction_ratio: float = 0.0
    ma10: float = 0.0
    ma20: float = 0.0
    ma20_slope_pct: float = 0.0
    trend_alignment: float = 0.0
    setup_quality: float = 0.0
    score: float = 0.0
    factors: Dict[str, float] = field(default_factory=dict)


@dataclass
class PickResult:
    stock: StockCandidate
    score: float
    reasons: List[str]
    pick_type: str
    breakdown: Dict[str, float] = field(default_factory=dict)


@dataclass
class TradeSignal:
    code: str
    name: str
    direction: str
    price: float
    shares: int
    signal_type: str
    signal_reason: str
    timestamp: datetime.datetime
    minute_price: float = 0.0
    volume_ratio: float = 0.0
    zone: str = ""
    emotion: str = ""
    zt_count: int = 0
    pick_type: str = ""
    strategy_ver: str = "v2.0"
    score: float = 0.0
    add_price: float = 0.0
    stop_price: float = 0.0
    tp1_price: float = 0.0
    tp2_price: float = 0.0
    runtime_rules: Dict[str, float] = field(default_factory=dict)


@dataclass
class TradePlan:
    code: str
    name: str
    sector: str
    zone: str
    emotion: str
    target_position_pct: float
    entry_price: float
    add_price: float
    stop_price: float
    tp1_price: float
    tp2_price: float
    hold_days_max: int = 3
    pick_type: str = ""
    score: float = 0.0
    reasons: List[str] = field(default_factory=list)
    runtime_rules: Dict[str, float] = field(default_factory=dict)
    score_breakdown: Dict[str, float] = field(default_factory=dict)
    source: str = ""
