from __future__ import annotations

from typing import List, Tuple

from strategy.adaptive_selector import evaluate_candidate, rank_candidates
from strategy.signal import PickResult, StockCandidate


def apply_hard_filter(stock: StockCandidate) -> Tuple[bool, List[str]]:
    result = evaluate_candidate(
        stock=stock,
        zone="attack",
        emotion="",
        sentiment_modifier=1.0,
        live_mode=False,
    )
    if result is None:
        return False, ["adaptive filter rejected"]
    return True, result.reasons


def score_stock(stock: StockCandidate) -> Tuple[float, List[str]]:
    result = evaluate_candidate(
        stock=stock,
        zone="attack",
        emotion="",
        sentiment_modifier=1.0,
        live_mode=False,
    )
    if result is None:
        return 0.0, ["adaptive score unavailable"]
    reasons = list(result.reasons)
    reasons.append(f"score={result.score:.1f}")
    return result.score, reasons


def pick_stocks(
    candidates: List[StockCandidate],
    zone: str,
    emotion: str,
) -> List[PickResult]:
    return rank_candidates(
        candidates=candidates,
        zone=zone,
        emotion=emotion,
        sentiment_modifier=1.0,
        live_mode=False,
    )
