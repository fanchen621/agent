from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence

from loguru import logger

from config import ALLOWED_PREFIXES, DOUBLE_DRAGON_FILTER
from models import get_param
from strategy.emotion_cycle import get_emotion_modifier
from strategy.multi_factor import blend_with_adaptive, compute_multi_factor_score
from strategy.signal import PickResult, StockCandidate


ROUTE_WEIGHTS = {
    "super_attack": {
        "leader_momentum": 1.10,
        "turnover_breakout": 1.05,
        "low_position_trend": 0.94,
        "base_pivot_trend": 0.97,
    },
    "attack": {
        "leader_momentum": 1.04,
        "turnover_breakout": 1.02,
        "low_position_trend": 1.00,
        "base_pivot_trend": 1.00,
    },
    "range": {
        "leader_momentum": 0.88,
        "turnover_breakout": 0.93,
        "low_position_trend": 1.10,
        "base_pivot_trend": 1.14,
    },
    "risk": {
        "leader_momentum": 0.62,
        "turnover_breakout": 0.66,
        "low_position_trend": 0.82,
        "base_pivot_trend": 0.84,
    },
}

ROUTE_SCORE_FLOOR = {
    "leader_momentum": 61.0,
    "turnover_breakout": 59.0,
    "low_position_trend": 57.0,
    "base_pivot_trend": 56.0,
}

ROUTE_PRIORITY = {
    "leader_momentum": 4,
    "turnover_breakout": 3,
    "base_pivot_trend": 2,
    "low_position_trend": 1,
}


def _safe_float(value, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _safe_int(value, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _band_score(value: float, bands: Sequence[Sequence[Optional[float]]], default: float = 0.0) -> float:
    for lower, upper, score in bands:
        if lower is not None and value < lower:
            continue
        if upper is not None and value > upper:
            continue
        return float(score)
    return default


def load_selector_thresholds() -> Dict[str, float]:
    defaults = {
        "theme_rank_max": DOUBLE_DRAGON_FILTER["theme_rank_max"],
        "volume_ratio_min": DOUBLE_DRAGON_FILTER["volume_ratio_min"],
        "from_60d_low_pct_min": DOUBLE_DRAGON_FILTER["from_60d_low_pct_min"],
        "from_60d_low_pct_max": DOUBLE_DRAGON_FILTER["from_60d_low_pct_max"],
        "close_change_min": DOUBLE_DRAGON_FILTER["close_change_min"],
        "close_change_max": DOUBLE_DRAGON_FILTER["close_change_max"],
        "min_amount_100m": DOUBLE_DRAGON_FILTER["min_amount_100m"],
    }
    return {
        key: _safe_float(get_param(key, default), default)
        for key, default in defaults.items()
    }


def build_candidate(
    code: str,
    name: str,
    sector: str = "",
    close: float = 0.0,
    change_pct: float = 0.0,
    volume_ratio: float = 0.0,
    turnover_pct: float = 0.0,
    breakout_20d: int = 0,
    from_60d_low_pct: float = 0.0,
    board_height: int = 0,
    is_limit_up: int = 0,
    is_one_wall: int = 0,
    theme_rank: int = 3,
    amount_100m: float = 0.0,
    distance_to_high_20d_pct: float = 0.0,
    range_position_pct: float = 0.0,
    base_tightness_pct: float = 0.0,
    vol_contraction_ratio: float = 0.0,
    ma10: float = 0.0,
    ma20: float = 0.0,
    ma20_slope_pct: float = 0.0,
    trend_alignment: float = 0.0,
    setup_quality: float = 0.0,
    factors: Optional[Dict[str, float]] = None,
) -> StockCandidate:
    return StockCandidate(
        code=str(code).replace("sh", "").replace("sz", ""),
        name=str(name or ""),
        sector=str(sector or ""),
        close=round(_safe_float(close), 3),
        change_pct=round(_safe_float(change_pct), 2),
        volume_ratio=round(_safe_float(volume_ratio), 2),
        turnover_pct=round(_safe_float(turnover_pct), 2),
        breakout_20d=_safe_int(breakout_20d),
        from_60d_low_pct=round(_safe_float(from_60d_low_pct), 2),
        board_height=_safe_int(board_height),
        is_limit_up=_safe_int(is_limit_up),
        is_one_wall=_safe_int(is_one_wall),
        theme_rank=max(1, _safe_int(theme_rank, 3)),
        amount_100m=round(_safe_float(amount_100m), 2),
        distance_to_high_20d_pct=round(_safe_float(distance_to_high_20d_pct), 2),
        range_position_pct=round(_safe_float(range_position_pct), 2),
        base_tightness_pct=round(_safe_float(base_tightness_pct), 2),
        vol_contraction_ratio=round(_safe_float(vol_contraction_ratio, 1.0), 2),
        ma10=round(_safe_float(ma10), 2),
        ma20=round(_safe_float(ma20), 2),
        ma20_slope_pct=round(_safe_float(ma20_slope_pct), 2),
        trend_alignment=round(_safe_float(trend_alignment), 3),
        setup_quality=round(_safe_float(setup_quality), 3),
        factors=dict(factors or {}),
    )


def _is_allowed_candidate(stock: StockCandidate) -> bool:
    return any(stock.code.startswith(prefix) for prefix in ALLOWED_PREFIXES)


def _passes_basic_filter(
    stock: StockCandidate,
    live_mode: bool,
    thresholds: Dict[str, float],
) -> bool:
    if not _is_allowed_candidate(stock):
        return False
    if stock.close <= 0:
        return False
    if stock.is_one_wall == 1:
        return False

    # ── 涨停板不过滤 ─────────────────────────────────────────────────────
    # 涨停应在买入信号层判断（check_buy_signal），不在候选阶段拒绝
    # 候选池保留所有达分股票，由买入信号层判断是否可以实际买入
    # ─────────────────────────────────────────────────────────────────

    min_amount = max(1.4, thresholds["min_amount_100m"] * (0.18 if live_mode else 0.22))
    if stock.amount_100m < min_amount:
        return False

    if stock.change_pct <= -1.8 and stock.board_height < 2:
        return False
    if stock.turnover_pct < 0.8 and stock.volume_ratio < 1.1 and stock.board_height < 2:
        return False
    if stock.from_60d_low_pct > 80.0 and stock.board_height < 2:
        return False

    if not live_mode:
        if stock.change_pct > thresholds["close_change_max"] and stock.is_limit_up == 0:
            return False
        if stock.change_pct < -0.5 and stock.breakout_20d == 0 and stock.trend_alignment < 0.5:
            return False

    return True


def _theme_score(stock: StockCandidate) -> float:
    return _band_score(
        float(stock.theme_rank),
        (
            (1, 1, 10.0),
            (2, 2, 7.5),
            (3, 3, 5.0),
            (4, 5, 2.5),
        ),
        1.0,
    )


def _board_score(stock: StockCandidate) -> float:
    if stock.board_height >= 4:
        return 18.0
    if stock.board_height == 3:
        return 15.0
    if stock.board_height == 2:
        return 12.0
    if stock.board_height == 1:
        return 5.0
    return 0.0


def _factor(stock: StockCandidate, key: str, default: float = 0.0) -> float:
    return _safe_float((stock.factors or {}).get(key, default), default)


def _institutional_bonus(stock: StockCandidate, pick_type: str) -> Dict[str, float]:
    fundamentals = 0.0
    capital_flow = 0.0
    sentiment = 0.0
    chip = 0.0
    penalty = 0.0

    pe_ttm = _factor(stock, "pe_ttm")
    free_float_cap = _factor(stock, "free_market_cap_100m")
    total_cap = _factor(stock, "total_market_cap_100m")
    roe = _factor(stock, "roe_weighted")
    main_inflow_20d = _factor(stock, "main_net_inflow_20d_100m")
    main_inflow_days = _factor(stock, "main_inflow_days_20d")
    lhb_count = _factor(stock, "lhb_count_20d")
    lhb_inst_net = _factor(stock, "lhb_inst_net_100m")
    stock_sentiment_adj = _factor(stock, "stock_sentiment_adj")
    stock_sentiment_rsi = _factor(stock, "stock_sentiment_rsi", 0.5)
    comment_score = _factor(stock, "comment_score")
    chip_concentration = _factor(stock, "chip_concentration_pct")
    chip_distance = abs(_factor(stock, "chip_distance_pct"))
    holder_change = _factor(stock, "holder_change_pct")
    activity_score = _factor(stock, "stock_activity_score")
    volatility_20d = _factor(stock, "volatility_20d_pct")

    if 0 < pe_ttm <= 80:
        fundamentals += 3.0
        if 8 <= pe_ttm <= 40:
            fundamentals += 2.5
    elif pe_ttm > 120:
        penalty -= 2.5

    if 20 <= free_float_cap <= 600:
        fundamentals += 3.0
    elif free_float_cap > 0 and free_float_cap < 10:
        penalty -= 1.5
    elif free_float_cap > 1500:
        penalty -= 1.0

    if total_cap > 0 and total_cap <= 2500:
        fundamentals += 1.0
    if roe >= 8:
        fundamentals += 2.0
    elif 0 < roe < 3:
        penalty -= 1.0

    if main_inflow_20d > 0:
        capital_flow += _clamp(main_inflow_20d / 3.0, 0.0, 5.0)
    elif main_inflow_20d < -3.0:
        penalty -= 3.0
    capital_flow += _clamp(main_inflow_days / 4.0, 0.0, 3.0)

    if lhb_count > 0:
        capital_flow += min(lhb_count, 3.0) * 0.8
    if lhb_inst_net > 0:
        capital_flow += _clamp(lhb_inst_net / 2.0, 0.0, 3.5)
    elif lhb_inst_net < -1.5:
        penalty -= 2.0

    sentiment += _clamp(stock_sentiment_adj / 4.0, -3.0, 3.0)
    if 0.35 <= stock_sentiment_rsi <= 0.72:
        sentiment += 1.5
    elif stock_sentiment_rsi > 0.9:
        penalty -= 2.0
    sentiment += _clamp(comment_score / 25.0, 0.0, 2.0)

    if chip_concentration >= 35:
        chip += 4.0
    elif chip_concentration >= 25:
        chip += 2.5
    if chip_distance <= 6.0:
        chip += 2.0
    elif chip_distance >= 18.0:
        penalty -= 1.5
    if holder_change < 0:
        chip += _clamp(abs(holder_change) / 5.0, 0.0, 2.0)
    elif holder_change > 12:
        penalty -= 1.5

    if pick_type in ("low_position_trend", "base_pivot_trend") and volatility_20d > 5.5:
        penalty -= 2.0
    if pick_type in ("leader_momentum", "turnover_breakout") and activity_score >= 6:
        capital_flow += 1.5

    return {
        "fundamentals": round(fundamentals, 2),
        "capital_flow": round(capital_flow, 2),
        "sentiment_factor": round(sentiment, 2),
        "chip_factor": round(chip, 2),
        "institutional_penalty": round(penalty, 2),
        "institutional_total": round(fundamentals + capital_flow + sentiment + chip + penalty, 2),
    }


def _leader_momentum_route(stock: StockCandidate, live_mode: bool) -> Dict[str, object]:
    leadership = _board_score(stock) + _theme_score(stock)
    trigger = _band_score(
        stock.change_pct,
        (
            (3.0, 9.9, 14.0),
            (1.5, 3.0, 8.0),
            (0.8, 1.5, 4.0),
        ),
    )
    if stock.breakout_20d == 1:
        trigger += 7.0
    if stock.is_limit_up == 1:
        trigger += 4.0
    if stock.distance_to_high_20d_pct <= 2.5:
        trigger += 4.0

    liquidity = _band_score(
        stock.volume_ratio,
        (
            (2.2, 6.0, 10.0),
            (1.6, 2.2, 7.0),
            (1.1, 1.6, 3.0),
        ),
    )
    liquidity += _band_score(
        stock.turnover_pct,
        (
            (5.0, 18.0, 8.0),
            (2.5, 5.0, 4.5),
            (18.0, 28.0, 5.0),
        ),
    )
    liquidity += _band_score(
        stock.amount_100m,
        (
            (6.0, None, 6.0),
            (3.0, 6.0, 4.0),
            (1.5, 3.0, 2.0),
        ),
    )

    trend = _band_score(
        stock.trend_alignment,
        (
            (0.75, None, 8.0),
            (0.5, 0.75, 4.0),
        ),
    )
    trend += _band_score(
        stock.from_60d_low_pct,
        (
            (8.0, 45.0, 6.0),
            (45.0, 58.0, 2.0),
            (4.0, 8.0, 3.0),
        ),
    )

    penalty = 0.0
    if stock.from_60d_low_pct > 65.0:
        penalty -= 10.0
    if stock.turnover_pct < 2.0:
        penalty -= 6.0
    if stock.distance_to_high_20d_pct > 8.0:
        penalty -= 4.0
    if live_mode and stock.change_pct < 1.0:
        penalty -= 4.0

    raw_score = leadership + trigger + liquidity + trend + penalty
    reasons = []
    if stock.board_height >= 2:
        reasons.append(f"board {stock.board_height}")
    if stock.theme_rank <= 2:
        reasons.append(f"theme top{stock.theme_rank}")
    if stock.breakout_20d == 1:
        reasons.append("20d breakout")
    if stock.volume_ratio >= 2.0:
        reasons.append(f"vr {stock.volume_ratio:.1f}")
    if stock.distance_to_high_20d_pct <= 2.5:
        reasons.append("near 20d high")

    return {
        "pick_type": "leader_momentum",
        "raw_score": raw_score,
        "reasons": reasons,
        "breakdown": {
            "leadership": round(leadership, 2),
            "trigger": round(trigger, 2),
            "liquidity": round(liquidity, 2),
            "trend": round(trend, 2),
            "setup": round(stock.setup_quality * 6.0, 2),
            "penalty": round(penalty, 2),
        },
    }


def _turnover_breakout_route(stock: StockCandidate, live_mode: bool) -> Dict[str, object]:
    trigger = _band_score(
        stock.change_pct,
        (
            (2.0, 7.5, 12.0),
            (7.5, 9.9, 8.0),
            (0.8, 2.0, 6.0),
        ),
    )
    if stock.breakout_20d == 1:
        trigger += 10.0
    elif stock.distance_to_high_20d_pct <= 2.5:
        trigger += 7.0

    liquidity = _band_score(
        stock.volume_ratio,
        (
            (1.8, 3.8, 14.0),
            (1.3, 1.8, 8.0),
            (3.8, 6.0, 9.0),
        ),
    )
    liquidity += _band_score(
        stock.turnover_pct,
        (
            (6.0, 18.0, 12.0),
            (3.0, 6.0, 8.0),
            (18.0, 30.0, 6.0),
        ),
    )
    liquidity += _band_score(
        stock.amount_100m,
        (
            (4.0, None, 8.0),
            (2.0, 4.0, 5.0),
            (1.2, 2.0, 2.0),
        ),
    )

    trend = _band_score(
        stock.trend_alignment,
        (
            (0.75, None, 10.0),
            (0.5, 0.75, 5.0),
        ),
    )
    trend += _band_score(
        stock.ma20_slope_pct,
        (
            (0.5, 10.0, 8.0),
            (10.0, None, 5.0),
            (0.0, 0.5, 3.0),
        ),
    )
    trend += _band_score(
        stock.from_60d_low_pct,
        (
            (10.0, 45.0, 6.0),
            (45.0, 60.0, 2.0),
            (5.0, 10.0, 3.0),
        ),
    )

    setup = _band_score(
        stock.distance_to_high_20d_pct,
        (
            (0.0, 2.5, 8.0),
            (2.5, 6.0, 4.0),
        ),
    )
    setup += _band_score(
        stock.base_tightness_pct,
        (
            (0.0, 18.0, 6.0),
            (18.0, 24.0, 3.0),
        ),
    )
    if 0.75 <= stock.vol_contraction_ratio <= 1.15:
        setup += 4.0

    penalty = 0.0
    if stock.from_60d_low_pct > 65.0:
        penalty -= 10.0
    if stock.volume_ratio < 1.2:
        penalty -= 8.0
    if stock.change_pct > 9.9:
        penalty -= 6.0
    if stock.is_limit_up == 1 and stock.board_height <= 1:
        penalty -= 4.0
    if live_mode and stock.change_pct < 0.8:
        penalty -= 4.0

    raw_score = trigger + liquidity + trend + setup + penalty + (_theme_score(stock) * 0.6)
    reasons = [
        "turnover pulse",
        f"vr {stock.volume_ratio:.1f}",
        f"turn {stock.turnover_pct:.1f}%",
    ]
    if stock.breakout_20d == 1:
        reasons.append("20d breakout")
    if stock.distance_to_high_20d_pct <= 2.5:
        reasons.append("tight to pivot")

    return {
        "pick_type": "turnover_breakout",
        "raw_score": raw_score,
        "reasons": reasons,
        "breakdown": {
            "leadership": round(_theme_score(stock) * 0.6, 2),
            "trigger": round(trigger, 2),
            "liquidity": round(liquidity, 2),
            "trend": round(trend, 2),
            "setup": round(setup, 2),
            "penalty": round(penalty, 2),
        },
    }


def _low_position_trend_route(stock: StockCandidate, live_mode: bool) -> Dict[str, object]:
    trend = _band_score(
        stock.trend_alignment,
        (
            (0.75, None, 14.0),
            (0.5, 0.75, 8.0),
            (0.25, 0.5, 3.0),
        ),
    )
    trend += _band_score(
        stock.ma20_slope_pct,
        (
            (1.0, 12.0, 12.0),
            (0.3, 1.0, 7.0),
            (12.0, None, 7.0),
        ),
        default=-8.0 if stock.ma20_slope_pct < 0 else 0.0,
    )

    setup = _band_score(
        stock.from_60d_low_pct,
        (
            (5.0, 25.0, 14.0),
            (25.0, 38.0, 9.0),
            (0.0, 5.0, 5.0),
        ),
    )
    setup += _band_score(
        stock.range_position_pct,
        (
            (35.0, 72.0, 12.0),
            (25.0, 35.0, 6.0),
            (72.0, 82.0, 6.0),
        ),
        default=-8.0 if stock.range_position_pct > 85.0 else 0.0,
    )
    setup += _band_score(
        stock.distance_to_high_20d_pct,
        (
            (2.0, 10.0, 10.0),
            (0.0, 2.0, 6.0),
            (10.0, 15.0, 4.0),
        ),
        default=-6.0 if stock.distance_to_high_20d_pct > 15.0 else 0.0,
    )
    setup += _band_score(
        stock.base_tightness_pct,
        (
            (0.0, 15.0, 8.0),
            (15.0, 22.0, 5.0),
        ),
    )

    liquidity = _band_score(
        stock.volume_ratio,
        (
            (0.9, 1.8, 10.0),
            (1.8, 2.5, 6.0),
            (0.6, 0.9, 4.0),
        ),
        default=-4.0 if stock.volume_ratio > 3.2 else 0.0,
    )
    liquidity += _band_score(
        stock.vol_contraction_ratio,
        (
            (0.65, 1.05, 10.0),
            (1.05, 1.2, 6.0),
        ),
        default=-4.0 if stock.vol_contraction_ratio > 1.35 else 0.0,
    )
    liquidity += _band_score(
        stock.turnover_pct,
        (
            (2.0, 9.0, 6.0),
            (9.0, 16.0, 4.0),
        ),
    )
    liquidity += _band_score(
        stock.amount_100m,
        (
            (4.0, None, 6.0),
            (1.5, 4.0, 4.0),
        ),
    )

    momentum = _band_score(
        stock.change_pct,
        (
            (1.0, 4.8, 8.0),
            (0.2, 1.0, 5.0),
            (4.8, 6.8, 4.0),
        ),
        default=-8.0 if stock.change_pct > 8.5 else (-6.0 if stock.change_pct < 0 else 0.0),
    )

    penalty = 0.0
    if stock.is_limit_up == 1:
        penalty -= 15.0
    if stock.board_height >= 2:
        penalty -= 10.0
    if stock.breakout_20d == 1 and stock.change_pct >= 7.5:
        penalty -= 4.0

    raw_score = trend + setup + liquidity + momentum + penalty + (_theme_score(stock) * 0.4)
    reasons = [
        "low-base uptrend",
        f"ma20 slope {stock.ma20_slope_pct:.1f}%",
        f"dist-high {stock.distance_to_high_20d_pct:.1f}%",
    ]
    if 0.65 <= stock.vol_contraction_ratio <= 1.05:
        reasons.append("vol calm")
    if stock.range_position_pct:
        reasons.append(f"range {stock.range_position_pct:.0f}%")

    return {
        "pick_type": "low_position_trend",
        "raw_score": raw_score,
        "reasons": reasons,
        "breakdown": {
            "leadership": round(_theme_score(stock) * 0.4, 2),
            "trigger": round(momentum, 2),
            "liquidity": round(liquidity, 2),
            "trend": round(trend, 2),
            "setup": round(setup, 2),
            "penalty": round(penalty, 2),
        },
    }


def _base_pivot_trend_route(stock: StockCandidate, live_mode: bool) -> Dict[str, object]:
    setup = _band_score(
        stock.base_tightness_pct,
        (
            (0.0, 12.0, 14.0),
            (12.0, 18.0, 8.0),
            (18.0, 24.0, 4.0),
        ),
    )
    setup += _band_score(
        stock.vol_contraction_ratio,
        (
            (0.65, 1.0, 12.0),
            (1.0, 1.15, 8.0),
            (1.15, 1.3, 4.0),
        ),
        default=-4.0 if stock.vol_contraction_ratio > 1.3 else 0.0,
    )
    setup += _band_score(
        stock.distance_to_high_20d_pct,
        (
            (0.5, 5.5, 14.0),
            (5.5, 8.0, 8.0),
            (0.0, 0.5, 5.0),
        ),
        default=-8.0 if stock.distance_to_high_20d_pct > 9.0 else 0.0,
    )
    setup += _band_score(
        stock.range_position_pct,
        (
            (45.0, 82.0, 10.0),
            (30.0, 45.0, 6.0),
        ),
    )

    trend = _band_score(
        stock.trend_alignment,
        (
            (0.75, None, 12.0),
            (0.5, 0.75, 6.0),
        ),
    )
    trend += _band_score(
        stock.ma20_slope_pct,
        (
            (0.5, 8.0, 10.0),
            (8.0, None, 7.0),
        ),
        default=-6.0 if stock.ma20_slope_pct < 0 else 0.0,
    )
    trend += _band_score(
        stock.from_60d_low_pct,
        (
            (6.0, 28.0, 8.0),
            (28.0, 40.0, 5.0),
            (0.0, 6.0, 3.0),
        ),
    )

    liquidity = _band_score(
        stock.volume_ratio,
        (
            (0.8, 1.6, 8.0),
            (1.6, 2.2, 5.0),
            (0.6, 0.8, 3.0),
        ),
        default=-4.0 if stock.volume_ratio > 2.8 else 0.0,
    )
    liquidity += _band_score(
        stock.turnover_pct,
        (
            (2.0, 10.0, 8.0),
            (10.0, 16.0, 5.0),
        ),
    )
    liquidity += _band_score(
        stock.amount_100m,
        (
            (4.0, None, 6.0),
            (1.5, 4.0, 4.0),
        ),
    )

    momentum = _band_score(
        stock.change_pct,
        (
            (0.5, 3.8, 10.0),
            (3.8, 6.0, 6.0),
            (0.0, 0.5, 4.0),
        ),
        default=-8.0 if stock.change_pct > 7.5 else 0.0,
    )

    penalty = 0.0
    if stock.is_limit_up == 1:
        penalty -= 15.0
    if stock.board_height >= 2:
        penalty -= 8.0
    if stock.from_60d_low_pct > 45.0:
        penalty -= 6.0
    if live_mode and stock.change_pct < 0:
        penalty -= 3.0

    raw_score = setup + trend + liquidity + momentum + penalty + (_theme_score(stock) * 0.35)
    reasons = [
        "tight base",
        f"pivot {stock.distance_to_high_20d_pct:.1f}% below high",
        f"base {stock.base_tightness_pct:.1f}%",
    ]
    if 0.65 <= stock.vol_contraction_ratio <= 1.05:
        reasons.append("volume contracted")
    if stock.trend_alignment >= 0.75:
        reasons.append("trend aligned")

    return {
        "pick_type": "base_pivot_trend",
        "raw_score": raw_score,
        "reasons": reasons,
        "breakdown": {
            "leadership": round(_theme_score(stock) * 0.35, 2),
            "trigger": round(momentum, 2),
            "liquidity": round(liquidity, 2),
            "trend": round(trend, 2),
            "setup": round(setup, 2),
            "penalty": round(penalty, 2),
        },
    }


def _route_weight(zone: str, pick_type: str) -> float:
    return ROUTE_WEIGHTS.get(zone, ROUTE_WEIGHTS["attack"]).get(pick_type, 1.0)


def _regime_bonus(
    stock: StockCandidate,
    zone: str,
    emotion: str,
    sentiment_modifier: float,
    pick_type: str,
) -> float:
    emotion_modifier = get_emotion_modifier(emotion)
    bonus = (sentiment_modifier - 1.0) * 9.0 + (emotion_modifier - 1.0) * 13.0
    bonus += {
        "super_attack": 4.0,
        "attack": 2.0,
        "range": 0.5,
        "risk": -14.0,
    }.get(zone, 0.0)

    if pick_type in ("leader_momentum", "turnover_breakout"):
        bonus += {
            "super_attack": 3.0,
            "attack": 1.5,
            "range": -2.5,
            "risk": -5.0,
        }.get(zone, 0.0)
        if stock.board_height >= 2:
            bonus += 1.0
    else:
        bonus += {
            "super_attack": -1.0,
            "attack": 0.0,
            "range": 3.0,
            "risk": -2.0,
        }.get(zone, 0.0)
        if zone == "range" and stock.change_pct <= 4.5:
            bonus += 1.5

    if pick_type in ("low_position_trend", "base_pivot_trend") and stock.change_pct > 6.5:
        bonus -= 2.0
    if zone == "range" and pick_type in ("leader_momentum", "turnover_breakout") and stock.change_pct > 8.0:
        bonus -= 2.0

    return round(_clamp(bonus, -18.0, 12.0), 2)


def _required_score(pick_type: str, zone: str, live_mode: bool) -> float:
    required = ROUTE_SCORE_FLOOR.get(pick_type, 58.0)
    if live_mode:
        required -= 3.0
    if zone == "super_attack" and pick_type in ("leader_momentum", "turnover_breakout"):
        required -= 2.0
    elif zone == "range" and pick_type in ("low_position_trend", "base_pivot_trend"):
        required -= 1.0
    elif zone == "range":
        required += 2.5
    elif zone == "risk":
        required += 6.0
    return required


def _finalize_route(
    stock: StockCandidate,
    zone: str,
    emotion: str,
    sentiment_modifier: float,
    route: Dict[str, object],
) -> Dict[str, object]:
    pick_type = str(route["pick_type"])
    route_weight = _route_weight(zone, pick_type)
    regime_bonus = _regime_bonus(stock, zone, emotion, sentiment_modifier, pick_type)
    raw_score = float(route["raw_score"])
    route_score = raw_score * route_weight + regime_bonus
    route["route_weight"] = route_weight
    route["regime_bonus"] = regime_bonus
    route["route_score"] = route_score
    return route


def _merge_reasons(
    route: Dict[str, object],
    ensemble_bonus: float,
    zone: str,
    stock: StockCandidate,
) -> List[str]:
    reasons = list(route.get("reasons", []))
    pick_type = str(route.get("pick_type", ""))
    if ensemble_bonus > 0:
        reasons.append("multi-route confirmed")
    if zone == "range" and pick_type in ("low_position_trend", "base_pivot_trend"):
        reasons.append("range rotation fit")
    if zone in ("super_attack", "attack") and pick_type in ("leader_momentum", "turnover_breakout"):
        reasons.append("attack regime fit")
    if route.get("regime_bonus", 0.0) <= -4.0:
        reasons.append("regime cautious")
    if _factor(stock, "main_net_inflow_20d_100m") > 0:
        reasons.append("20d main inflow")
    if _factor(stock, "chip_concentration_pct") >= 25:
        reasons.append("chip concentrated")
    if _factor(stock, "stock_sentiment_adj") > 0:
        reasons.append("sentiment improving")
    return reasons[:6]


def evaluate_candidate(
    stock: StockCandidate,
    zone: str,
    emotion: str,
    sentiment_modifier: float = 1.0,
    live_mode: bool = False,
    thresholds: Optional[Dict[str, float]] = None,
    score_floor_override: Optional[float] = None,
) -> Optional[PickResult]:
    thresholds = thresholds or load_selector_thresholds()
    if not _passes_basic_filter(stock, live_mode, thresholds):
        return None

    if zone == "risk" and not live_mode:
        return None

    routes = [
        _finalize_route(stock, zone, emotion, sentiment_modifier, _leader_momentum_route(stock, live_mode)),
        _finalize_route(stock, zone, emotion, sentiment_modifier, _turnover_breakout_route(stock, live_mode)),
        _finalize_route(stock, zone, emotion, sentiment_modifier, _low_position_trend_route(stock, live_mode)),
        _finalize_route(stock, zone, emotion, sentiment_modifier, _base_pivot_trend_route(stock, live_mode)),
    ]
    routes.sort(
        key=lambda item: (
            float(item.get("route_score", 0.0)),
            ROUTE_PRIORITY.get(str(item.get("pick_type", "")), 0),
        ),
        reverse=True,
    )
    best = routes[0]
    institutional = _institutional_bonus(stock, str(best["pick_type"]))

    required_score = _required_score(str(best["pick_type"]), zone, live_mode)
    route_score = float(best["route_score"]) + float(institutional["institutional_total"])
    if route_score < required_score:
        return None

    ensemble_bonus = 0.0
    if len(routes) > 1:
        second = routes[1]
        if float(second.get("route_score", 0.0)) >= float(best["route_score"]) - 4.0:
            ensemble_bonus = 1.5

    breakdown = dict(best.get("breakdown", {}))
    breakdown["regime"] = round(float(best.get("regime_bonus", 0.0)), 2)
    breakdown["route_weight"] = round(float(best.get("route_weight", 1.0)), 3)
    breakdown["fundamentals"] = float(institutional["fundamentals"])
    breakdown["capital_flow"] = float(institutional["capital_flow"])
    breakdown["sentiment_factor"] = float(institutional["sentiment_factor"])
    breakdown["chip_factor"] = float(institutional["chip_factor"])
    breakdown["institutional_penalty"] = float(institutional["institutional_penalty"])
    breakdown["ensemble_bonus"] = round(ensemble_bonus, 2)

    adaptive_score = round(_clamp(route_score + ensemble_bonus, 0.0, 99.0), 2)

    # ─── 多因子增强：舆论/基本面/筹码/股东/PE/利好利空/股性/均线MACD/行业/板块/主力 ───
    try:
        mf = compute_multi_factor_score(stock)
        multi_score = mf.total_score
        final_score = blend_with_adaptive(adaptive_score, multi_score, multi_weight=0.45)
        breakdown["multi_factor_score"] = multi_score
        breakdown["multi_factor_grade"] = mf.grade
        breakdown["adaptive_score"] = adaptive_score
        for fac in mf.factors:
            breakdown[f"mf_{fac.name}"] = fac.score
    except Exception as exc:
        logger.debug(f"[multi_factor] fallback for {stock.code}: {exc}")
        final_score = adaptive_score
        mf = None

    score = round(_clamp(final_score, 0.0, 99.0), 2)

    # ── 全局最低分数线：低于门槛直接淘汰 ──────────────────────────────
    from config import BUY_MIN_SCORE
    _ice_min = BUY_MIN_SCORE
    if zone == "risk":
        from config import BUY_MIN_SCORE_ICEBORN
        _ice_min = BUY_MIN_SCORE_ICEBORN
    if score_floor_override is not None:
        _ice_min = max(40.0, float(score_floor_override))
    if score < _ice_min:
        logger.debug(
            f"[selector] {stock.code} score={score:.1f} < {_ice_min:.1f} 淘汰"
        )
        return None
    # ────────────────────────────────────────────────────────────

    stock.score = score

    reasons = _merge_reasons(best, ensemble_bonus, zone, stock)
    if mf is not None:
        if mf.highlights:
            reasons.append(f"多因子[{mf.grade}]: {mf.highlights[0]}")
        elif mf.grade in ("S", "A"):
            reasons.append(f"多因子 {mf.grade} 级")
        if mf.warnings and mf.grade in ("C", "D"):
            reasons.append(f"⚠{mf.warnings[0]}")

    return PickResult(
        stock=stock,
        score=score,
        reasons=reasons[:7],
        pick_type=str(best["pick_type"]),
        breakdown=breakdown,
    )


def rank_candidates(
    candidates: Iterable[StockCandidate],
    zone: str,
    emotion: str,
    sentiment_modifier: float = 1.0,
    live_mode: bool = False,
    limit: Optional[int] = None,
    score_floor_override: Optional[float] = None,
    quiet: bool = False,
) -> List[PickResult]:
    thresholds = load_selector_thresholds()
    results: List[PickResult] = []
    for stock in candidates:
        result = evaluate_candidate(
            stock=stock,
            zone=zone,
            emotion=emotion,
            sentiment_modifier=sentiment_modifier,
            live_mode=live_mode,
            thresholds=thresholds,
            score_floor_override=score_floor_override,
        )
        if result is not None:
            results.append(result)

    results.sort(
        key=lambda item: (
            item.score,
            ROUTE_PRIORITY.get(item.pick_type, 0),
            item.stock.trend_alignment,
            item.stock.amount_100m,
            item.stock.board_height,
        ),
        reverse=True,
    )
    if limit is not None:
        results = results[:limit]

    if results and not quiet:
        top = results[0]
        logger.info(
            f"[selector] {len(results)} picks | top={top.stock.code} "
            f"{top.pick_type} {top.score:.1f}"
        )
    elif not results and not quiet:
        logger.info("[selector] no candidates passed adaptive ranking")
    return results
