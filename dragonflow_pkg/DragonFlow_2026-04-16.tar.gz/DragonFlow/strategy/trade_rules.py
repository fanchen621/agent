from __future__ import annotations

import datetime
from typing import Dict, List, Optional

from loguru import logger

from config import ALLOWED_PREFIXES
from strategy.position_manager import calc_buy_shares, can_add_position
from strategy.runtime_rules import get_runtime_trade_rules
from strategy.signal import StockCandidate, TradePlan, TradeSignal


def is_allowed_code(code: str) -> bool:
    return any(str(code).startswith(prefix) for prefix in ALLOWED_PREFIXES)


def _runtime_rules_for_plan(plan: TradePlan, zone: str, emotion: str) -> Dict:
    score = float(plan.score or 0.0)
    if plan.runtime_rules:
        return dict(plan.runtime_rules)
    return get_runtime_trade_rules(zone, emotion, score, plan.pick_type or "")


def _resolve_position_rules(position: Dict, zone: str, emotion: str) -> Dict:
    score = float(position.get("score", 0.0) or 0.0)
    runtime_rules = dict(position.get("runtime_rules") or {})
    if runtime_rules:
        return runtime_rules
    return get_runtime_trade_rules(zone, emotion, score, str(position.get("pick_type", "") or ""))


def _target_buy_amount(plan: TradePlan, runtime_rules: Dict) -> float:
    policy = runtime_rules.get("position_policy") or {}
    base_single_pct = float(policy.get("max_single_pct", 0.0) or 0.0)
    plan_pct = float(plan.target_position_pct or 0.0)
    if plan_pct > 0:
        total_pct = float(policy.get("total_pct", base_single_pct) or base_single_pct)
        target_pct = min(total_pct, plan_pct)
    else:
        if plan.score >= 88:
            quality_factor = 1.0
        elif plan.score >= 80:
            quality_factor = 0.94
        elif plan.score >= 72:
            quality_factor = 0.86
        else:
            quality_factor = 0.75
        target_pct = base_single_pct * quality_factor

    capital = float(runtime_rules.get("initial_capital", 0.0) or 0.0)
    return max(0.0, capital * target_pct)


def _pick_type_change_bounds(pick_type: str) -> tuple[float, float]:
    if pick_type == "leader_momentum":
        return 1.0, 10.5
    if pick_type == "turnover_breakout":
        return 0.8, 8.8
    if pick_type == "low_position_trend":
        return 0.2, 6.8
    if pick_type == "base_pivot_trend":
        return 0.0, 5.8
    return 0.8, 9.5


def _data_quality_bounds(pick_type: str) -> tuple[float, float, float]:
    if pick_type in ("low_position_trend", "base_pivot_trend"):
        return 0.64, 0.8, 25.0
    if pick_type in ("leader_momentum", "turnover_breakout"):
        return 0.58, 1.2, 35.0
    return 0.6, 1.0, 30.0


def _passes_realtime_quality(realtime: Dict, pick_type: str) -> bool:
    min_confidence, max_gap_pct, max_age_sec = _data_quality_bounds(pick_type)
    data_confidence = float(realtime.get("data_confidence", 0.0) or 0.0)
    quote_age_sec = float(realtime.get("quote_age_sec", 0.0) or 0.0)
    consensus_gap = realtime.get("consensus_gap_pct")

    if data_confidence <= 0 or data_confidence < min_confidence:
        return False
    if quote_age_sec > max_age_sec:
        return False
    if consensus_gap is not None and float(consensus_gap) > max_gap_pct:
        return False
    return True


def check_buy_signal(
    plan: TradePlan,
    realtime: Dict,
    zone: str,
    emotion: str,
    current_positions: int,
) -> Optional[TradeSignal]:
    code = plan.code
    if not is_allowed_code(code):
        return None
    if zone == "risk":
        return None

    # ── 全局最低分数线（第二层兜底） ─────────────────────────────────
    from config import BUY_MIN_SCORE, BUY_MIN_SCORE_ICEBORN
    _min = BUY_MIN_SCORE_ICEBORN if zone == "risk" else BUY_MIN_SCORE
    plan_score = float(plan.score or 0)
    if plan_score < _min:
        return None
    # ────────────────────────────────────────────────────────────

    runtime_rules = _runtime_rules_for_plan(plan, zone, emotion)
    policy = runtime_rules.get("position_policy") or {}
    max_holdings = int(policy.get("max_holdings", 0) or 0)
    if current_positions >= max_holdings:
        return None

    price = float(realtime.get("price", 0) or 0)
    change_pct = float(realtime.get("change_pct", 0) or 0)
    # 如果实时价格为空，用候选股已有数据（watch循环已获取）
    if price <= 0 and plan.stock:
        price = float(plan.stock.close or 0)
    if change_pct == 0 and plan.stock:
        change_pct = float(plan.stock.change_pct or 0)
    volume_ratio = float(realtime.get("volume_ratio", 0) or 0)
    if price <= 0:
        return None
    if not _passes_realtime_quality(realtime, plan.pick_type or ""):
        return None

    # ── 追高限制：通过 max_chase_pct（已有）控制，不另设涨幅硬限制 ─────
    # 评分门槛(BUY_MIN_SCORE)和仓位控制(max_chase_pct)已足够过滤
    # ───────────────────────────────────────────────────────────────────

    max_chase_pct = float(runtime_rules.get("max_chase_pct", 0) or 0)
    if plan.entry_price > 0 and price > plan.entry_price * (1 + max_chase_pct / 100):
        return None

    min_buy_volume_ratio = float(runtime_rules.get("min_buy_volume_ratio", 0) or 0)
    if volume_ratio > 0 and volume_ratio < min_buy_volume_ratio:
        return None

    min_change_pct, max_change_pct = _pick_type_change_bounds(plan.pick_type or "")
    if change_pct < min_change_pct or change_pct > max_change_pct:
        return None
    if plan.pick_type in ("low_position_trend", "base_pivot_trend") and volume_ratio > 2.8:
        return None

    buy_amount = _target_buy_amount(plan, runtime_rules)
    shares = calc_buy_shares(price, buy_amount)
    if shares <= 0:
        return None

    reason = (
        f"{plan.pick_type or 'adaptive'} | "
        f"score={plan.score:.1f} vr={volume_ratio:.2f} "
        f"chg={change_pct:.2f}% "
        f"q={float(realtime.get('data_confidence', 0.0) or 0.0):.2f} "
        f"gap={float(realtime.get('consensus_gap_pct', 0.0) or 0.0):.2f}% "
        f"{zone}/{emotion}"
    )

    return TradeSignal(
        code=plan.code,
        name=plan.name,
        direction="BUY",
        price=price,
        shares=shares,
        signal_type=plan.pick_type or "adaptive_buy",
        signal_reason=reason,
        timestamp=datetime.datetime.now(),
        minute_price=price,
        volume_ratio=volume_ratio,
        zone=zone,
        emotion=emotion,
        pick_type=plan.pick_type,
        score=plan.score,
        add_price=plan.add_price,
        stop_price=plan.stop_price,
        tp1_price=plan.tp1_price,
        tp2_price=plan.tp2_price,
        runtime_rules=runtime_rules,
    )


def check_sell_signal(
    position: Dict,
    realtime: Dict,
    zone: str,
    emotion: str,
    force_close: bool = False,
) -> Optional[TradeSignal]:
    code = str(position.get("code", ""))
    shares = int(position.get("shares", 0) or 0)
    price = float(realtime.get("price", 0) or 0)
    buy_price = float(position.get("buy_price", 0) or 0)
    hold_days = int(position.get("hold_days", 0) or 0)
    if shares <= 0 or price <= 0 or buy_price <= 0:
        return None

    runtime_rules = _resolve_position_rules(position, zone, emotion)
    pnl_pct = (price - buy_price) / buy_price
    volume_ratio = float(realtime.get("volume_ratio", 0) or 0)

    stop_price = float(position.get("stop_loss", 0) or 0) or round(
        buy_price * (1 + float(runtime_rules.get("stop_loss_pct", 0) or 0)), 3
    )
    tp1_price = float(position.get("take_profit_1", 0) or 0) or round(
        buy_price * (1 + float(runtime_rules.get("take_profit_1_pct", 0) or 0)), 3
    )
    tp2_price = float(position.get("take_profit_2", 0) or 0) or round(
        buy_price * (1 + float(runtime_rules.get("take_profit_2_pct", 0) or 0)), 3
    )

    signal_type = ""
    signal_reason = ""
    sell_shares = shares

    if price <= stop_price or pnl_pct <= float(runtime_rules.get("stop_loss_pct", -0.018) or -0.018):
        signal_type = "STOP_LOSS"
        signal_reason = f"price={price:.2f} stop={stop_price:.2f}"
    elif tp2_price > 0 and price >= tp2_price:
        signal_type = "TAKE_PROFIT_2"
        signal_reason = f"price={price:.2f} tp2={tp2_price:.2f}"
    elif tp1_price > 0 and price >= tp1_price:
        signal_type = "TAKE_PROFIT_1"
        signal_reason = f"price={price:.2f} tp1={tp1_price:.2f}"
        if shares > 100:
            sell_shares = max((shares // 2) // 100 * 100, 100)

    if not signal_type and hold_days >= int(runtime_rules.get("max_hold_days", 3) or 3):
        signal_type = "TIME_EXIT"
        signal_reason = f"hold_days={hold_days}>={runtime_rules.get('max_hold_days',3)}"

    # OVERDUE_EJECT: 超出max_hold_days+2天，强制弹出，不参与urgency排队
    max_hold = int(runtime_rules.get("max_hold_days", 3) or 3)
    if not signal_type and hold_days > max_hold + 2:
        signal_type = "OVERDUE_EJECT"
        signal_reason = f"hold_days={hold_days} overdue force eject"

    if not signal_type and hold_days >= 1:
        now = datetime.datetime.now()
        next_day_fail_pct = float(runtime_rules.get("next_day_fail_pct", -0.01) or -0.01)
        next_day_low_vol_ratio = float(runtime_rules.get("next_day_low_vol_ratio", 1.0) or 1.0)
        if now.hour < 10 and pnl_pct <= next_day_fail_pct:
            signal_type = "NEXT_DAY_FAIL"
            signal_reason = f"pnl={pnl_pct * 100:.2f}% threshold={next_day_fail_pct * 100:.2f}%"
        elif now.hour == 9 and 30 <= now.minute < 60 and 0 < volume_ratio < next_day_low_vol_ratio:
            signal_type = "LOW_OPEN_VOLUME"
            signal_reason = f"vr={volume_ratio:.2f} threshold={next_day_low_vol_ratio:.2f}"

    # force_close: 14:50触发，优先于其他逻辑，确保收盘前必清
    if force_close:
        signal_type = "FORCE_CLOSE"
        signal_reason = "late_session_flatten"
        logger.info(f"[check_sell_signal] FORCE_CLOSE {code} hold_days={hold_days} pnl_pct={pnl_pct*100:.2f}%")

    if not signal_type:
        return None

    return TradeSignal(
        code=code,
        name=str(position.get("name", "")),
        direction="SELL",
        price=price,
        shares=sell_shares,
        signal_type=signal_type,
        signal_reason=signal_reason,
        timestamp=datetime.datetime.now(),
        minute_price=price,
        volume_ratio=volume_ratio,
        zone=zone,
        emotion=emotion,
        score=float(position.get("score", 0.0) or 0.0),
        add_price=float(position.get("add_price", 0.0) or 0.0),
        stop_price=stop_price,
        tp1_price=tp1_price,
        tp2_price=tp2_price,
        runtime_rules=runtime_rules,
    )


def check_add_signal(
    position: Dict,
    realtime: Dict,
    zone: str,
    emotion: str,
) -> Optional[TradeSignal]:
    if not can_add_position(zone):
        return None

    shares = int(position.get("shares", 0) or 0)
    buy_price = float(position.get("buy_price", 0) or 0)
    price = float(realtime.get("price", 0) or 0)
    if shares <= 0 or buy_price <= 0 or price <= 0:
        return None
    if not _passes_realtime_quality(realtime, str(position.get("pick_type", "") or "")):
        return None

    runtime_rules = _resolve_position_rules(position, zone, emotion)
    add_price = float(position.get("add_price", 0) or 0) or round(
        buy_price * (1 + float(runtime_rules.get("add_trigger_pct", 0.02) or 0.02)), 3
    )
    tp1_price = float(position.get("take_profit_1", 0) or 0)
    if price < add_price:
        return None
    if tp1_price > 0 and price >= tp1_price:
        return None

    add_ratio = float(runtime_rules.get("add_ratio", 0.5) or 0.5)
    add_shares = int((shares * add_ratio) / 100) * 100
    if add_shares < 100:
        return None

    return TradeSignal(
        code=str(position.get("code", "")),
        name=str(position.get("name", "")),
        direction="BUY",
        price=price,
        shares=add_shares,
        signal_type="ADD_POSITION",
        signal_reason=f"price={price:.2f} add={add_price:.2f}",
        timestamp=datetime.datetime.now(),
        minute_price=price,
        volume_ratio=float(realtime.get("volume_ratio", 0) or 0),
        zone=zone,
        emotion=emotion,
        score=float(position.get("score", 0.0) or 0.0),
        add_price=0.0,
        stop_price=float(position.get("stop_loss", 0) or 0),
        tp1_price=float(position.get("take_profit_1", 0) or 0),
        tp2_price=float(position.get("take_profit_2", 0) or 0),
        runtime_rules=runtime_rules,
    )


def build_trade_plan(
    stock: StockCandidate,
    zone: str,
    emotion: str,
    pick_type: str,
    score: float,
    reasons: List[str],
    breakdown: Optional[Dict[str, float]] = None,
    source: str = "",
) -> TradePlan:
    runtime_rules = get_runtime_trade_rules(zone, emotion, score, pick_type)
    position_policy = runtime_rules.get("position_policy") or {}
    base_target_pct = float(position_policy.get("max_single_pct", 0.0) or 0.0)
    if score >= 88:
        quality_factor = 1.0
    elif score >= 80:
        quality_factor = 0.95
    elif score >= 72:
        quality_factor = 0.85
    else:
        quality_factor = 0.72

    pick_factor = {
        "leader_momentum": 1.0,
        "turnover_breakout": 0.9,
        "low_position_trend": 0.78,
        "base_pivot_trend": 0.74,
    }.get(pick_type, 0.82)
    if zone == "range" and pick_type in ("low_position_trend", "base_pivot_trend"):
        pick_factor += 0.06

    entry = float(stock.close or 0)
    target_pct = round(base_target_pct * quality_factor * pick_factor, 4)
    return TradePlan(
        code=stock.code,
        name=stock.name,
        sector=stock.sector,
        zone=zone,
        emotion=emotion,
        target_position_pct=target_pct,
        entry_price=entry,
        add_price=round(entry * (1 + float(runtime_rules["add_trigger_pct"])), 3),
        stop_price=round(entry * (1 + float(runtime_rules["stop_loss_pct"])), 3),
        tp1_price=round(entry * (1 + float(runtime_rules["take_profit_1_pct"])), 3),
        tp2_price=round(entry * (1 + float(runtime_rules["take_profit_2_pct"])), 3),
        hold_days_max=int(runtime_rules["max_hold_days"]),
        pick_type=pick_type,
        score=round(score, 2),
        reasons=list(reasons),
        runtime_rules=runtime_rules,
        score_breakdown=dict(breakdown or {}),
        source=source or pick_type or "adaptive",
    )
