from __future__ import annotations

from typing import Dict

from config import TRADE_RULES
from models import get_param
from strategy.emotion_cycle import get_emotion_modifier
from strategy.position_manager import get_position_policy


_RULE_KEYS = (
    "initial_capital",
    "stop_loss_pct",
    "next_day_fail_pct",
    "next_day_low_vol_ratio",
    "take_profit_1_pct",
    "take_profit_2_pct",
    "max_hold_days",
    "add_trigger_pct",
    "add_ratio",
    "max_chase_pct",
    "min_buy_volume_ratio",
    "buy_fee_rate",
    "sell_fee_rate",
)


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def load_base_trade_rules() -> Dict[str, float]:
    rules: Dict[str, float] = {}
    for key in _RULE_KEYS:
        value = get_param(key, TRADE_RULES.get(key))
        if value is None:
            value = TRADE_RULES.get(key)
        rules[key] = value
    return rules


def _apply_zone_adjustments(rules: Dict[str, float], zone: str) -> None:
    if zone == "super_attack":
        rules["max_chase_pct"] += 0.8
        rules["min_buy_volume_ratio"] -= 0.15
        rules["take_profit_1_pct"] += 0.005
        rules["take_profit_2_pct"] += 0.012
        rules["add_trigger_pct"] -= 0.002
        rules["max_hold_days"] += 1
    elif zone == "attack":
        rules["max_chase_pct"] += 0.3
        rules["take_profit_1_pct"] += 0.002
        rules["take_profit_2_pct"] += 0.006
    elif zone == "range":
        rules["max_chase_pct"] -= 0.6
        rules["min_buy_volume_ratio"] += 0.2
        rules["take_profit_1_pct"] -= 0.003
        rules["take_profit_2_pct"] -= 0.006
        rules["max_hold_days"] -= 1
    elif zone == "risk":
        rules["max_chase_pct"] -= 1.8
        rules["min_buy_volume_ratio"] += 0.6
        rules["take_profit_1_pct"] -= 0.01
        rules["take_profit_2_pct"] -= 0.015
        rules["max_hold_days"] -= 2


def _apply_emotion_adjustments(rules: Dict[str, float], emotion_modifier: float) -> None:
    if emotion_modifier <= 0.65:
        rules["max_chase_pct"] -= 1.0
        rules["min_buy_volume_ratio"] += 0.35
        rules["take_profit_1_pct"] -= 0.006
        rules["take_profit_2_pct"] -= 0.01
        rules["stop_loss_pct"] += 0.003
        rules["max_hold_days"] -= 1
    elif emotion_modifier < 0.83:
        rules["max_chase_pct"] -= 0.2
        rules["min_buy_volume_ratio"] += 0.1
        rules["stop_loss_pct"] += 0.001
    elif emotion_modifier < 0.95:
        rules["max_chase_pct"] -= 0.4
        rules["min_buy_volume_ratio"] += 0.15
        rules["take_profit_2_pct"] -= 0.003
    else:
        rules["max_chase_pct"] += 0.2
        rules["min_buy_volume_ratio"] -= 0.05


def _apply_score_adjustments(rules: Dict[str, float], score: float) -> None:
    if score >= 85:
        rules["max_chase_pct"] += 0.2
        rules["min_buy_volume_ratio"] -= 0.05
        rules["take_profit_2_pct"] += 0.004
    elif score < 70 and score > 0:
        rules["max_chase_pct"] -= 0.2
        rules["min_buy_volume_ratio"] += 0.1
        rules["stop_loss_pct"] += 0.001


def _apply_pick_type_adjustments(rules: Dict[str, float], pick_type: str) -> None:
    if pick_type == "leader_momentum":
        rules["stop_loss_pct"] = max(float(rules["stop_loss_pct"]), -0.0175)
        rules["take_profit_1_pct"] += 0.004
        rules["take_profit_2_pct"] += 0.008
        rules["max_hold_days"] = min(int(rules["max_hold_days"]), 3)
        rules["add_trigger_pct"] -= 0.002
        rules["min_buy_volume_ratio"] += 0.2
        rules["max_chase_pct"] += 0.7
    elif pick_type == "turnover_breakout":
        rules["stop_loss_pct"] = max(float(rules["stop_loss_pct"]), -0.0185)
        rules["take_profit_1_pct"] += 0.003
        rules["take_profit_2_pct"] += 0.01
        rules["max_hold_days"] += 1
        rules["add_trigger_pct"] -= 0.001
        rules["min_buy_volume_ratio"] -= 0.15
        rules["max_chase_pct"] += 0.2
    elif pick_type == "low_position_trend":
        rules["stop_loss_pct"] = min(float(rules["stop_loss_pct"]), -0.0195)
        rules["next_day_fail_pct"] = min(float(rules["next_day_fail_pct"]), -0.012)
        rules["take_profit_1_pct"] += 0.003
        rules["take_profit_2_pct"] += 0.02
        rules["max_hold_days"] += 2
        rules["add_trigger_pct"] += 0.006
        rules["add_ratio"] -= 0.12
        rules["min_buy_volume_ratio"] -= 0.55
        rules["max_chase_pct"] -= 1.0
    elif pick_type == "base_pivot_trend":
        rules["stop_loss_pct"] = min(float(rules["stop_loss_pct"]), -0.0198)
        rules["next_day_fail_pct"] = min(float(rules["next_day_fail_pct"]), -0.012)
        rules["take_profit_1_pct"] += 0.004
        rules["take_profit_2_pct"] += 0.024
        rules["max_hold_days"] += 2
        rules["add_trigger_pct"] += 0.008
        rules["add_ratio"] -= 0.15
        rules["min_buy_volume_ratio"] -= 0.65
        rules["max_chase_pct"] -= 1.2


def _normalize_rules(rules: Dict[str, float]) -> Dict[str, float]:
    rules["stop_loss_pct"] = round(_clamp(float(rules["stop_loss_pct"]), -0.02, -0.01), 4)
    rules["next_day_fail_pct"] = round(_clamp(float(rules["next_day_fail_pct"]), -0.03, -0.003), 4)
    rules["next_day_low_vol_ratio"] = round(_clamp(float(rules["next_day_low_vol_ratio"]), 0.6, 2.0), 3)
    rules["take_profit_1_pct"] = round(_clamp(float(rules["take_profit_1_pct"]), 0.03, 0.09), 4)
    rules["take_profit_2_pct"] = round(_clamp(float(rules["take_profit_2_pct"]), 0.05, 0.14), 4)
    rules["add_trigger_pct"] = round(_clamp(float(rules["add_trigger_pct"]), 0.01, 0.04), 4)
    rules["add_ratio"] = round(_clamp(float(rules["add_ratio"]), 0.25, 0.75), 4)
    rules["max_chase_pct"] = round(_clamp(float(rules["max_chase_pct"]), 0.5, 6.0), 3)
    rules["min_buy_volume_ratio"] = round(_clamp(float(rules["min_buy_volume_ratio"]), 0.8, 3.0), 3)
    rules["max_hold_days"] = int(_clamp(int(rules["max_hold_days"]), 1, 6))
    return rules


def get_runtime_trade_rules(
    zone: str,
    emotion: str,
    score: float = 0.0,
    pick_type: str = "",
) -> Dict[str, float]:
    rules = load_base_trade_rules()
    _apply_zone_adjustments(rules, zone)
    _apply_emotion_adjustments(rules, get_emotion_modifier(emotion))
    _apply_score_adjustments(rules, score)
    _apply_pick_type_adjustments(rules, pick_type)
    rules = _normalize_rules(rules)
    rules["position_policy"] = get_position_policy(zone, emotion)
    return rules
