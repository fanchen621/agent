# DragonFlow 版本变更记录

## v2.3 [2026-04-09]
- **来源**：用户上传 DragonFlow_v2_3---1c9b703b-5c73-41c1-a2ae-4e6d1c3d9bdd.zip
- **部署时间**：2026-04-09 08:55
- **升级内容**：
  - 新增 engine/realtime_watch.py（重构版）
  - 新增 strategy/emotion_cycle.py
  - 新增 strategy/adaptive_selector.py
  - 新增 selfheal/diagnostics.py
  - feeds/akshare_data.py 更新
- **备份**：DragonFlow_v2.2_backup_20260409_085131
- **运行状态**：✅ 正常运行（AutoPilot PID=565990）

### PAD情感集成方案
- **架构**：独立模块 + 新版接口
- **模块**：
  - pad_sentiment_bridge.py：PAD×DragonFlow组合modifier
  - pad_status_reader.py：外部查询PAD状态
- **原理**：市场情绪modifier × 主人情绪modifier = 最终调整系数
- **说明**：新版架构下PAD作为独立模块被查询，不修改DragonFlow核心

---

## v2.2 [2026-04-08]
- **部署时间**：2026-04-09（已删除）
- **备份**：DragonFlow_v2.2_backup_20260409_085131（已删除）

---

## v2.1 [2026-04-08]
- **部署时间**：2026-04-08 15:00
- **状态**：已升级至v2.3
