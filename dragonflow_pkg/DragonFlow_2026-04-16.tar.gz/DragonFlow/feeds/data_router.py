"""
DragonFlow 数据源路由层
═══════════════════════════════════════════════════════════════════════════════════════
设计：三级数据源分层 + 自动探活 + 成功率反馈
═══════════════════════════════════════════════════════════════════════════════════════

Tier 1（核心）：EastMoney → 涨停池/龙虎榜/资金流
Tier 2（备用）：新浪VIP / 腾讯行情 → 实时价格/指数
Tier 3（兜底）：本地缓存（T+1 快照）

新增（2026-04-13）：
  - curl_cffi JA3指纹模拟（Chrome120 TLS握手指纹）
  - tenacity 指数退避重试（1s→2s→4s→8s）
  - Cloudflare Worker 反向代理（隐藏VPS真实IP，突破单IP QPS限制）
"""

from __future__ import annotations

import json
import logging
import os
import time
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, date
from pathlib import Path
from typing import Dict, List, Optional

from feeds.proxy_engine import get_pool_status

logger = logging.getLogger("feeds.data_router")


# ── curl_cffi + tenacity 客户端导入 ───────────────────────────────────────────
try:
    from feeds.curl_client import (
        get as _curl_get,
        UpstreamError as _UpstreamError,
    )
    _HAS_CURL_CFFI = True
except ImportError:
    _HAS_CURL_CFFI = False
    import urllib.request, urllib.error
    _UpstreamError = Exception

    def _curl_get(url, timeout=8.0, **kw):
        headers = kw.get("headers", {})
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="ignore")


# ── Cloudflare Worker 端点（部署后替换 YOUR_SUBDOMAIN） ────────────────────────
# ⚠️  部署 Cloudflare Worker 后，替换为你的 worker URL
# Cloudflare Worker 已部署到 foxpy.cc.cd
_CF_BASE = "https://foxpy.cc.cd"


# ════════════════════════════════════════════════════════════════════════════════
# 数据源定义
# ════════════════════════════════════════════════════════════════════════════════

@dataclass
class DataSource:
    name: str
    tier: int                      # 1=核心 2=备用 3=兜底
    url: str
    referer: str = ""
    encoding: str = "utf-8"
    timeout: float = 6.0
    method: str = "curl_cffi"      # curl_cffi | urllib | curl
    headers: Dict[str, str] = field(default_factory=dict)
    # 健康状态
    ok: bool = True
    consecutive_fails: int = 0
    total_requests: int = 0
    failed_requests: int = 0
    avg_latency: float = 0.0
    last_try: float = 0.0

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 1.0
        return 1.0 - (self.failed_requests / self.total_requests)

    def record(self, ok: bool, latency: float):
        self.total_requests += 1
        if not ok:
            self.failed_requests += 1
            self.consecutive_fails += 1
        else:
            self.consecutive_fails = 0
        self.last_try = time.time()
        # 滑动平均延迟
        if latency > 0:
            self.avg_latency = self.avg_latency * 0.7 + latency * 0.3


# ════════════════════════════════════════════════════════════════════════════════
# 数据源配置（全部走 CF Worker 代理 → 隐藏真实IP）
# ════════════════════════════════════════════════════════════════════════════════

_TIER1: List[DataSource] = [
    DataSource(
        name="eastmoney_clist",
        tier=1,
        url=f"{_CF_BASE}/eastmoney/clist",
        referer="https://quote.eastmoney.com",
        method="curl_cffi",
    ),
    DataSource(
        name="eastmoney_ulist",
        tier=1,
        url=f"{_CF_BASE}/eastmoney/ulist",
        referer="https://quote.eastmoney.com",
        method="curl_cffi",
    ),
]

_TIER2: List[DataSource] = [
    DataSource(
        name="sina_vip",
        tier=2,
        url=f"{_CF_BASE}/sina/vip",
        referer="https://finance.sina.com.cn",
        method="curl_cffi",
    ),
    DataSource(
        name="tencent_quote",
        tier=2,
        url=f"{_CF_BASE}/tencent/quote",
        referer="https://finance.qq.com",
        method="curl_cffi",
    ),
    DataSource(
        name="sina_hq",
        tier=2,
        url=f"{_CF_BASE}/sina/hq",
        referer="https://finance.sina.com.cn",
        method="curl_cffi",
        encoding="gbk",
        timeout=4.0,
    ),
]

_ALL_SOURCES: List[DataSource] = _TIER1 + _TIER2
_SOURCE_MAP: Dict[str, DataSource] = {s.name: s for s in _ALL_SOURCES}
_ROUTER_LOCK = threading.RLock()


# ════════════════════════════════════════════════════════════════════════════════
# 缓存管理
# ════════════════════════════════════════════════════════════════════════════════

class CacheManager:
    """本地缓存兜底层（T+1 快照）"""

    @staticmethod
    def default_cache_dir() -> str:
        openclaw_data = os.environ.get("OPENCLAW_DATA_DIR", "").strip()
        if openclaw_data:
            return str(Path(openclaw_data) / "cache")
        root_dir = Path(__file__).resolve().parents[1]
        return str(root_dir / "data" / "cache")

    def __init__(self, cache_dir: str | None = None):
        self.cache_dir = str(Path(cache_dir or self.default_cache_dir()).resolve())
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
        except Exception:
            fallback = Path.cwd() / "data" / "cache"
            fallback.mkdir(parents=True, exist_ok=True)
            self.cache_dir = str(fallback.resolve())

    def _path(self, key: str) -> str:
        import os
        safe = key.replace("/", "_").replace(":", "_")
        return os.path.join(self.cache_dir, f"{safe}.json")

    def get(self, key: str, max_age_seconds: int = 86400) -> Optional[dict]:
        """获取缓存，max_age_seconds 内有效"""
        import os, json
        p = self._path(key)
        if not os.path.exists(p):
            return None
        mtime = os.path.getmtime(p)
        if time.time() - mtime > max_age_seconds:
            return None
        try:
            with open(p) as f:
                return json.load(f)
        except Exception:
            return None

    def set(self, key: str, data: dict):
        """写入缓存"""
        import os, json
        p = self._path(key)
        try:
            with open(p, "w") as f:
                json.dump(data, f, ensure_ascii=False, default=str)
        except Exception as e:
            logger.debug(f"[cache] set failed {key}: {e}")

    def clear_stale(self, max_age_seconds: int = 86400 * 7):
        """清理过期缓存"""
        import os
        count = 0
        now = time.time()
        for fn in os.listdir(self.cache_dir):
            if not fn.endswith(".json"):
                continue
            p = os.path.join(self.cache_dir, fn)
            if now - os.path.getmtime(p) > max_age_seconds:
                try:
                    os.remove(p)
                    count += 1
                except Exception:
                    pass
        if count:
            logger.info(f"[cache] cleared {count} stale files")


_cache = CacheManager()


# ════════════════════════════════════════════════════════════════════════════════
# 底层 HTTP 获取（curl_cffi + tenacity 自动重试）
# ════════════════════════════════════════════════════════════════════════════════

def _fetch_text(source: DataSource, url: str) -> str:
    """
    使用 curl_cffi 获取文本（Chrome120 TLS指纹 + tenacity 4次重试）。
    失败时自动指数退避（1s → 2s → 4s → 8s）。
    """
    if not _HAS_CURL_CFFI:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=source.timeout) as resp:
            return resp.read().decode(source.encoding, errors="ignore")

    # curl_cffi：模拟 Chrome120 TLS 指纹，自动 tenacity 重试
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": source.referer or "https://finance.sina.com.cn",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }

    # url 已是 CF Worker 完整 URL，直接用
    return _curl_get(
        url,
        headers=headers,
        timeout=source.timeout,
    )


# ════════════════════════════════════════════════════════════════════════════════
# 数据源路由器
# ════════════════════════════════════════════════════════════════════════════════

class DataRouter:
    """
    三级数据源路由 + 自动探活 + 成功率反馈：

    fetch() → Tier1 核心源
             ↓ 失败
             Tier2 备用源
             ↓ 失败
             Tier3 本地缓存
             ↓ 失败
             返回 None

    自动维护每个数据源的：
    - 连续失败计数（≥3 降级）
    - 成功率统计
    - 平均延迟
    """

    def __init__(self):
        self.tier1: List[DataSource] = _TIER1
        self.tier2: List[DataSource] = _TIER2
        self.cache = _cache
        self._probing = False

    def fetch(self, key: str, url: str = "",
              tier_override: int = 0, use_cache: bool = True) -> Optional[dict]:
        """
        获取数据，自动走三级 fallback。

        key: 缓存key
        url: 完整CF Worker URL（e.g. https://dragonflow-proxy.workers.dev/eastmoney/clist）
        tier_override: 强制使用指定tier（0=自动）
        """
        if use_cache:
            cached = self.cache.get(key)
            if cached:
                logger.debug(f"[router] cache hit: {key}")
                return cached

        candidates: List[DataSource] = []
        if tier_override > 0:
            candidates = [s for s in _ALL_SOURCES if s.tier == tier_override]
        else:
            candidates = self.tier1 + self.tier2

        for source in candidates:
            if not source.ok and source.consecutive_fails >= 3:
                continue

            result = self._fetch_one(source, url or source.url)
            if result is not None:
                if use_cache:
                    self.cache.set(key, result)
                return result

        # 兜底：本地缓存
        if use_cache:
            cached = self.cache.get(key, max_age_seconds=86400 * 3)
            if cached:
                logger.warning(f"[router] {key} 使用3天缓存兜底")
                return cached

        logger.warning(f"[router] {key} 全链路失败，返回None")
        return None

    def _fetch_one(self, source: DataSource, url: str) -> Optional[dict]:
        """单源获取（curl_cffi + 自动重试）"""
        start = time.time()
        try:
            text = _fetch_text(source, url)
            latency = time.time() - start
            source.record(True, latency)
            if text:
                try:
                    return json.loads(text)
                except Exception:
                    return {"raw": text}
        except _UpstreamError as e:
            latency = time.time() - start
            source.record(False, latency)
            logger.debug(f"[router] {source.name} failed: {e}")
        except Exception as e:
            latency = time.time() - start
            source.record(False, latency)
            logger.debug(f"[router] {source.name} error: {e}")
        return None

    def probe_all(self) -> dict:
        """探活所有数据源（启动时调用）"""
        results = []
        for source in _ALL_SOURCES:
            start = time.time()
            ok = False
            try:
                text = _fetch_text(source, source.url)
                ok = len(text) > 20
            except Exception:
                pass
            latency = time.time() - start
            source.record(ok, latency)
            results.append({
                "name": source.name,
                "tier": source.tier,
                "ok": ok,
                "latency": round(latency, 3),
                "success_rate": round(source.success_rate, 3),
                "consecutive_fails": source.consecutive_fails,
            })
            if ok:
                logger.info(f"[router] {source.name} ✅ {latency:.2f}s")
            else:
                logger.warning(f"[router] {source.name} ❌")

        return {
            "probed_at": time.time(),
            "results": results,
        }

    def get_status(self) -> dict:
        """返回路由状态（供 Dashboard）"""
        return {
            "tier1": [{
                "name": s.name, "ok": s.ok, "success_rate": round(s.success_rate, 3),
                "avg_latency": round(s.avg_latency, 3),
                "consecutive_fails": s.consecutive_fails,
                "total": s.total_requests,
            } for s in self.tier1],
            "tier2": [{
                "name": s.name, "ok": s.ok, "success_rate": round(s.success_rate, 3),
                "avg_latency": round(s.avg_latency, 3),
                "consecutive_fails": s.consecutive_fails,
                "total": s.total_requests,
            } for s in self.tier2],
            "cf_worker_base": _CF_BASE,
        }

    def switch_data_source_if_needed(self, threshold: float = 0.6):
        """
        反馈驱动：成功率低于 threshold 时自动降级。
        由 autopilot 在每日收盘后调用。
        """
        switched = []
        for source in _ALL_SOURCES:
            if source.total_requests < 10:
                continue
            if source.success_rate < threshold:
                source.ok = False
                switched.append(source.name)
                logger.warning(
                    f"[router] {source.name} 成功率{source.success_rate:.1%} < {threshold:.0%}，已降级"
                )
        return switched


# ════════════════════════════════════════════════════════════════════════════════
# 全局单例
# ════════════════════════════════════════════════════════════════════════════════

_router: Optional[DataRouter] = None


def get_router() -> DataRouter:
    global _router
    if _router is None:
        _router = DataRouter()
    return _router
