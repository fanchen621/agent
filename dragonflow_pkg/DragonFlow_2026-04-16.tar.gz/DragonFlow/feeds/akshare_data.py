"""
深度数据源（全代理模式，彻底解决腾讯云IP封禁）
═══════════════════════════════════════════════════════════════════════════
所有金融数据请求统一走 proxy_engine.proxied_get()，
通过 HTTPS 高匿代理 + IP 自动轮换访问数据源。

akshare 仅用于涨停池/龙虎榜等无法手动构造的接口，
且通过注入代理 session 使其也走代理出网。
其余接口全部直接构造 HTTP 请求 → proxied_get()。
"""
from __future__ import annotations

import datetime
import hashlib
import json
import random
import time
import functools
import re
import secrets
import threading
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import StringIO
from typing import Dict, List, Optional, Tuple

import pandas as pd
import requests
from bs4 import BeautifulSoup
from loguru import logger

from config import DATA_SOURCE_CONFIG
from feeds.proxy_engine import proxied_get, get_proxied_session, ensure_pool_ready

# ─── akshare 注入代理 ────────────────────────────────────────────────────────
try:
    import akshare as ak
    # 每次调用前刷新 akshare 内部 session 的代理
    _ak_original_session = None
except ImportError:
    ak = None


def _patch_akshare_proxy():
    """给 akshare 注入代理 session"""
    if not ak:
        return
    try:
        import requests as req_lib
        sess = get_proxied_session()
        if sess:
            # akshare 内部用 requests.get/post，我们替换掉
            req_lib.Session = lambda: sess
    except Exception:
        pass


# ─── TTL 缓存 ────────────────────────────────────────────────────────────────
_cache: Dict[str, Tuple[float, object]] = {}
_spot_snapshot_lock = threading.Lock()
_eastmoney_auth_lock = threading.Lock()
_endpoint_failure_lock = threading.Lock()
_endpoint_failures: Dict[str, Tuple[float, int]] = {}


def _cached(key: str, ttl: int = 60):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            now = time.time()
            if key in _cache:
                ts, val = _cache[key]
                if now - ts < ttl:
                    return val
            result = fn(*args, **kwargs)
            _cache[key] = (now, result)
            return result
        return wrapper
    return decorator


def clear_cache():
    _cache.clear()


def _get_cache_value(key: str, ttl: int):
    now = time.time()
    cached = _cache.get(key)
    if not cached:
        return None
    ts, value = cached
    if now - ts >= ttl:
        return None
    return value


def _set_cache_value(key: str, value) -> None:
    _cache[key] = (time.time(), value)


def _is_eastmoney_url(url: str) -> bool:
    return "eastmoney.com" in (url or "")


def _generate_eastmoney_fingerprint() -> str:
    return hashlib.md5(str(uuid.uuid4()).encode("utf-8")).hexdigest()


def _generate_st_nvi() -> str:
    charset = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict"
    random_str = "".join(secrets.choice(charset) for _ in range(21))
    suffix = hashlib.sha256(random_str.encode("utf-8")).hexdigest()[:4]
    return random_str + suffix


def _get_eastmoney_nid(user_agent: str) -> str:
    cache_key = "eastmoney_nid18"
    cached = _get_cache_value(cache_key, 20)
    if cached:
        return str(cached)

    with _eastmoney_auth_lock:
        cached = _get_cache_value(cache_key, 20)
        if cached:
            return str(cached)
        try:
            payload = {
                "osPlatform": "Windows",
                "sourceType": "WEB",
                "osversion": "Windows 10.0",
                "language": "zh-CN",
                "timezone": "Asia/Shanghai",
                "webDeviceInfo": {
                    "screenResolution": random.choice(["1920X1080", "2560X1440", "3840X2160"]),
                    "userAgent": user_agent,
                    "canvasKey": _generate_eastmoney_fingerprint(),
                    "webglKey": _generate_eastmoney_fingerprint(),
                    "fontKey": _generate_eastmoney_fingerprint(),
                    "audioKey": _generate_eastmoney_fingerprint(),
                },
            }
            response = requests.post(
                "https://anonflow2.eastmoney.com/backend/api/webreport",
                headers={
                    "Content-Type": "application/json",
                    "Cookie": f"st_nvi={_generate_st_nvi()}",
                    "User-Agent": user_agent,
                },
                json=payload,
                timeout=3.0,
            )
            response.raise_for_status()
            nid = str(((response.json() or {}).get("data") or {}).get("nid") or "").strip()
            if nid:
                _set_cache_value(cache_key, nid)
                return nid
        except Exception as exc:
            logger.debug(f"[data] eastmoney nid fetch failed: {exc}")
        return ""


def _build_request_headers(url: str, referer: str = "") -> Dict[str, str]:
    user_agent = random.choice(DATA_SOURCE_CONFIG["user_agents"])
    headers = {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/json,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
    }
    if referer:
        headers["Referer"] = referer
    if _is_eastmoney_url(url):
        nid = _get_eastmoney_nid(user_agent)
        if nid:
            headers["Cookie"] = f"nid18={nid}"
    return headers


def _is_endpoint_temporarily_blocked(endpoint: str, threshold: int = 3, ttl: float = 20.0) -> bool:
    with _endpoint_failure_lock:
        state = _endpoint_failures.get(endpoint)
        if not state:
            return False
        last_ts, fail_count = state
        if time.time() - last_ts >= ttl:
            _endpoint_failures.pop(endpoint, None)
            return False
        return fail_count >= threshold


def _record_endpoint_failure(endpoint: str, ttl: float = 20.0) -> None:
    with _endpoint_failure_lock:
        last_ts, fail_count = _endpoint_failures.get(endpoint, (0.0, 0))
        if time.time() - last_ts >= ttl:
            fail_count = 0
        _endpoint_failures[endpoint] = (time.time(), fail_count + 1)


def _record_endpoint_success(endpoint: str) -> None:
    with _endpoint_failure_lock:
        _endpoint_failures.pop(endpoint, None)


def _direct_request_text(
    url: str,
    referer: str = "",
    encoding: Optional[str] = "utf-8",
    timeout: float = 6.0,
    params: Optional[Dict] = None,
) -> str:
    headers = _build_request_headers(url, referer=referer)
    response = requests.get(url, params=params, headers=headers, timeout=timeout)
    response.raise_for_status()
    if encoding:
        response.encoding = encoding
        return response.text
    return response.text


def _direct_request_json(
    url: str,
    referer: str = "",
    timeout: float = 6.0,
    params: Optional[Dict] = None,
) -> Dict:
    text = _direct_request_text(url, referer=referer, encoding="utf-8", timeout=timeout, params=params)
    data = json.loads(text)
    return data if isinstance(data, dict) else {}


def _request_text_direct_first(
    url: str,
    referer: str = "",
    timeout: float = 3.0,
    params: Optional[Dict] = None,
    encoding: Optional[str] = "utf-8",
) -> str:
    headers = _build_request_headers(url, referer=referer)
    try:
        response = requests.get(url, params=params, headers=headers, timeout=timeout)
        response.raise_for_status()
        if encoding:
            response.encoding = encoding
            return response.text
        return response.text
    except Exception:
        return proxied_get(
            url,
            referer=referer,
            encoding=encoding or "utf-8",
            timeout=timeout,
            params=params,
            max_retries=1,
            headers=headers,
        )


def _request_json_direct_first(
    url: str,
    referer: str = "",
    timeout: float = 3.0,
    params: Optional[Dict] = None,
    encoding: str = "utf-8",
) -> Dict:
    headers = _build_request_headers(url, referer=referer)
    try:
        response = requests.get(url, params=params, headers=headers, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        if data:
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    text = proxied_get(
        url,
        referer=referer,
        encoding=encoding,
        timeout=timeout,
        params=params,
        max_retries=1,
        headers=headers,
    )
    data = json.loads(text)
    return data if isinstance(data, dict) else {}


def _fetch_tencent_quote_fields(code: str) -> List[str]:
    cache_key = f"tencent_quote:{code}"
    cached = _get_cache_value(cache_key, 30)
    if cached is not None:
        return cached

    symbol = f"{_guess_market(code)}{_normalize_stock_code(code)}"
    url = f"https://qt.gtimg.cn/q={symbol}"
    text = _request_text_direct_first(url, referer="https://gu.qq.com", timeout=4.0)
    payload = text.split("=\"", 1)[1].rsplit("\";", 1)[0]
    parts = payload.split("~")
    _set_cache_value(cache_key, parts)
    return parts


_AK_CALL_TIMEOUT = 2.0  # akshare单次调用超时，防止无限阻塞

def _safe_ak_call(fn, *args, retries=1, retry_sleep: float = 0.3, **kwargs):
    """安全调用 akshare（注入代理 + 重试 + 超时保护）"""
    for attempt in range(retries):
        _patch_akshare_proxy()
        result_holder = [None]
        exc_holder = [None]

        def _call():
            try:
                result_holder[0] = fn(*args, **kwargs)
            except Exception as e:
                exc_holder[0] = e

        t = threading.Thread(target=_call, daemon=True)
        t.start()
        t.join(timeout=_AK_CALL_TIMEOUT)
        if t.is_alive():
            # 超时，强制跳过
            logger.debug(f"[akshare] {fn.__name__} 超时({_AK_CALL_TIMEOUT}s)，切换方式")
            if attempt < retries - 1:
                time.sleep(retry_sleep)
                continue
            return None
        if exc_holder[0]:
            if attempt < retries - 1:
                time.sleep(retry_sleep)
                continue
            raise exc_holder[0]
        result = result_holder[0]
        if result is not None:
            return result
        if attempt < retries - 1:
            time.sleep(retry_sleep)
            continue
    return None


# ════════════════════════════════════════════════════════════════════════════
# 涨停池
# ════════════════════════════════════════════════════════════════════════════

@_cached("zt_pool", ttl=120)
def get_zt_pool(date: Optional[str] = None) -> pd.DataFrame:
    if not date:
        date = datetime.date.today().strftime("%Y%m%d")

    # 方式1: 直接HTTP走代理
    try:
        url = (f"https://push2ex.eastmoney.com/getTopicZTPool?"
               f"ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.ztzt&"
               f"Ession=f&date={date}&_={int(time.time()*1000)}")
        text = proxied_get(url, referer="https://quote.eastmoney.com", timeout=5.0, max_retries=1)
        data = json.loads(text)
        pool = data.get("data", {}).get("pool", [])
        if pool:
            rows = []
            for item in pool:
                rows.append({
                    "代码": item.get("c", ""),
                    "名称": item.get("n", ""),
                    "涨跌幅": item.get("zdp", 0),
                    "最新价": item.get("p", 0) / 1000 if item.get("p") else 0,
                    "成交额": item.get("amount", 0),
                    "流通市值": item.get("ltsz", 0),
                    "连板数": item.get("days", 1),
                    "首次涨停时间": item.get("fbt", ""),
                })
            logger.info(f"[数据] 涨停池(代理): {len(rows)}只")
            return pd.DataFrame(rows)
    except Exception as e:
        logger.debug(f"[数据] 代理涨停池失败: {e}")

    # 方式2: akshare（也走代理了）
    if ak:
        try:
            df = _safe_ak_call(ak.stock_zt_pool_em, date=date)
            if df is not None and not df.empty:
                return df
        except Exception:
            pass

    return pd.DataFrame()


def get_zt_stats(date: Optional[str] = None) -> Dict:
    df = get_zt_pool(date)
    if df.empty:
        return {"zt_count": 0, "highest_board": 0, "broken_rate": 0.0,
                "consecutive_ladder": {}}

    zt_count = len(df)
    board_col = None
    for c in ["连板数", "连续涨停天数", "days"]:
        if c in df.columns:
            board_col = c
            break
    highest_board = int(df[board_col].max()) if board_col else 1

    ladder: Dict[int, List[Dict]] = {}
    if board_col:
        for _, row in df.iterrows():
            days = int(row.get(board_col, 1) or 1)
            name = str(row.get("名称", ""))
            code = str(row.get("代码", ""))
            ladder.setdefault(days, []).append({"name": name, "code": code})

    # 炸板率
    broken_rate = 0.0
    if not date:
        date = datetime.date.today().strftime("%Y%m%d")
    try:
        url = (f"https://push2ex.eastmoney.com/getTopicZBPool?"
               f"ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.ztzt&"
               f"date={date}&_={int(time.time()*1000)}")
        text = proxied_get(url, referer="https://quote.eastmoney.com", timeout=5.0, max_retries=1)
        data = json.loads(text)
        zb_pool = data.get("data", {}).get("pool", [])
        broken_count = len(zb_pool)
        broken_rate = broken_count / (zt_count + broken_count) if (zt_count + broken_count) > 0 else 0
    except Exception:
        pass

    return {
        "zt_count": zt_count,
        "highest_board": highest_board,
        "broken_rate": round(broken_rate, 3),
        "consecutive_ladder": dict(sorted(ladder.items(), key=lambda x: x[0], reverse=True)),
    }


# ════════════════════════════════════════════════════════════════════════════
# 龙虎榜
# ════════════════════════════════════════════════════════════════════════════

@_cached("lhb", ttl=300)
def get_lhb(date: Optional[str] = None) -> pd.DataFrame:
    if not date:
        date = datetime.date.today().strftime("%Y%m%d")
    if ak:
        for fn_name in ["stock_lhb_detail_em", "stock_lhb_ggtj_dtl_em", "stock_lhb_jgmmtj_em"]:
            fn = getattr(ak, fn_name, None)
            if fn is None:
                continue
            try:
                df = _safe_ak_call(fn, start_date=date, end_date=date)
                if df is not None and not df.empty:
                    return df
            except Exception:
                pass
    return pd.DataFrame()


# ════════════════════════════════════════════════════════════════════════════
# 板块资金流向
# ════════════════════════════════════════════════════════════════════════════

@_cached("sector_flow", ttl=120)
def get_sector_flow() -> List[Dict]:
    try:
        url = ("https://push2.eastmoney.com/api/qt/clist/get?"
               "fid=f62&po=1&pz=20&np=1&fltt=2&invt=2&"
               "fs=m:90+t:2&fields=f12,f14,f3,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f204,f205,f124"
               f"&ut=b2884a393a59ad64002292a3e90d46a5&_={int(time.time()*1000)}")
        text = proxied_get(url, referer="https://data.eastmoney.com")
        data = json.loads(text)
        result = []
        for item in (data.get("data", {}).get("diff", []) or [])[:15]:
            name = item.get("f14", "")
            pct = item.get("f3", 0)
            net_flow = item.get("f62", 0)
            if name:
                result.append({
                    "name": str(name),
                    "change_pct": round(float(pct), 2) if pct else 0,
                    "net_flow": round(float(net_flow), 2) if net_flow else 0,
                })
        if result:
            logger.debug(f"[数据] 板块资金(代理): {len(result)}条")
            return result
    except Exception as e:
        logger.debug(f"[数据] 代理板块资金失败: {e}")
    return []


def get_main_net_flow() -> float:
    sectors = get_sector_flow()
    if not sectors:
        return 0.0
    total = sum(s.get("net_flow", 0) for s in sectors)
    return round(total / 1e8, 2) if abs(total) > 1e6 else round(total, 2)


# ════════════════════════════════════════════════════════════════════════════
# 市场宽度
# ════════════════════════════════════════════════════════════════════════════

@_cached("market_breadth", ttl=60)
def get_market_breadth() -> Dict:
    result = {
        "up_count": 0, "down_count": 0, "flat_count": 0,
        "up_down_ratio": 1.0, "zt_count": 0, "dt_count": 0,
    }

    # 方式1: 东方财富全市场 API 走代理
    try:
        url = ("https://push2.eastmoney.com/api/qt/clist/get?"
               "pn=1&pz=5000&po=1&np=1&fltt=2&invt=2&fid=f3&"
               "fs=m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23&"
               "fields=f3&"
               f"ut=b2884a393a59ad64002292a3e90d46a5&_={int(time.time()*1000)}")
        text = proxied_get(url, referer="https://quote.eastmoney.com", timeout=5.0, max_retries=1)
        data = json.loads(text)
        diff = data.get("data", {}).get("diff", [])
        if diff:
            ups = sum(1 for x in diff if (x.get("f3") or 0) > 0)
            downs = sum(1 for x in diff if (x.get("f3") or 0) < 0)
            flats = len(diff) - ups - downs
            zt = sum(1 for x in diff if (x.get("f3") or 0) >= 9.8)
            dt = sum(1 for x in diff if (x.get("f3") or 0) <= -9.8)
            result["up_count"] = ups
            result["down_count"] = downs
            result["flat_count"] = flats
            result["up_down_ratio"] = round(ups / max(downs, 1), 2)
            result["zt_count"] = zt
            result["dt_count"] = dt
            logger.debug(f"[数据] 市场宽度(代理): 涨{ups} 跌{downs} 涨停{zt}")
            return result
    except Exception as e:
        logger.debug(f"[数据] 代理市场宽度失败: {e}")

    # 方式2: 从指数估算
    try:
        from feeds.resilient import resilient_fetch_indices
        indices = resilient_fetch_indices()
        sh_pct = 0
        for idx in indices:
            if idx.get("code") == "sh000001":
                sh_pct = idx.get("pct", 0)
                break
        if sh_pct > 1:
            result.update(up_count=3000, down_count=1500, up_down_ratio=2.0)
        elif sh_pct > 0:
            result.update(up_count=2500, down_count=2000, up_down_ratio=1.25)
        elif sh_pct > -1:
            result.update(up_count=2000, down_count=2500, up_down_ratio=0.8)
        else:
            result.update(up_count=1500, down_count=3000, up_down_ratio=0.5)
        zt = get_zt_stats()
        result["zt_count"] = zt.get("zt_count", 0)
    except Exception:
        pass

    return result


# ════════════════════════════════════════════════════════════════════════════
# 北向资金
# ════════════════════════════════════════════════════════════════════════════

def _eastmoney_payload(text: str) -> Dict:
    data = json.loads(text)
    payload = data.get("data") or {}
    return payload if isinstance(payload, dict) else {}


@_cached("zt_pool", ttl=1.0)
def get_zt_pool(date: Optional[str] = None) -> pd.DataFrame:
    if not date:
        date = datetime.date.today().strftime("%Y%m%d")

    try:
        url = (
            "https://push2ex.eastmoney.com/getTopicZTPool?"
            "ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.ztzt&"
            f"Ession=f&date={date}&_={int(time.time() * 1000)}"
        )
        pool = _request_json_direct_first(
            url,
            referer="https://quote.eastmoney.com",
            timeout=3.0,
        ).get("data") or {}
        pool = pool.get("pool") or []
        if pool:
            rows = []
            for item in pool:
                rows.append({
                    "code": str(item.get("c") or "").strip(),
                    "name": str(item.get("n") or "").strip(),
                    "change_pct": round(_parse_number(item.get("zdp")), 2),
                    "latest_price": round(_parse_number(item.get("p")) / 1000, 3) if item.get("p") else 0.0,
                    "amount": round(_parse_number(item.get("amount")), 2),
                    "float_market_cap": round(_parse_number(item.get("ltsz")), 2),
                    "days": int(_parse_number(item.get("days")) or 1),
                    "first_limit_time": str(item.get("fbt") or ""),
                })
            normalized = [row for row in rows if row["code"]]
            if normalized:
                return pd.DataFrame(normalized)
    except Exception as exc:
        logger.debug(f"[data] direct zt pool fetch failed: {exc}")

    if ak:
        try:
            df = _safe_ak_call(ak.stock_zt_pool_em, date=date)
            if df is not None and not df.empty:
                code_col = _find_column(df.columns, ["code", "symbol", "代码", "证券代码"])
                name_col = _find_column(df.columns, ["name", "名称", "股票简称"])
                pct_col = _find_column(df.columns, ["change", "pct", "涨跌幅", "涨跌"])
                price_col = _find_column(df.columns, ["latest", "price", "最新价"])
                amount_col = _find_column(df.columns, ["amount", "成交额"])
                float_cap_col = _find_column(df.columns, ["float", "流通市值"])
                days_col = _find_column(df.columns, ["days", "board", "连板", "连续涨停"])
                first_limit_col = _find_column(df.columns, ["first", "首次涨停时间", "首次封板时间"])
                rows = []
                for _, row in df.iterrows():
                    code = str(row.get(code_col, "")).strip() if code_col else ""
                    if not code:
                        continue
                    rows.append({
                        "code": code.replace("sh", "").replace("sz", ""),
                        "name": str(row.get(name_col, "")).strip() if name_col else "",
                        "change_pct": round(_parse_number(row.get(pct_col, 0)) if pct_col else 0.0, 2),
                        "latest_price": round(_parse_number(row.get(price_col, 0)) if price_col else 0.0, 3),
                        "amount": round(_parse_number(row.get(amount_col, 0)) if amount_col else 0.0, 2),
                        "float_market_cap": round(_parse_number(row.get(float_cap_col, 0)) if float_cap_col else 0.0, 2),
                        "days": int(_parse_number(row.get(days_col, 1)) if days_col else 1),
                        "first_limit_time": str(row.get(first_limit_col, "")).strip() if first_limit_col else "",
                    })
                if rows:
                    return pd.DataFrame(rows)
        except Exception as exc:
            logger.debug(f"[data] akshare zt pool fetch failed: {exc}")

    return pd.DataFrame(columns=[
        "code", "name", "change_pct", "latest_price",
        "amount", "float_market_cap", "days", "first_limit_time",
    ])


def get_zt_stats(date: Optional[str] = None) -> Dict:
    df = get_zt_pool(date)
    if df.empty:
        return {
            "zt_count": 0,
            "highest_board": 0,
            "broken_rate": 0.0,
            "consecutive_ladder": {},
        }

    board_col = "days" if "days" in df.columns else _find_column(df.columns, ["days", "board", "连板"])
    code_col = "code" if "code" in df.columns else _find_column(df.columns, ["code", "symbol", "代码"])
    name_col = "name" if "name" in df.columns else _find_column(df.columns, ["name", "名称"])
    zt_count = len(df)
    highest_board = int(df[board_col].fillna(1).max()) if board_col else 1

    ladder: Dict[int, List[Dict]] = {}
    if board_col:
        for _, row in df.iterrows():
            days = int(_parse_number(row.get(board_col, 1)) or 1)
            ladder.setdefault(days, []).append({
                "name": str(row.get(name_col, "")).strip() if name_col else "",
                "code": str(row.get(code_col, "")).strip() if code_col else "",
            })

    broken_rate = 0.0
    if not date:
        date = datetime.date.today().strftime("%Y%m%d")
    try:
        url = (
            "https://push2ex.eastmoney.com/getTopicZBPool?"
            "ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.ztzt&"
            f"date={date}&_={int(time.time() * 1000)}"
        )
        broken_pool = _request_json_direct_first(
            url,
            referer="https://quote.eastmoney.com",
            timeout=3.0,
        ).get("data") or {}
        broken_pool = broken_pool.get("pool") or []
        broken_count = len(broken_pool)
        total = zt_count + broken_count
        broken_rate = (broken_count / total) if total > 0 else 0.0
    except Exception as exc:
        logger.debug(f"[data] broken-rate fetch failed: {exc}")

    return {
        "zt_count": zt_count,
        "highest_board": highest_board,
        "broken_rate": round(broken_rate, 3),
        "consecutive_ladder": dict(sorted(ladder.items(), key=lambda item: item[0], reverse=True)),
    }


@_cached("sector_flow", ttl=1.0)
def get_sector_flow() -> List[Dict]:
    try:
        import requests
        from io import StringIO
        from py_mini_racer import MiniRacer
        from akshare.stock_feature.stock_fund_flow import _get_file_content_ths

        js = MiniRacer()
        js.eval(_get_file_content_ths("ths.js"))
        headers = {
            "Accept": "text/html, */*; q=0.01",
            "hexin-v": js.call("v"),
            "Referer": "http://data.10jqka.com.cn/funds/hyzjl/",
            "User-Agent": random.choice(DATA_SOURCE_CONFIG["user_agents"]),
            "X-Requested-With": "XMLHttpRequest",
        }
        url = "http://data.10jqka.com.cn/funds/hyzjl/field/je/order/desc/page/1/ajax/1/free/1/"
        resp = requests.get(url, headers=headers, timeout=2.0)
        df = pd.read_html(StringIO(resp.text))[0]
        if df is not None and not df.empty:
            result = []
            for _, row in df.iterrows():
                name = str(row.get("行业", "")).strip()
                if not name:
                    continue
                result.append({
                    "name": name,
                    "change_pct": round(_parse_number(row.get("涨跌幅", 0)), 2),
                    "net_flow": round(_parse_number(row.get("净额(亿)", 0)) * 1e8, 2),
                })
            if result:
                return result[:15]
    except Exception as exc:
        logger.debug(f"[data] ths sector flow fetch failed: {exc}")

    try:
        url = (
            "https://push2.eastmoney.com/api/qt/clist/get?"
            "pn=1&pz=100&po=1&np=1&ut=b2884a393a59ad64002292a3e90d46a5&"
            "fltt=2&invt=2&fid0=f62&fs=m:90+t:2&stat=1&"
            "fields=f12,f14,f2,f3,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f204,f205,f124&"
            f"rt={int(time.time() * 1000)}"
        )
        diff = _request_json_direct_first(
            url,
            referer="https://data.eastmoney.com",
            timeout=2.5,
        ).get("data") or {}
        diff = diff.get("diff") or []
        result = []
        for item in diff:
            name = str(item.get("f14") or "").strip()
            if not name:
                continue
            result.append({
                "name": name,
                "change_pct": round(_parse_number(item.get("f3")), 2),
                "net_flow": round(_parse_number(item.get("f62")), 2),
            })
        if result:
            return result[:15]
    except Exception as exc:
        logger.debug(f"[data] eastmoney sector flow fetch failed: {exc}")

    return []


@_cached("market_breadth", ttl=1.0)
def get_market_breadth() -> Dict:
    result = {
        "up_count": 0,
        "down_count": 0,
        "flat_count": 0,
        "up_down_ratio": 1.0,
        "zt_count": 0,
        "dt_count": 0,
    }

    try:
        if ak:
            # akshare 东财接口在腾讯云会被封，快速失败不阻塞主流程
            df = _safe_ak_call(ak.stock_market_activity_legu, retries=1)
            field_map = _frame_to_field_map(df)
            if field_map:
                up_count = int(_parse_number(field_map.get("上涨")))
                down_count = int(_parse_number(field_map.get("下跌")))
                flat_count = int(_parse_number(field_map.get("平盘")))
                zt_count = int(_parse_number(field_map.get("真实涨停") or field_map.get("涨停")))
                dt_count = int(_parse_number(field_map.get("真实跌停") or field_map.get("跌停")))
                result.update(
                    up_count=up_count,
                    down_count=down_count,
                    flat_count=flat_count,
                    up_down_ratio=round(up_count / max(down_count, 1), 2),
                    zt_count=zt_count,
                    dt_count=dt_count,
                )
                return result
    except Exception as exc:
        logger.debug(f"[data] legu market breadth fetch failed: {exc}")

    try:
        # 东财 17.push2 域名在腾讯云超时，改用新浪市场数据（快速）
        import requests as _req_sina
        import urllib3
        urllib3.disable_warnings()
        sina_url = (
            "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php"
            "/Market_Center.getHQNodeData?page=1&num=3000&sort=changepercent&asc=0&node=hs_a&symbol=&_s_r_a=page"
        )
        headers = {"Referer": "https://finance.sina.com.cn", "User-Agent": "Mozilla/5.0"}
        resp = _req_sina.get(sina_url, headers=headers, timeout=5.0)
        rows = resp.json()
        if rows:
            ups = sum(1 for r in rows if float(r.get("pricechange", 0)) > 0)
            dns = sum(1 for r in rows if float(r.get("pricechange", 0)) < 0)
            zt = sum(1 for r in rows if float(r.get("pricechange", 0)) >= 9.8)
            dt = sum(1 for r in rows if float(r.get("pricechange", 0)) <= -9.8)
            result["up_count"] = ups
            result["down_count"] = dns
            result["flat_count"] = len(rows) - ups - dns
            result["up_down_ratio"] = round(ups / max(dns, 1), 2)
            result["zt_count"] = zt
            result["dt_count"] = dt
            return result
    except Exception as exc:
        logger.debug(f"[data] 新浪市场宽度失败: {exc}")

    try:
        from feeds.resilient import resilient_fetch_indices

        indices = resilient_fetch_indices()
        sh_pct = 0.0
        for idx in indices:
            if idx.get("code") == "sh000001":
                sh_pct = float(idx.get("pct", 0) or 0)
                break
        if sh_pct > 1:
            result.update(up_count=3000, down_count=1500, up_down_ratio=2.0)
        elif sh_pct > 0:
            result.update(up_count=2500, down_count=2000, up_down_ratio=1.25)
        elif sh_pct > -1:
            result.update(up_count=2000, down_count=2500, up_down_ratio=0.8)
        else:
            result.update(up_count=1500, down_count=3000, up_down_ratio=0.5)
    except Exception:
        pass

    return result


@_cached("north_flow", ttl=180)
def get_north_flow() -> float:
    try:
        url = ("https://push2.eastmoney.com/api/qt/kamtbs.wpt?"
               f"fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55,f56&"
               f"ut=b2884a393a59ad64002292a3e90d46a5&_={int(time.time()*1000)}")
        text = proxied_get(url, referer="https://data.eastmoney.com")
        data = json.loads(text)
        payload = data.get("data") or {}
        s2n = payload.get("s2n", [])
        if s2n:
            latest = s2n[-1].split(",")
            if len(latest) >= 2 and latest[1]:
                return round(float(latest[1]) / 1e8, 2)
    except Exception as e:
        logger.debug(f"[数据] 代理北向资金失败: {e}")
    return 0.0


# ════════════════════════════════════════════════════════════════════════════
# 财经新闻
# ════════════════════════════════════════════════════════════════════════════

@_cached("news", ttl=180)
def get_financial_news(limit: int = 10) -> List[Dict]:
    try:
        url = (f"https://np-listapi.eastmoney.com/comm/web/getNewsByColumns?"
               f"client=web&biz=web_home_fl&column=102&order=1&needInteractData=0&"
               f"page_index=1&page_size={limit}&req_trace={int(time.time()*1000)}")
        text = proxied_get(url, referer="https://kuaixun.eastmoney.com")
        data = json.loads(text)
        result = []
        payload = data.get("data") or {}
        for item in (payload.get("list", []) or [])[:limit]:
            title = item.get("title", "")
            if title:
                result.append({
                    "title": title,
                    "time": item.get("showTime", ""),
                    "source": "东方财富",
                    "importance": _judge_importance(title),
                })
        if result:
            return result
    except Exception as e:
        logger.debug(f"[数据] 代理新闻失败: {e}")
    return []


def _judge_importance(title: str) -> str:
    from config import NEWS_KEYWORDS_HIGH, NEWS_KEYWORDS_MID
    for kw in NEWS_KEYWORDS_HIGH:
        if kw in title:
            return "high"
    for kw in NEWS_KEYWORDS_MID:
        if kw in title:
            return "medium"
    return "low"


# ════════════════════════════════════════════════════════════════════════════
# 个股历史K线（腾讯/网易源走代理，不依赖东方财富）
# ════════════════════════════════════════════════════════════════════════════

def get_stock_history(code: str, days: int = 60) -> Optional[pd.DataFrame]:
    # 方式1: 腾讯K线（走代理）
    try:
        df = _fetch_history_tencent(code, days)
        if df is not None and len(df) >= 20:
            return df
    except Exception as e:
        logger.debug(f"[数据] {code} 腾讯K线失败: {e}")

    # 方式2: 网易K线（走代理）
    try:
        df = _fetch_history_netease(code, days)
        if df is not None and len(df) >= 20:
            return df
    except Exception as e:
        logger.debug(f"[数据] {code} 网易K线失败: {e}")

    return None


def _fetch_history_tencent(code: str, days: int = 60) -> Optional[pd.DataFrame]:
    code = code.strip()
    prefix = "sh" if code.startswith("6") else "sz"
    symbol = f"{prefix}{code}"
    end = datetime.date.today().strftime("%Y-%m-%d")
    start = (datetime.date.today() - datetime.timedelta(days=days * 2)).strftime("%Y-%m-%d")
    url = (f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
           f"param={symbol},day,{start},{end},{days * 2},qfq")
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": random.choice(DATA_SOURCE_CONFIG["user_agents"]),
            "Referer": "https://web.ifzq.gtimg.cn",
        })
        with urllib.request.urlopen(req, timeout=5) as resp:
            text = resp.read().decode("utf-8", errors="ignore")
    except Exception:
        text = proxied_get(url, referer="https://web.ifzq.gtimg.cn", timeout=4)
    data = json.loads(text)
    klines = (data.get("data", {}).get(symbol, {}).get("day")
              or data.get("data", {}).get(symbol, {}).get("qfqday")
              or [])
    if not klines:
        return None
    rows = []
    for k in klines:
        if len(k) >= 6:
            rows.append({
                "date": k[0], "open": float(k[1]), "close": float(k[2]),
                "high": float(k[3]), "low": float(k[4]), "volume": float(k[5]),
            })
    return pd.DataFrame(rows).tail(days) if rows else None


def _fetch_history_netease(code: str, days: int = 60) -> Optional[pd.DataFrame]:
    code = code.strip()
    prefix = "0" if code.startswith("6") else "1"
    symbol = f"{prefix}{code}"
    end = datetime.date.today().strftime("%Y%m%d")
    start = (datetime.date.today() - datetime.timedelta(days=days * 2)).strftime("%Y%m%d")
    url = (f"https://quotes.money.163.com/service/chddata.html?"
           f"code={symbol}&start={start}&end={end}&"
           f"fields=TCLOSE;HIGH;LOW;TOPEN;LCLOSE;CHG;PCHG;TURNOVER;VOTURNOVER;VATURNOVER")
    text = proxied_get(url, referer="https://quotes.money.163.com", encoding="gbk")
    lines = text.strip().split("\n")
    if len(lines) < 3:
        return None
    rows = []
    for line in lines[1:]:
        parts = line.strip().split(",")
        if len(parts) < 10:
            continue
        try:
            rows.append({
                "date": parts[0].strip("'"),
                "close": float(parts[3]) if parts[3] and parts[3] != "None" else 0,
                "high": float(parts[4]) if parts[4] and parts[4] != "None" else 0,
                "low": float(parts[5]) if parts[5] and parts[5] != "None" else 0,
                "open": float(parts[6]) if parts[6] and parts[6] != "None" else 0,
                "volume": float(parts[9]) if parts[9] and parts[9] != "None" else 0,
                "turnover_pct": float(parts[8]) if parts[8] and parts[8] != "None" else 0,
            })
        except (ValueError, IndexError):
            continue
    if not rows:
        return None
    df = pd.DataFrame(rows)
    df = df[df["close"] > 0].sort_values("date").tail(days)
    return df


def compute_stock_features(code: str, current_price: float = 0,
                           current_change_pct: float = 0) -> Optional[Dict]:
    hist = get_stock_history(code, 60)
    if hist is None or len(hist) < 20:
        return None
    try:
        close_series = hist["close"].astype(float)
        high_series = hist["high"].astype(float) if "high" in hist.columns else close_series
        low_series = hist["low"].astype(float) if "low" in hist.columns else close_series
        volume_series = hist["volume"].astype(float)
        high_20d = high_series.tail(20).max()
        low_20d = low_series.tail(20).min()
        high_60d = high_series.max()
        low_60d = low_series.min()
        avg_vol_5d = volume_series.tail(5).mean()
        avg_vol_20d = volume_series.tail(20).mean()
        today_vol = volume_series.iloc[-1]
        ma5 = close_series.tail(5).mean()
        ma10 = close_series.tail(10).mean()
        ma20 = close_series.tail(20).mean()
        ma60 = close_series.mean()
        ma20_prev = close_series.iloc[-25:-5].mean() if len(close_series) >= 25 else ma20
        price = current_price or float(close_series.iloc[-1])
        breakout_20d = 1 if price >= high_20d else 0
        from_60d_low_pct = ((price - low_60d) / low_60d * 100) if low_60d > 0 else 0
        volume_ratio_5d = (today_vol / avg_vol_5d) if avg_vol_5d > 0 else 1.0
        distance_to_high_20d_pct = ((high_20d - price) / high_20d * 100) if high_20d > 0 else 0
        range_position_pct = (
            (price - low_60d) / (high_60d - low_60d) * 100
            if high_60d > low_60d else 50.0
        )
        base_high_10d = high_series.tail(10).max()
        base_low_10d = low_series.tail(10).min()
        base_tightness_pct = (
            (base_high_10d - base_low_10d) / base_low_10d * 100
            if base_low_10d > 0 else 0
        )
        vol_contraction_ratio = (avg_vol_5d / avg_vol_20d) if avg_vol_20d > 0 else 1.0
        ma20_slope_pct = ((ma20 - ma20_prev) / ma20_prev * 100) if ma20_prev > 0 else 0.0
        returns_20d = close_series.pct_change().dropna().tail(20)
        volatility_20d_pct = float(returns_20d.std() * 100) if not returns_20d.empty else 0.0
        limit_up_days_20d = int((returns_20d >= 0.095).sum()) if not returns_20d.empty else 0
        trend_alignment = 0.0
        trend_alignment += 1.0 if price >= ma5 else 0.0
        trend_alignment += 1.0 if ma5 >= ma10 else 0.0
        trend_alignment += 1.0 if ma10 >= ma20 else 0.0
        trend_alignment += 1.0 if ma20 >= ma60 else 0.0
        trend_alignment = trend_alignment / 4.0
        typical_price = ((high_series + low_series + close_series) / 3.0).tail(60)
        volume_tail = volume_series.tail(len(typical_price))
        chip_peak_price = price
        chip_concentration_pct = 0.0
        chip_distance_pct = 0.0
        if len(typical_price) >= 10 and typical_price.max() > typical_price.min():
            bins = min(24, max(10, len(typical_price) // 2))
            hist_bins = pd.cut(
                typical_price,
                bins=bins,
                labels=False,
                include_lowest=True,
                duplicates="drop",
            )
            chip_profile = volume_tail.groupby(hist_bins).sum()
            if not chip_profile.empty and chip_profile.sum() > 0:
                top_bin = int(chip_profile.idxmax())
                bin_edges = pd.cut(
                    typical_price,
                    bins=bins,
                    include_lowest=True,
                    duplicates="drop",
                    retbins=True,
                )[1]
                if len(bin_edges) > top_bin + 1:
                    chip_peak_price = float((bin_edges[top_bin] + bin_edges[top_bin + 1]) / 2.0)
                chip_concentration_pct = float(chip_profile.sort_values(ascending=False).head(3).sum() / chip_profile.sum() * 100)
                if chip_peak_price > 0:
                    chip_distance_pct = float((price - chip_peak_price) / chip_peak_price * 100)
        setup_quality = 0.0
        if base_tightness_pct <= 12.0:
            setup_quality += 0.5
        elif base_tightness_pct <= 20.0:
            setup_quality += 0.25
        if 0.65 <= vol_contraction_ratio <= 1.05:
            setup_quality += 0.35
        elif vol_contraction_ratio <= 1.2:
            setup_quality += 0.2
        if 1.0 <= distance_to_high_20d_pct <= 8.0:
            setup_quality += 0.15
        setup_quality = min(setup_quality, 1.0)
        turnover = 0.0
        if "turnover_pct" in hist.columns:
            tp = hist["turnover_pct"].iloc[-1]
            turnover = float(tp) if pd.notna(tp) else 0.0

        # ─── MACD ──────────────────────────────────────────────────────────
        macd_golden_cross = 0.0
        macd_histogram = 0.0
        if len(close_series) >= 26:
            ema12 = close_series.ewm(span=12, adjust=False).mean()
            ema26 = close_series.ewm(span=26, adjust=False).mean()
            dif = ema12 - ema26
            dea = dif.ewm(span=9, adjust=False).mean()
            macd_bar = (dif - dea) * 2
            macd_histogram = float(macd_bar.iloc[-1])
            if len(dif) >= 2:
                prev_diff = float(dif.iloc[-2] - dea.iloc[-2])
                curr_diff = float(dif.iloc[-1] - dea.iloc[-1])
                if prev_diff < 0 < curr_diff:
                    macd_golden_cross = 1.0

        # ─── KDJ ──────────────────────────────────────────────────────────
        kdj_j = 50.0
        if len(close_series) >= 9:
            low_9 = low_series.rolling(9).min()
            high_9 = high_series.rolling(9).max()
            rsv = ((close_series - low_9) / (high_9 - low_9 + 1e-10)) * 100
            k = rsv.ewm(alpha=1/3, adjust=False).mean()
            d = k.ewm(alpha=1/3, adjust=False).mean()
            j = 3 * k - 2 * d
            kdj_j = float(j.iloc[-1]) if pd.notna(j.iloc[-1]) else 50.0

        # ─── RSI(14) ──────────────────────────────────────────────────────
        rsi_14 = 50.0
        if len(close_series) >= 15:
            delta = close_series.diff()
            gain = delta.where(delta > 0, 0.0)
            loss = (-delta.where(delta < 0, 0.0))
            avg_gain = gain.rolling(14).mean()
            avg_loss = loss.rolling(14).mean()
            rs = avg_gain / (avg_loss + 1e-10)
            rsi = 100 - (100 / (1 + rs))
            rsi_14 = float(rsi.iloc[-1]) if pd.notna(rsi.iloc[-1]) else 50.0

        # ─── Beta（相对大盘 60 日） ────────────────────────────────────────
        beta_60d = 1.0
        # beta 需要指数数据，此处用简化版（基于波动率估算）
        if volatility_20d_pct > 0:
            beta_60d = round(volatility_20d_pct / 1.5, 2)  # 假设大盘日波动约 1.5%

        return {
            "breakout_20d": breakout_20d,
            "from_60d_low_pct": round(from_60d_low_pct, 2),
            "volume_ratio_5d": round(volume_ratio_5d, 2),
            "turnover_pct": round(turnover, 2),
            "ma5": round(float(ma5), 2),
            "ma10": round(float(ma10), 2),
            "ma20": round(float(ma20), 2),
            "ma60": round(float(ma60), 2),
            "ma20_slope_pct": round(float(ma20_slope_pct), 2),
            "high_20d": round(float(high_20d), 2),
            "low_20d": round(float(low_20d), 2),
            "high_60d": round(float(high_60d), 2),
            "low_60d": round(float(low_60d), 2),
            "distance_to_high_20d_pct": round(float(distance_to_high_20d_pct), 2),
            "range_position_pct": round(float(range_position_pct), 2),
            "base_tightness_pct": round(float(base_tightness_pct), 2),
            "vol_contraction_ratio": round(float(vol_contraction_ratio), 2),
            "volatility_20d_pct": round(float(volatility_20d_pct), 2),
            "limit_up_days_20d": int(limit_up_days_20d),
            "chip_peak_price": round(float(chip_peak_price), 2),
            "chip_concentration_pct": round(float(chip_concentration_pct), 2),
            "chip_distance_pct": round(float(chip_distance_pct), 2),
            "trend_alignment": round(float(trend_alignment), 3),
            "setup_quality": round(float(setup_quality), 3),
            "macd_golden_cross": macd_golden_cross,
            "macd_histogram": round(float(macd_histogram), 4),
            "kdj_j": round(float(kdj_j), 2),
            "rsi_14": round(float(rsi_14), 2),
            "beta_60d": round(float(beta_60d), 2),
            "limit_up_count_20d": int(limit_up_days_20d),
        }
    except Exception as e:
        logger.debug(f"[数据] {code} 特征计算失败: {e}")
        return None


# ════════════════════════════════════════════════════════════════════════════
# 全市场实时行情
# ════════════════════════════════════════════════════════════════════════════

def _normalize_stock_code(code: str) -> str:
    return str(code or "").strip().replace("sh", "").replace("sz", "")


def _guess_market(code: str) -> str:
    return "sh" if str(code).startswith("6") else "sz"


def _parse_number(value) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    if not text or text in {"--", "-", "nan", "None"}:
        return 0.0
    multiplier = 1.0
    if "万亿" in text:
        multiplier = 10000.0
    elif "亿" in text:
        multiplier = 1.0
    elif "万" in text:
        multiplier = 0.01
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        return 0.0
    return float(match.group()) * multiplier


def _to_100m_value(value) -> float:
    parsed = _parse_number(value)
    if abs(parsed) > 1e6:
        return round(parsed / 1e8, 2)
    return round(parsed, 2)


def _find_column(columns, patterns: List[str]) -> Optional[str]:
    lowered = {str(col).lower(): col for col in columns}
    for pattern in patterns:
        needle = pattern.lower()
        for key, original in lowered.items():
            if needle in key:
                return original
    return None


def _frame_to_field_map(df: pd.DataFrame) -> Dict[str, object]:
    if df is None or df.empty:
        return {}
    columns = list(df.columns)
    if len(columns) < 2:
        return {}
    key_col = _find_column(columns, ["item", "指标", "项目", "名称"]) or columns[0]
    value_col = _find_column(columns, ["value", "值", "数据", "最新"]) or columns[1]
    result: Dict[str, object] = {}
    for _, row in df.iterrows():
        key = str(row.get(key_col, "")).strip()
        if key:
            result[key] = row.get(value_col)
    return result


def _load_stock_comment_map() -> Dict[str, Dict]:
    cache_key = "stock_comment_map"
    cached = _get_cache_value(cache_key, 1800)
    if cached is not None:
        return cached

    result: Dict[str, Dict] = {}
    if ak:
        try:
            df = _safe_ak_call(ak.stock_comment_em)
            if df is not None and not df.empty:
                code_col = _find_column(df.columns, ["代码", "symbol", "证券代码"])
                score_col = _find_column(df.columns, ["综合", "评分", "score"])
                attention_col = _find_column(df.columns, ["关注", "热度", "人气"])
                institution_col = _find_column(df.columns, ["机构", "参与"])
                for _, row in df.iterrows():
                    code = _normalize_stock_code(row.get(code_col, "")) if code_col else ""
                    if not code:
                        continue
                    result[code] = {
                        "comment_score": round(_parse_number(row.get(score_col, 0)) if score_col else 0.0, 2),
                        "attention_score": round(_parse_number(row.get(attention_col, 0)) if attention_col else 0.0, 2),
                        "institution_participation": round(_parse_number(row.get(institution_col, 0)) if institution_col else 0.0, 2),
                    }
        except Exception as exc:
            logger.debug(f"[data] comment map load failed: {exc}")

    _set_cache_value(cache_key, result)
    return result


def _load_lhb_stat_map() -> Dict[str, Dict]:
    cache_key = "lhb_stat_map"
    cached = _get_cache_value(cache_key, 1800)
    if cached is not None:
        return cached

    result: Dict[str, Dict] = {}
    if ak:
        try:
            df = _safe_ak_call(ak.stock_lhb_stock_statistic_em, symbol="近一月")
            if df is not None and not df.empty:
                code_col = _find_column(df.columns, ["代码", "证券代码", "code"])
                count_col = _find_column(df.columns, ["上榜次数", "次数"])
                net_col = _find_column(df.columns, ["净买", "净额", "买入净额"])
                inst_col = _find_column(df.columns, ["机构净买", "机构买入", "机构净额"])
                for _, row in df.iterrows():
                    code = _normalize_stock_code(row.get(code_col, "")) if code_col else ""
                    if not code:
                        continue
                    result[code] = {
                        "lhb_count_20d": round(_parse_number(row.get(count_col, 0)) if count_col else 0.0, 2),
                        "lhb_net_100m": _to_100m_value(row.get(net_col, 0)) if net_col else 0.0,
                        "lhb_inst_net_100m": _to_100m_value(row.get(inst_col, 0)) if inst_col else 0.0,
                    }
        except Exception as exc:
            logger.debug(f"[data] lhb stat load failed: {exc}")

    _set_cache_value(cache_key, result)
    return result


def _get_profile_factors(code: str) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"profile:{code}"
    cached = _get_cache_value(cache_key, 3600)
    if cached is not None:
        return cached

    factors = {
        "pe_ttm": 0.0,
        "total_market_cap_100m": 0.0,
        "free_market_cap_100m": 0.0,
        "total_shares_100m": 0.0,
        "float_shares_100m": 0.0,
        "roe_weighted": 0.0,
    }
    if ak:
        try:
            df = _safe_ak_call(ak.stock_individual_info_em, symbol=code)
            field_map = _frame_to_field_map(df)
            if field_map:
                pe_value = field_map.get("动态市盈率") or field_map.get("市盈率(动)") or field_map.get("市盈率")
                roe_value = field_map.get("净资产收益率") or field_map.get("加权净资产收益率")
                factors.update({
                    "pe_ttm": round(_parse_number(pe_value), 2),
                    "total_market_cap_100m": _to_100m_value(field_map.get("总市值")),
                    "free_market_cap_100m": _to_100m_value(field_map.get("流通市值")),
                    "total_shares_100m": round(_parse_number(field_map.get("总股本")), 2),
                    "float_shares_100m": round(_parse_number(field_map.get("流通股")), 2),
                    "roe_weighted": round(_parse_number(roe_value), 2),
                })
        except Exception as exc:
            logger.debug(f"[data] profile factors failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def _get_fund_flow_factors(code: str) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"fund_flow:{code}"
    cached = _get_cache_value(cache_key, 900)
    if cached is not None:
        return cached

    factors = {
        "main_net_inflow_20d_100m": 0.0,
        "main_inflow_days_20d": 0.0,
        "main_net_ratio_20d": 0.0,
    }
    if ak:
        try:
            df = _safe_ak_call(ak.stock_individual_fund_flow, stock=code, market=_guess_market(code))
            if df is not None and not df.empty:
                main_col = _find_column(df.columns, ["主力净流入", "主力净额"])
                ratio_col = _find_column(df.columns, ["主力净占比", "主力占比"])
                recent = df.tail(20)
                if main_col:
                    values = recent[main_col].apply(_parse_number)
                    total = values.sum()
                    factors["main_net_inflow_20d_100m"] = round(total / 1e8, 2) if abs(total) > 1e6 else round(total, 2)
                    factors["main_inflow_days_20d"] = float((values > 0).sum())
                if ratio_col:
                    ratios = recent[ratio_col].apply(_parse_number)
                    factors["main_net_ratio_20d"] = round(float(ratios.mean()), 2) if not ratios.empty else 0.0
        except Exception as exc:
            logger.debug(f"[data] fund flow factors failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def _get_holder_factors(code: str) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"holder:{code}"
    cached = _get_cache_value(cache_key, 3600)
    if cached is not None:
        return cached

    factors = {
        "holder_change_pct": 0.0,
        "top_holder_concentration_pct": 0.0,
    }
    if ak:
        try:
            df = _safe_ak_call(ak.stock_shareholder_change_ths, symbol=code)
            if df is not None and not df.empty:
                change_col = _find_column(df.columns, ["变动", "增减", "变化", "股东户数"])
                if change_col:
                    factors["holder_change_pct"] = round(_parse_number(df.iloc[-1][change_col]), 2)
        except Exception as exc:
            logger.debug(f"[data] holder change factors failed for {code}: {exc}")

        try:
            df = _safe_ak_call(ak.stock_circulate_stock_holder, symbol=code)
            if df is not None and not df.empty:
                ratio_col = _find_column(df.columns, ["占流通股比例", "占总流通股比例", "持股比例"])
                if ratio_col:
                    ratios = df[ratio_col].head(10).apply(_parse_number)
                    factors["top_holder_concentration_pct"] = round(float(ratios.sum()), 2)
        except Exception as exc:
            logger.debug(f"[data] circulate holder factors failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def warm_advanced_factor_support() -> None:
    _load_stock_comment_map()
    _load_lhb_stat_map()


def get_stock_advanced_factors(
    code: str,
    name: str = "",
    tech_features: Optional[Dict] = None,
) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"advanced_factors:{code}"
    cached = _get_cache_value(cache_key, 600)
    if cached is not None:
        return cached

    factors: Dict[str, float] = {}

    with ThreadPoolExecutor(max_workers=4) as pool:
        profile_future = pool.submit(_get_profile_factors, code)
        fund_flow_future = pool.submit(_get_fund_flow_factors, code)
        holder_future = pool.submit(_get_holder_factors, code)
        sentiment_future = pool.submit(__import__("feeds.sentiment", fromlist=["get_stock_sentiment"]).get_stock_sentiment, code)

        for future in (profile_future, fund_flow_future, holder_future):
            try:
                factors.update(future.result() or {})
            except Exception as exc:
                logger.debug(f"[data] advanced factors failed for {code}: {exc}")

        try:
            sentiment = sentiment_future.result() or {}
            factors["stock_sentiment_rsi"] = round(_parse_number(sentiment.get("rsi", 0.5)), 3)
            factors["stock_sentiment_adj"] = round(_parse_number(sentiment.get("score_adj", 0.0)), 2)
        except Exception as exc:
            logger.debug(f"[data] stock sentiment factors failed for {code}: {exc}")
            factors.setdefault("stock_sentiment_rsi", 0.5)
            factors.setdefault("stock_sentiment_adj", 0.0)

    factors.update(_load_stock_comment_map().get(code, {}))
    factors.update(_load_lhb_stat_map().get(code, {}))

    # 合并技术指标（MACD/KDJ/RSI/beta/筹码等）
    try:
        tech = tech_features or compute_stock_features(code)
        if tech:
            for k in ("macd_golden_cross", "macd_histogram", "kdj_j", "rsi_14",
                       "beta_60d", "chip_concentration_pct", "chip_distance_pct",
                       "volatility_20d_pct", "limit_up_count_20d", "trend_alignment",
                       "ma20_slope_pct"):
                if k in tech:
                    factors.setdefault(k, tech[k])
    except Exception as exc:
        logger.debug(f"[data] tech factors merge failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def _get_spot_snapshot_fallback() -> pd.DataFrame:
    cache_key = "a_spot_snapshot_fallback"
    cached = _get_cache_value(cache_key, ttl=30)
    if cached is not None:
        return cached

    if not ak:
        return pd.DataFrame()

    try:
        df = _safe_ak_call(ak.stock_zh_a_spot, retries=1)
        if df is None or df.empty:
            return pd.DataFrame()
        normalized = pd.DataFrame({
            "code": df.get("代码", pd.Series(dtype=str)).astype(str).str.replace("^(sh|sz|bj)", "", regex=True),
            "name": df.get("名称", pd.Series(dtype=str)).astype(str),
            "price": pd.to_numeric(df.get("最新价", 0), errors="coerce").fillna(0.0),
            "change_pct": pd.to_numeric(df.get("涨跌幅", 0), errors="coerce").fillna(0.0),
            "volume": pd.to_numeric(df.get("成交量", 0), errors="coerce").fillna(0.0),
            "amount": pd.to_numeric(df.get("成交额", 0), errors="coerce").fillna(0.0),
            "turnover_pct": 0.0,
            "volume_ratio": 0.0,
        })
        normalized = normalized[normalized["code"].astype(str) != ""].reset_index(drop=True)
        _set_cache_value(cache_key, normalized)
        return normalized
    except Exception as exc:
        logger.debug(f"[data] fallback spot snapshot failed: {exc}")
        return pd.DataFrame()


def get_all_stocks_spot(
    limit: int = 50,
    sort_field: str = "f3",
    sort_order: int = 1,
) -> pd.DataFrame:
    cache_key = f"a_spot_em:{limit}:{sort_field}:{sort_order}"
    cached = _get_cache_value(cache_key, ttl=30)
    if cached is not None:
        return cached
    # 东财push2.eastmoney.com在腾讯云被封，改用新浪市场API（0.4秒极速）
    sort_map_sina = {"f6": "amount", "f3": "changepercent", "f8": "volume"}
    sina_sort = sort_map_sina.get(sort_field, "changepercent")
    sort_asc = "0" if int(sort_order) == 1 else "1"
    all_rows = []
    page_size = 80
    for page in range(1, 6):  # 最多5页=400只
        try:
            sina_url = (
                f"https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php"
                f"/Market_Center.getHQNodeData?page={page}&num={page_size}"
                f"&sort={sina_sort}&asc={sort_asc}&node=hs_a&symbol=&_s_r_a=page"
            )
            resp = requests.get(sina_url, headers={"Referer": "https://finance.sina.com.cn", "User-Agent": "Mozilla/5.0"}, timeout=6.0)
            if not resp:
                break
            rows_batch = resp.json() if hasattr(resp, "json") else json.loads(resp)
            if not rows_batch:
                break
            for item in rows_batch:
                code = str(item.get("code", "")).replace("sh", "").replace("sz", "")
                all_rows.append({
                    "code": code,
                    "name": item.get("name", ""),
                    "price": float(item.get("trade", 0) or 0),
                    "change_pct": float(item.get("changepercent", 0) or 0),
                    "volume": float(item.get("volume", 0) or 0),
                    "amount": float(item.get("amount", 0) or 0),
                    "turnover_pct": float(item.get("turnoverratio", 0) or 0),
                    "volume_ratio": 0.0,  # Sina无量比数据，暂用0
                })
        except Exception:
            break
    if all_rows:
        df = pd.DataFrame(all_rows)
        _set_cache_value(cache_key, df)
        return df

    with _spot_snapshot_lock:
        fallback = _get_cache_value("a_spot_snapshot_fallback", ttl=30)
        if fallback is None or fallback.empty:
            fallback = _get_spot_snapshot_fallback()
    if fallback.empty:
        return pd.DataFrame()

    sort_map = {
        "f6": "amount",
        "f3": "change_pct",
        "f8": "volume",
    }
    sort_column = sort_map.get(sort_field, "change_pct")
    ascending = int(sort_order) != 1
    df = fallback.sort_values(sort_column, ascending=ascending).head(max(1, int(limit))).reset_index(drop=True)
    _set_cache_value(cache_key, df)
    return df


def enrich_stock_data(sina_data: Dict[str, Dict]) -> Dict[str, Dict]:
    spot_df = get_all_stocks_spot(limit=max(120, len(sina_data) * 2), sort_field="f6")
    if spot_df.empty:
        return sina_data
    for code, data in sina_data.items():
        row = spot_df[spot_df["code"] == code]
        if not row.empty:
            r = row.iloc[0]
            data["volume_ratio"] = float(r.get("volume_ratio", 0) or 0)
            data["turnover_pct"] = float(r.get("turnover_pct", 0) or 0)
    return sina_data


def _load_stock_comment_map() -> Dict[str, Dict]:
    cache_key = "stock_comment_map"
    cached = _get_cache_value(cache_key, 1800)
    if cached is not None:
        return cached

    result: Dict[str, Dict] = {}
    try:
        params = {
            "sortColumns": "SECURITY_CODE",
            "sortTypes": "1",
            "pageSize": "5000",
            "pageNumber": "1",
            "reportName": "RPT_DMSK_TS_STOCKNEW",
            "quoteColumns": (
                "f2~01~SECURITY_CODE~CLOSE_PRICE,f8~01~SECURITY_CODE~TURNOVERRATE,"
                "f3~01~SECURITY_CODE~CHANGE_RATE,f9~01~SECURITY_CODE~PE_DYNAMIC"
            ),
            "columns": "ALL",
            "filter": "",
            "token": "894050c76af8597a853f5b408b759f5d",
        }
        first_page = _request_json_direct_first(
            "https://datacenter-web.eastmoney.com/api/data/v1/get",
            referer="https://data.eastmoney.com/stockcomment/",
            timeout=6.0,
            params=params,
        ).get("result", {})
        rows = list(first_page.get("data", []) or [])
        total_pages = int(first_page.get("pages", 1) or 1)
        for page in range(2, total_pages + 1):
            params["pageNumber"] = str(page)
            page_rows = _request_json_direct_first(
                "https://datacenter-web.eastmoney.com/api/data/v1/get",
                referer="https://data.eastmoney.com/stockcomment/",
                timeout=6.0,
                params=params,
            ).get("result", {}).get("data", [])
            rows.extend(page_rows or [])

        for row in rows:
            code = _normalize_stock_code(row.get("SECURITY_CODE", ""))
            if not code:
                continue
            result[code] = {
                "comment_score": round(_parse_number(row.get("TOTALSCORE", 0)), 2),
                "attention_score": round(_parse_number(row.get("FOCUS", 0)), 2),
                "institution_participation": round(_parse_number(row.get("ORG_PARTICIPATE", 0)), 2),
            }
    except Exception as exc:
        logger.debug(f"[data] comment map load failed: {exc}")

    _set_cache_value(cache_key, result)
    return result


def _load_lhb_stat_map() -> Dict[str, Dict]:
    cache_key = "lhb_stat_map"
    cached = _get_cache_value(cache_key, 1800)
    if cached is not None:
        return cached

    result: Dict[str, Dict] = {}
    try:
        rows = _request_json_direct_first(
            "https://datacenter-web.eastmoney.com/api/data/v1/get",
            referer="https://data.eastmoney.com/stock/tradedetail.html",
            timeout=6.0,
            params={
                "sortColumns": "BILLBOARD_TIMES,LATEST_TDATE,SECURITY_CODE",
                "sortTypes": "-1,-1,1",
                "pageSize": "5000",
                "pageNumber": "1",
                "reportName": "RPT_BILLBOARD_TRADEALL",
                "columns": "ALL",
                "source": "WEB",
                "client": "WEB",
                "filter": '(STATISTICS_CYCLE="01")',
            },
        ).get("result", {}).get("data", [])
        for row in (rows or []):
            code = _normalize_stock_code(row.get("SECURITY_CODE", ""))
            if not code:
                continue
            result[code] = {
                "lhb_count_20d": round(_parse_number(row.get("BILLBOARD_TIMES", 0)), 2),
                "lhb_net_100m": _to_100m_value(row.get("BILLBOARD_NET_BUY", 0)),
                "lhb_inst_net_100m": _to_100m_value(row.get("ORG_NET_BUY", 0)),
            }
    except Exception as exc:
        logger.debug(f"[data] lhb stat load failed: {exc}")

    _set_cache_value(cache_key, result)
    return result


def _get_profile_factors(code: str) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"profile:{code}"
    cached = _get_cache_value(cache_key, 3600)
    if cached is not None:
        return cached

    factors = {
        "pe_ttm": 0.0,
        "total_market_cap_100m": 0.0,
        "free_market_cap_100m": 0.0,
        "total_shares_100m": 0.0,
        "float_shares_100m": 0.0,
        "roe_weighted": 0.0,
    }
    try:
        fields = _fetch_tencent_quote_fields(code)
        if len(fields) > 73:
            factors.update({
                "pe_ttm": round(_parse_number(fields[39]), 2),
                "free_market_cap_100m": round(_parse_number(fields[44]), 2),
                "total_market_cap_100m": round(_parse_number(fields[45]), 2),
                "float_shares_100m": round(_parse_number(fields[72]) / 1e8, 2),
                "total_shares_100m": round(_parse_number(fields[73]) / 1e8, 2),
            })
    except Exception as exc:
        logger.debug(f"[data] tencent profile snapshot failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def _get_fund_flow_factors(code: str) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"fund_flow:{code}"
    cached = _get_cache_value(cache_key, 900)
    if cached is not None:
        return cached
    endpoint = "eastmoney_fund_flow_daykline"

    factors = {
        "main_net_inflow_20d_100m": 0.0,
        "main_inflow_days_20d": 0.0,
        "main_net_ratio_20d": 0.0,
    }
    if _is_endpoint_temporarily_blocked(endpoint):
        _set_cache_value(cache_key, factors)
        return factors
    try:
        data = _request_json_direct_first(
            "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get",
            referer="https://data.eastmoney.com/zjlx/detail.html",
            timeout=4.0,
            params={
                "lmt": "0",
                "klt": "101",
                "secid": f"{1 if _guess_market(code) == 'sh' else 0}.{code}",
                "fields1": "f1,f2,f3,f7",
                "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65",
                "ut": "b2884a393a59ad64002292a3e90d46a5",
                "_": int(time.time() * 1000),
            },
        ).get("data") or {}
        klines = data.get("klines", []) or []
        if klines:
            recent = [line.split(",") for line in klines[-20:]]
            main_values = [_parse_number(item[1]) for item in recent if len(item) > 1]
            ratio_values = [_parse_number(item[6]) for item in recent if len(item) > 6]
            total = sum(main_values)
            factors["main_net_inflow_20d_100m"] = round(total / 1e8, 2) if abs(total) > 1e6 else round(total, 2)
            factors["main_inflow_days_20d"] = float(sum(1 for item in main_values if item > 0))
            factors["main_net_ratio_20d"] = round(sum(ratio_values) / len(ratio_values), 2) if ratio_values else 0.0
            _record_endpoint_success(endpoint)
        else:
            _record_endpoint_failure(endpoint)
    except Exception as exc:
        _record_endpoint_failure(endpoint)
        logger.debug(f"[data] fund flow factors failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def _get_holder_factors(code: str) -> Dict:
    code = _normalize_stock_code(code)
    cache_key = f"holder:{code}"
    cached = _get_cache_value(cache_key, 3600)
    if cached is not None:
        return cached

    factors = {
        "holder_change_pct": 0.0,
        "top_holder_concentration_pct": 0.0,
    }
    ths_html = ""
    sina_html = ""

    with ThreadPoolExecutor(max_workers=2) as pool:
        ths_future = pool.submit(
            _request_text_direct_first,
            f"https://basic.10jqka.com.cn/new/{code}/event.html",
            referer=f"https://basic.10jqka.com.cn/new/{code}/",
            encoding="gb2312",
            timeout=4.0,
        )
        sina_future = pool.submit(
            _request_text_direct_first,
            f"https://vip.stock.finance.sina.com.cn/corp/go.php/vCI_CirculateStockHolder/stockid/{code}.phtml",
            referer=f"https://vip.stock.finance.sina.com.cn/corp/go.php/vCI_CirculateStockHolder/stockid/{code}.phtml",
            timeout=4.0,
        )
        try:
            ths_html = ths_future.result()
        except Exception as exc:
            logger.debug(f"[data] holder change factors failed for {code}: {exc}")
        try:
            sina_html = sina_future.result()
        except Exception as exc:
            logger.debug(f"[data] circulate holder factors failed for {code}: {exc}")

    try:
        html = ths_html
        soup = BeautifulSoup(html, features="html.parser")
        table = soup.find(name="table", attrs={"class": "m_table data_table_1 m_hl"})
        if table is not None:
            content_list = [item.text.strip() for item in table]
            if len(content_list) >= 4:
                column_names = content_list[1].split("\n")
                row = (
                    content_list[3]
                    .replace("\t", "")
                    .replace("\n\n", "")
                    .replace("   ", "\n")
                    .replace(" ", "")
                    .replace("\n\n", "\n")
                    .split("\n")
                )
                row = [item for item in row if item != ""]
                new_rows = []
                step = len(column_names)
                for i in range(0, len(row), step):
                    new_rows.append(row[i:i + step])
                df = pd.DataFrame(new_rows, columns=column_names)
                if not df.empty:
                    change_col = _find_column(df.columns, ["变动", "增减", "变化", "股东户数"])
                    if change_col:
                        factors["holder_change_pct"] = round(_parse_number(df.iloc[-1][change_col]), 2)
    except Exception as exc:
        logger.debug(f"[data] holder change factors failed for {code}: {exc}")

    try:
        html = sina_html
        tables = pd.read_html(StringIO(html))
        if len(tables) > 13:
            df = tables[13].iloc[:, :5]
            df.columns = [*range(5)]
            need_range = df[df.iloc[:, 0].astype(str).str.find("截止日期") == 0].index.tolist() + [len(df)]
            big_df = pd.DataFrame()
            for i in range(len(need_range) - 1):
                truncated_df = df.iloc[need_range[i]:need_range[i + 1], :].dropna(how="all")
                temp_truncated = truncated_df.iloc[2:, :].reset_index(drop=True)
                concat_df = pd.concat(
                    objs=[temp_truncated, truncated_df.iloc[0, :], truncated_df.iloc[1, :]],
                    axis=1,
                )
                concat_df.columns = concat_df.iloc[0, :]
                concat_df = concat_df.iloc[1:, :]
                big_df = pd.concat(objs=[big_df, concat_df], axis=0, ignore_index=True)
            if not big_df.empty:
                ratio_col = _find_column(big_df.columns, ["占流通股比例", "占总流通股比例", "持股比例"])
                if ratio_col:
                    ratios = big_df[ratio_col].head(10).apply(_parse_number)
                    factors["top_holder_concentration_pct"] = round(float(ratios.sum()), 2)
    except Exception as exc:
        logger.debug(f"[data] circulate holder factors failed for {code}: {exc}")

    _set_cache_value(cache_key, factors)
    return factors


def _get_spot_snapshot_fallback() -> pd.DataFrame:
    cache_key = "a_spot_snapshot_fallback"
    cached = _get_cache_value(cache_key, ttl=30)
    if cached is not None:
        return cached

    with _spot_snapshot_lock:
        cached = _get_cache_value(cache_key, ttl=30)
        if cached is not None:
            return cached
        try:
            from akshare.utils import demjson as ak_demjson

            count_text = _request_text_direct_first(
                "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeStockCount?node=hs_a",
                timeout=6.0,
            )
            total_count = int(re.findall(r"\d+", count_text)[0])
            page_count = max(1, (total_count + 79) // 80)

            def fetch_page(page: int) -> pd.DataFrame:
                text = _request_text_direct_first(
                    "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData",
                    timeout=6.0,
                    params={
                        "page": str(page),
                        "num": "80",
                        "sort": "symbol",
                        "asc": "1",
                        "node": "hs_a",
                        "symbol": "",
                        "_s_r_a": "page",
                    },
                )
                return pd.DataFrame(ak_demjson.decode(text))

            frames: List[pd.DataFrame] = []
            with ThreadPoolExecutor(max_workers=min(12, page_count)) as pool:
                future_map = {
                    pool.submit(fetch_page, page): page
                    for page in range(1, page_count + 1)
                }
                for future in as_completed(future_map):
                    try:
                        frame = future.result()
                    except Exception as exc:
                        logger.debug(f"[data] sina spot page {future_map[future]} failed: {exc}")
                        continue
                    if frame is not None and not frame.empty:
                        frames.append(frame)

            if not frames:
                return pd.DataFrame()
            df = pd.concat(frames, ignore_index=True)
            normalized = pd.DataFrame({
                "code": df.get("code", pd.Series(dtype=str)).astype(str).str.replace("^(sh|sz|bj)", "", regex=True),
                "name": df.get("name", pd.Series(dtype=str)).astype(str),
                "price": pd.to_numeric(df.get("trade", 0), errors="coerce").fillna(0.0),
                "change_pct": pd.to_numeric(df.get("changepercent", 0), errors="coerce").fillna(0.0),
                "volume": pd.to_numeric(df.get("volume", 0), errors="coerce").fillna(0.0),
                "amount": pd.to_numeric(df.get("amount", 0), errors="coerce").fillna(0.0),
                "turnover_pct": pd.to_numeric(df.get("turnoverratio", 0), errors="coerce").fillna(0.0),
                "volume_ratio": 0.0,
            })
            normalized = normalized[normalized["code"].astype(str) != ""].reset_index(drop=True)
            _set_cache_value(cache_key, normalized)
            return normalized
        except Exception as exc:
            logger.debug(f"[data] fallback spot snapshot failed: {exc}")
            return pd.DataFrame()


def get_all_stocks_spot(
    limit: int = 50,
    sort_field: str = "f3",
    sort_order: int = 1,
) -> pd.DataFrame:
    cache_key = f"a_spot_em:{limit}:{sort_field}:{sort_order}"
    cached = _get_cache_value(cache_key, ttl=30)
    if cached is not None:
        return cached

    sort_map = {
        "f6": "amount",
        "f3": "change_pct",
        "f8": "volume",
    }
    fallback_cached = _get_cache_value("a_spot_snapshot_fallback", ttl=30)
    if fallback_cached is not None and not fallback_cached.empty:
        sort_column = sort_map.get(sort_field, "change_pct")
        ascending = int(sort_order) != 1
        df = fallback_cached.sort_values(sort_column, ascending=ascending).head(max(1, int(limit))).reset_index(drop=True)
        _set_cache_value(cache_key, df)
        return df

    url = (
        "https://push2.eastmoney.com/api/qt/clist/get?"
        f"pn=1&pz={max(1, int(limit))}&po={int(sort_order)}&np=1&fltt=2&invt=2&fid={sort_field}&"
        "fs=m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23&"
        "fields=f12,f14,f2,f3,f5,f6,f8,f10&"
        f"ut=b2884a393a59ad64002292a3e90d46a5&_={int(time.time()*1000)}"
    )
    try:
        data = _request_json_direct_first(
            url,
            referer="https://quote.eastmoney.com",
            timeout=2.5,
        )
        rows = []
        for item in (data.get("data", {}).get("diff", []) or []):
            rows.append({
                "code": str(item.get("f12", "")),
                "name": item.get("f14", ""),
                "price": float(item.get("f2", 0) or 0),
                "change_pct": float(item.get("f3", 0) or 0),
                "volume": float(item.get("f5", 0) or 0),
                "amount": float(item.get("f6", 0) or 0),
                "turnover_pct": float(item.get("f8", 0) or 0),
                "volume_ratio": float(item.get("f10", 0) or 0),
            })
        if rows:
            df = pd.DataFrame(rows)
            _set_cache_value(cache_key, df)
            return df
    except Exception as exc:
        logger.debug(f"[data] spot fetch failed: {exc}")

    fallback = _get_spot_snapshot_fallback()
    if fallback.empty:
        return pd.DataFrame()

    sort_column = sort_map.get(sort_field, "change_pct")
    ascending = int(sort_order) != 1
    df = fallback.sort_values(sort_column, ascending=ascending).head(max(1, int(limit))).reset_index(drop=True)
    _set_cache_value(cache_key, df)
    return df
