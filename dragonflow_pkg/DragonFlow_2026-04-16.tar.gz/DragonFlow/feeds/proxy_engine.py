"""
HTTPS 高匿代理 + IP 自动轮换引擎
═══════════════════════════════════════════════════════════════════════════
根因：腾讯云 IP 段被东方财富/新浪等全链路封禁（不分域名），
必须通过外部代理 IP 出网才能获取数据。

架构：
  ProxyRouter  → 域名级路由（SOCKS5/HTTP/direct）
              → 健康检测（连续失败剔除 + 成功率降权）
              → 反馈闭环（失败即时调整）
  ProxyPool    → HTTP 高匿代理池（多源抓取 + 验证）
  SOCKS5Pool   → SOCKS5 代理池（动态刷新）
  proxied_get  → 全局统一代理出口

路由策略：
  xueqiu.com      → SOCKS5（风控识别HTTP隧道）
  10jqka.com.cn   → SOCKS5（风控识别HTTP隧道）
  eastmoney.com   → direct（已备案，可直连）
 .sina.com.cn     → direct（已备案，可直连）
  163.com         → direct（已备案，可直连）
  其他            → HTTP 代理池
"""
from __future__ import annotations

import json
import os
import random
import re
import socket
import time
import threading
import urllib.request
import urllib.error
from urllib.parse import quote, urlencode, urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from loguru import logger

from config import DATA_SOURCE_CONFIG

# ════════════════════════════════════════════════════════════════════════════
# 第一层：统一代理抽象（支持 HTTP + SOCKS5）
# ════════════════════════════════════════════════════════════════════════════

@dataclass
class Proxy:
    """统一代理对象：HTTP / SOCKS5 共用同一抽象"""
    host: str
    port: int
    protocol: str = "http"          # "http" | "socks5"
    username: str = ""
    password: str = ""
    # 健康指标
    score: float = 5.0              # 0-10，初始5分
    success_count: int = 0
    fail_count: int = 0
    avg_latency: float = 999.0
    last_used: float = 0.0
    last_fail: float = 0.0
    consecutive_fails: int = 0      # 连续失败次数（超3次踢出）
    # 元数据
    source: str = "pool"            # "configured" | "pool" | "socks5_dynamic"

    @property
    def url(self) -> str:
        return f"{self.protocol}://{self.host}:{self.port}"

    @property
    def auth_url(self) -> str:
        """带认证的URL（用于requests库）"""
        if not (self.username or self.password):
            return self.url
        u = quote(self.username, safe="")
        p = quote(self.password, safe="")
        return f"{self.protocol}://{u}:{p}@{self.host}:{self.port}"

    @property
    def key(self) -> str:
        return f"{self.protocol}|{self.source}|{self.username}|{self.host}|{self.port}"

    @property
    def is_usable(self) -> bool:
        """代理是否可用（评分>0 + 冷却期已过）"""
        if self.score <= 0 or self.consecutive_fails >= 3:
            return False
        # 配置代理冷却1秒，池代理冷却30秒
        cooldown = 1.0 if self.source == "configured" else 30.0
        if self.last_fail > 0 and time.time() - self.last_fail < cooldown:
            return False
        return True

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.fail_count
        return self.success_count / total if total > 0 else 1.0

    def record_success(self, latency_ms: float):
        """记录成功：提分 + 统计"""
        self.success_count += 1
        self.last_used = time.time()
        self.consecutive_fails = 0
        # 延迟更新（EWMA）
        if self.avg_latency < 900:
            self.avg_latency = self.avg_latency * 0.7 + latency_ms * 0.3
        else:
            self.avg_latency = latency_ms
        # 提分（上线10分）
        self.score = min(self.score + 0.5, 10.0)

    def record_failure(self):
        """记录失败：降分 + 冷却"""
        self.fail_count += 1
        self.last_fail = time.time()
        self.consecutive_fails += 1
        # 配置代理只扣0.5分（容忍度高），池代理扣2分
        penalty = 0.5 if self.source == "configured" else 2.0
        self.score = max(self.score - penalty, 0.0)

    def to_dict(self) -> dict:
        return {
            "proxy": self.url,
            "type": self.protocol,
            "score": round(self.score, 1),
            "success_rate": round(self.success_rate, 2),
            "avg_latency_ms": round(self.avg_latency, 0),
            "consecutive_fails": self.consecutive_fails,
            "usable": self.is_usable,
            "source": self.source,
        }


# ════════════════════════════════════════════════════════════════════════════
# 第二层：域名路由引擎
# ════════════════════════════════════════════════════════════════════════════

# 域名 → 路由策略
# direct:   直连（已备案域名，腾讯云可访问）
# socks5:    走 SOCKS5（风控严格，必须SOCKS5）
# http:      走 HTTP 代理池（默认兜底）
DOMAIN_ROUTING: Dict[str, str] = {
    # ── 腾讯直连域名（东财系，已备案）────────────────────────
    "qt.gtimg.cn":              "direct",
    "sqt.gtimg.cn":             "direct",
    "smartqt.gtimg.cn":         "direct",
    "push2.eastmoney.com":      "direct",
    "push2ex.eastmoney.com":    "direct",
    "push2his.eastmoney.com":   "direct",
    "hks.push2.eastmoney.com":  "direct",
    "emweb.eastmoney.com":      "direct",
    "datacenter.eastmoney.com":  "direct",
    "quote.eastmoney.com":      "direct",
    "stock.eastmoney.com":      "direct",
    "guba.eastmoney.com":       "direct",
    "bbs.eastmoney.com":        "direct",
    # ── 新浪直连域名（已备案）─────────────────────────────
    "hq.sinajs.cn":             "direct",
    "vip.stock.finance.sina.com.cn": "direct",
    "finance.sina.com.cn":       "direct",
    # ── 网易直连域名（已备案）─────────────────────────────
    "quotes.money.163.com":      "direct",
    "web.ifzq.gtimg.cn":        "direct",
    # ── 必须走 SOCKS5 的域名（风控识别HTTP隧道）──────────
    "xueqiu.com":               "socks5",
    "10jqka.com.cn":            "socks5",
    "t.10jqka.com.cn":          "socks5",
    # ── 其他财经（默认HTTP池）─────────────────────────────
}

# 从环境变量读取的静态 SOCKS5 代理
_STATIC_SOCKS5: Optional[Proxy] = None

def _get_static_socks5() -> Optional[Proxy]:
    """从环境变量读取静态SOCKS5配置"""
    global _STATIC_SOCKS5
    if _STATIC_SOCKS5 is not None:
        return _STATIC_SOCKS5

    socks5_url = os.environ.get("SOCKS5_PROXY", "") or os.environ.get("socks5_proxy", "")
    if not socks5_url:
        return None

    try:
        parsed = urlparse(socks5_url.strip())
        if parsed.scheme == "socks5":
            _STATIC_SOCKS5 = Proxy(
                host=parsed.hostname,
                port=parsed.port or 1080,
                protocol="socks5",
                username=parsed.username or "",
                password=parsed.password or "",
                source="configured",
            )
        elif parsed.hostname and parsed.port:
            _STATIC_SOCKS5 = Proxy(
                host=parsed.hostname,
                port=parsed.port,
                protocol="socks5",
                username=parsed.username or "",
                password=parsed.password or "",
                source="configured",
            )
    except Exception as e:
        logger.warning(f"[SOCKS5] 环境变量解析失败: {e}")

    return _STATIC_SOCKS5


def route_domain(url: str) -> Tuple[str, Optional[Proxy]]:
    """
    域名路由：返回 (路由策略, 对应代理对象)
    策略: "direct" | "socks5" | "http"
    """
    parsed = urlparse(url)
    host = parsed.hostname or ""
    domain = host.lower()

    # 精确匹配 + 后缀匹配（t.10jqka.com.cn → 10jqka.com.cn）
    for rule_domain, strategy in DOMAIN_ROUTING.items():
        if domain == rule_domain or domain.endswith(f".{rule_domain}"):
            if strategy == "direct":
                return "direct", None
            if strategy == "socks5":
                socks5 = _get_static_socks5()
                if socks5 and socks5.is_usable:
                    return "socks5", socks5
                # 静态SOCKS5不可用，尝试从动态池获取
                dynamic = _socks5_pool.get_best()
                if dynamic:
                    return "socks5", dynamic
                # 都没有，降级到HTTP
                logger.debug(f"[路由] SOCKS5不可用，降级HTTP: {domain}")
                return "http", None

    # 默认：HTTP代理池
    return "http", None


# ════════════════════════════════════════════════════════════════════════════
# 第三层：HTTP 代理池
# ════════════════════════════════════════════════════════════════════════════

class ProxyPool:
    """HTTP(S) 代理池：抓取 + 验证 + 健康管理"""

    def __init__(self):
        self._proxies: List[Proxy] = []
        self._lock = threading.RLock()
        self._last_refresh = 0.0
        self._last_refresh_attempt = 0.0
        self._refresh_interval = 600    # 10分钟
        self._empty_retry_interval = 15.0

    @property
    def size(self) -> int:
        return len(self._proxies)

    @property
    def usable_count(self) -> int:
        with self._lock:
            return sum(1 for p in self._proxies if p.is_usable)

    def get_best(self) -> Optional[Proxy]:
        """获取最佳HTTP代理（高分 + 低延迟 + 负载均衡）"""
        with self._lock:
            usable = [p for p in self._proxies if p.is_usable]
            if not usable:
                return None
            # 排序：score降序 → latency升序 → last_used升序
            usable.sort(key=lambda p: (-p.score, p.avg_latency, p.last_used))
            # Top3随机选一（避免单个被打满）
            top = usable[:min(3, len(usable))]
            return random.choice(top)

    def add(self, host: str, port: int, protocol: str = "http",
            username: str = "", password: str = "", *, source: str = "pool"):
        with self._lock:
            for p in self._proxies:
                if (p.host == host and p.port == port
                        and p.protocol == protocol
                        and p.username == (username or "")):
                    return  # 去重
            self._proxies.append(
                Proxy(host, port, protocol, username, password, source=source)
            )

    def remove_dead(self):
        """清除连续失败≥3或评分≤0的代理"""
        with self._lock:
            before = len(self._proxies)
            self._proxies = [
                p for p in self._proxies
                if p.consecutive_fails < 3 and p.score > 0
            ]
            removed = before - len(self._proxies)
            if removed:
                logger.debug(f"[HTTP池] 清除{removed}个失效代理")

    def needs_refresh(self) -> bool:
        return (time.time() - self._last_refresh > self._refresh_interval
                or self.usable_count < 3)

    def mark_refreshed(self):
        self._last_refresh = time.time()

    def mark_refresh_attempt(self):
        self._last_refresh_attempt = time.time()

    def should_retry_empty_refresh(self) -> bool:
        if self.usable_count > 0:
            return True
        return (time.time() - self._last_refresh_attempt) >= self._empty_retry_interval


# ════════════════════════════════════════════════════════════════════════════
# 第四层：SOCKS5 动态代理池
# ════════════════════════════════════════════════════════════════════════════

# 免费 SOCKS5 源（来自公开 GitHub 列表）
_SOCKS5_SOURCES = [
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/socks5-proxies.txt",
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
]

_SOCKS5_REFRESH_INTERVAL = 300  # 5分钟刷新一次


class SOCKS5Pool:
    """SOCKS5 动态代理池：抓取 + 验证 + 健康管理"""

    def __init__(self):
        self._proxies: List[Proxy] = []
        self._lock = threading.RLock()
        self._last_refresh = 0.0

    @property
    def size(self) -> int:
        return len(self._proxies)

    @property
    def usable_count(self) -> int:
        with self._lock:
            return sum(1 for p in self._proxies if p.is_usable)

    def get_best(self) -> Optional[Proxy]:
        with self._lock:
            usable = [p for p in self._proxies if p.is_usable]
            if not usable:
                return None
            usable.sort(key=lambda p: (-p.score, p.avg_latency, p.last_used))
            return random.choice(usable[:min(3, len(usable))])

    def add(self, host: str, port: int, username: str = "", password: str = ""):
        with self._lock:
            for p in self._proxies:
                if p.host == host and p.port == port:
                    return
            self._proxies.append(
                Proxy(host, port, "socks5", username, password, source="socks5_dynamic")
            )

    def remove_dead(self):
        with self._lock:
            before = len(self._proxies)
            self._proxies = [
                p for p in self._proxies
                if p.consecutive_fails < 3 and p.score > 0
            ]
            removed = before - len(self._proxies)
            if removed:
                logger.debug(f"[SOCKS5池] 清除{removed}个失效节点")

    def needs_refresh(self) -> bool:
        return (time.time() - self._last_refresh > _SOCKS5_REFRESH_INTERVAL
                or self.usable_count < 2)

    def mark_refreshed(self):
        self._last_refresh = time.time()


# 全局池实例
_http_pool = ProxyPool()
_socks5_pool = SOCKS5Pool()

# 配置代理URL集合（用于识别配置的代理，单独降权策略）
_configured_proxy_keys: set[str] = set()


# ════════════════════════════════════════════════════════════════════════════
# 代理源抓取（免费 HTTP 高匿代理）
# ════════════════════════════════════════════════════════════════════════════

def _direct_fetch(url: str, timeout: float = 8) -> str:
    """不走代理的直接请求（用于抓代理列表）"""
    headers = {"User-Agent": random.choice(DATA_SOURCE_CONFIG["user_agents"])}
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def _dedupe(proxies: List[Tuple[str, int]]) -> List[Tuple[str, int]]:
    seen = set()
    result: List[Tuple[str, int]] = []
    for host, port in proxies:
        if not host or not port:
            continue
        key = (str(host), int(port))
        if key in seen:
            continue
        seen.add(key)
        result.append(key)
    return result


def _fetch_http_candidates() -> List[Tuple[str, int]]:
    """从多个源抓取候选HTTP代理"""
    proxies: List[Tuple[str, int]] = []

    # Geonode API（JSON，高质量）
    for url in [
        "https://proxylist.geonode.com/api/proxy-list?limit=30&page=1&sort_by=lastChecked&sort_type=desc&protocols=https&anonymityLevel=elite",
        "https://proxylist.geonode.com/api/proxy-list?limit=30&page=1&sort_by=lastChecked&sort_type=desc&country=CN&protocols=https&anonymityLevel=elite",
    ]:
        try:
            text = _direct_fetch(url, timeout=10)
            data = json.loads(text)
            for item in (data.get("data", []) or []):
                host = item.get("ip", "")
                port = int(item.get("port", 0))
                if host and port:
                    proxies.append((host, port))
        except Exception as e:
            logger.debug(f"[HTTP源] geonode 失败: {e}")

    # free-proxy-list.net（HTML）
    try:
        text = _direct_fetch("https://free-proxy-list.net/", timeout=8)
        pattern = re.compile(r"(\d{1,3}(?:\.\d{1,3}){3})\s*</td>\s*<td>\s*(\d{2,5})")
        for m in pattern.finditer(text):
            proxies.append((m.group(1), int(m.group(2))))
    except Exception as e:
        logger.debug(f"[HTTP源] free-proxy-list 失败: {e}")

    # 89ip.cn（国内代理）
    try:
        text = _direct_fetch("https://www.89ip.cn/tqdl.html?api=1&num=30&port=&address=&isp=", timeout=8)
        pattern = re.compile(r"(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})")
        for m in pattern.finditer(text):
            proxies.append((m.group(1), int(m.group(2))))
    except Exception as e:
        logger.debug(f"[HTTP源] 89ip 失败: {e}")

    return _dedupe(proxies)[:30]


def _fetch_socks5_candidates() -> List[Tuple[str, int]]:
    """从 GitHub 公开列表抓取候选 SOCKS5 代理"""
    proxies: List[Tuple[str, int]] = []
    for url in _SOCKS5_SOURCES:
        try:
            text = _direct_fetch(url, timeout=6)
            for line in text.strip().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                # 格式: host:port 或 host:port:username:password
                parts = line.split(":")
                if len(parts) >= 2:
                    try:
                        host = parts[0].strip()
                        port = int(parts[1].strip())
                        if host and port:
                            proxies.append((host, port))
                    except ValueError:
                        continue
        except Exception as e:
            logger.debug(f"[SOCKS5源] {url[-30:]} 失败: {e}")
    return _dedupe(proxies)[:20]


def _validate_http_proxy(host: str, port: int, timeout: float = 3) -> bool:
    """验证HTTP代理能否访问东方财富"""
    try:
        proxy_handler = urllib.request.ProxyHandler({
            "https": f"http://{host}:{port}",
            "http": f"http://{host}:{port}",
        })
        opener = urllib.request.build_opener(proxy_handler)
        req = urllib.request.Request(
            "https://push2.eastmoney.com/api/qt/ulist.np/get"
            "?fields=f2,f3,f12,f14&secids=1.000001",
            headers={
                "User-Agent": random.choice(DATA_SOURCE_CONFIG["user_agents"]),
                "Referer": "https://quote.eastmoney.com",
            },
        )
        with opener.open(req, timeout=timeout) as resp:
            data = resp.read().decode("utf-8", errors="ignore")
            return "data" in data and len(data) > 50
    except Exception:
        return False


def _validate_socks5_proxy(host: str, port: int, timeout: float = 4) -> bool:
    """验证SOCKS5代理可用性（连接成功即算通过）"""
    try:
        import socks
        start = time.perf_counter()
        sock = socks.socksocket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        sock.close()
        elapsed = (time.perf_counter() - start) * 1000
        logger.debug(f"[SOCKS5验证] {host}:{port} OK {elapsed:.0f}ms")
        return True
    except Exception:
        return False


# ════════════════════════════════════════════════════════════════════════════
# 配置代理初始化
# ════════════════════════════════════════════════════════════════════════════

_DEFAULT_UPSTREAM_PROXY_URLS = [
    "http://dragonflow:VKoF7-u1qOQ2beXH@23.142.188.254:7890",
]
_configured_proxy_urls: Optional[List[str]] = None


def _parse_proxy_url(proxy_url: str) -> Optional[Tuple[str, int, str, str, str]]:
    try:
        parsed = urlparse(proxy_url.strip())
    except Exception:
        return None
    if not parsed.scheme or not parsed.hostname or not parsed.port:
        return None
    protocol = parsed.scheme.lower()
    if protocol not in {"http", "https"}:
        return None
    return parsed.hostname, int(parsed.port), protocol, parsed.username or "", parsed.password or ""


def _get_configured_proxy_urls() -> List[str]:
    global _configured_proxy_urls
    if _configured_proxy_urls is not None:
        return _configured_proxy_urls

    configured: List[str] = []
    raw_multi = (os.environ.get("DRAGONFLOW_UPSTREAM_PROXIES", "") or "").strip()
    raw_single = (os.environ.get("DRAGONFLOW_UPSTREAM_PROXY", "") or "").strip()

    if raw_multi:
        configured.extend([i.strip() for i in re.split(r"[;,]", raw_multi) if i.strip()])
    elif raw_single:
        configured.append(raw_single)
    elif os.environ.get("USE_PROXY", "false").lower() == "true":
        host = (os.environ.get("PROXY_HOST", "") or "").strip()
        port = (os.environ.get("PROXY_PORT", "") or "").strip()
        username = (os.environ.get("PROXY_USER", "") or os.environ.get("PROXY_USERNAME", "") or "").strip()
        password = (os.environ.get("PROXY_PASSWORD", "") or "").strip()
        if host and port.isdigit():
            configured.append(f"http://{username}:{password}@{host}:{port}" if username else f"http://{host}:{port}")

    if not configured:
        configured = list(_DEFAULT_UPSTREAM_PROXY_URLS)

    _configured_proxy_urls = configured
    return configured


def _seed_configured_proxies() -> int:
    global _configured_proxy_keys
    added = 0
    for proxy_url in _get_configured_proxy_urls():
        parsed = _parse_proxy_url(proxy_url)
        if not parsed:
            continue
        host, port, protocol, username, password = parsed
        key = f"{protocol}||{username or ''}|{host}|{port}"
        _configured_proxy_keys.add(key)
        _http_pool.add(host, port, protocol, username, password, source="configured")
        added += 1
    return added


# ════════════════════════════════════════════════════════════════════════════
# 刷新调度
# ════════════════════════════════════════════════════════════════════════════

def refresh_http_pool(validate: bool = True, force: bool = False) -> dict:
    """刷新 HTTP 代理池"""
    if not force and not _http_pool.should_retry_empty_refresh():
        return {"skipped": True, "raw": 0, "valid": 0}

    # 先注入配置代理
    configured_count = _seed_configured_proxies()
    if configured_count > 0:
        return {
            "skipped": False,
            "raw": configured_count,
            "valid": _http_pool.usable_count,
        }

    _http_pool.mark_refresh_attempt()
    logger.info("[HTTP池] 刷新中...")
    candidates = _fetch_http_candidates()
    valid_count = 0

    if validate and candidates:
        to_validate = candidates[:12]
        with ThreadPoolExecutor(max_workers=min(6, len(to_validate))) as pool:
            futures = {
                pool.submit(_validate_http_proxy, h, p, 2.5): (h, p)
                for h, p in to_validate
            }
            for future in as_completed(futures):
                h, p = futures[future]
                try:
                    if future.result():
                        _http_pool.add(h, p, "http", source="pool")
                        valid_count += 1
                        if valid_count >= 8:
                            break
                except Exception:
                    continue

    # 验证失败但有候选，直接加入（兜底）
    if valid_count == 0 and candidates:
        for h, p in candidates[:8]:
            _http_pool.add(h, p, "http", source="pool")
            valid_count += 1

    _http_pool.remove_dead()
    _http_pool.mark_refreshed()
    logger.info(f"[HTTP池] 刷新完成: {valid_count}个可用, 共{_http_pool.size}个")
    return {"skipped": False, "raw": len(candidates), "valid": valid_count}


def refresh_socks5_pool(force: bool = False) -> dict:
    """刷新 SOCKS5 动态池"""
    if not force and not _socks5_pool.needs_refresh():
        return {"skipped": True, "raw": 0, "valid": 0}

    # 静态SOCKS5已通过 route_domain 处理，这里只补充动态池
    candidates = _fetch_socks5_candidates()
    valid_count = 0

    for h, p in candidates:
        if _validate_socks5_proxy(h, p, timeout=3):
            _socks5_pool.add(h, p)
            valid_count += 1
            if valid_count >= 5:
                break
        time.sleep(0.2)

    _socks5_pool.remove_dead()
    _socks5_pool.mark_refreshed()
    logger.info(f"[SOCKS5池] 刷新完成: {valid_count}个可用, 共{_socks5_pool.size}个")
    return {"skipped": False, "raw": len(candidates), "valid": valid_count}


def ensure_pool_ready():
    """确保代理系统就绪：注入配置代理 + 按需刷新"""
    _seed_configured_proxies()

    # HTTP池：配置代理充足时不刷新，否则补充
    if _http_pool.usable_count == 0:
        refresh_http_pool(validate=True, force=True)
    elif _http_pool.needs_refresh():
        refresh_http_pool(validate=True)

    # SOCKS5池：按需刷新（异步会更好，这里同步做最小化）
    # 注：SOCKS5验证较慢，主要靠 route_domain 时的按需验证


# ════════════════════════════════════════════════════════════════════════════
# 第五层：统一代理出口
# ════════════════════════════════════════════════════════════════════════════

_direct_ok_until = 0.0
_direct_fail_until = 0.0


def _get_ua() -> str:
    return random.choice(DATA_SOURCE_CONFIG["user_agents"])


def _append_query_params(url: str, params: Optional[Dict]) -> str:
    if not params:
        return url
    filtered = {k: v for k, v in params.items() if v is not None}
    if not filtered:
        return url
    query = urlencode(filtered, doseq=True)
    return f"{url}{'&' if '?' in url else '?'}{query}"


def _decode_response(raw: bytes, encoding: str, resp_headers) -> str:
    if encoding == "auto":
        ct = resp_headers.get("Content-Type", "")
        if "gbk" in ct.lower() or "gb2312" in ct.lower():
            return raw.decode("gbk", errors="ignore")
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return raw.decode("gbk", errors="ignore")
    return raw.decode(encoding, errors="replace")


def proxied_get(
    url: str,
    referer: str = "",
    encoding: str = "utf-8",
    timeout: float = 10.0,
    max_retries: int = 3,
    params: Optional[Dict] = None,
    headers: Optional[Dict[str, str]] = None,
) -> str:
    """
    核心出口：所有金融数据请求都走这里。
    域名路由 → SOCKS5 / HTTP / direct 自动选择
    失败 → 健康反馈 → 下次路由自动规避坏节点
    """
    global _direct_ok_until, _direct_fail_until

    request_url = _append_query_params(url, params)
    last_error: Optional[Exception] = None
    tried_keys: set[str] = set()

    # ── Step 1: 域名路由决策 ───────────────────────────────────────────
    strategy, proxy = route_domain(request_url)

    # ── Step 2a: Direct 路径 ──────────────────────────────────────────
    if strategy == "direct":
        if time.time() >= _direct_fail_until:
            try:
                return _direct_request(request_url, referer, encoding, timeout, headers=headers)
            except Exception as e:
                last_error = e
                _direct_ok_until = 0.0
                _direct_fail_until = time.time() + 15

    # ── Step 2b: SOCKS5 路径 → 失败则自动降级HTTP池 ──────────────
    elif strategy == "socks5" and proxy:
        socks5_err = _try_proxy(proxy, request_url, referer, encoding, timeout, tried_keys)
        if socks5_err is None:
            # SOCKS5成功：直接返回缓存结果，不再走HTTP池
            return _get_cached_response()
        # SOCKS5失败，降级HTTP池
        logger.debug(f"[路由] SOCKS5 {proxy.url} 失败，降级HTTP: {socks5_err}")
        proxy.record_failure()
        strategy = "http"
        proxy = None

    # ── Step 2c: HTTP 池路径（默认）───────────────────────────────────
    if strategy == "http":
        # 直连试探（仅在池为空且刚过失败冷却时）
        if (_http_pool.usable_count == 0
                and time.time() >= _direct_fail_until
                and time.time() >= _direct_ok_until - 300):
            try:
                result = _direct_request(request_url, referer, encoding, timeout, headers=headers)
                _direct_ok_until = time.time() + 300
                _direct_fail_until = 0.0
                return result
            except Exception as e:
                last_error = e
                _direct_ok_until = 0.0
                _direct_fail_until = time.time() + 15

        ensure_pool_ready()

        for attempt in range(max_retries):
            if attempt > 0:
                time.sleep(random.uniform(0.2, 0.6))

            http_proxy = _http_pool.get_best()
            if http_proxy is None:
                if time.time() < _direct_fail_until:
                    continue
                # 池空，直连兜底
                try:
                    result = _direct_request(request_url, referer, encoding, timeout, headers=headers)
                    _direct_ok_until = time.time() + 300
                    _direct_fail_until = 0.0
                    return result
                except Exception as e:
                    last_error = e
                    _direct_fail_until = time.time() + 15
                    continue

            if http_proxy.key in tried_keys:
                continue

            tried_keys.add(http_proxy.key)
            err = _try_proxy(http_proxy, request_url, referer, encoding, timeout, tried_keys)
            if err is None:
                return _get_cached_response()
            last_error = err

    # ── Step 3: 全部失败 ───────────────────────────────────────────────
    if last_error:
        raise last_error
    raise RuntimeError(f"代理请求失败: {url}")


# 线程局部变量：跨函数传递响应
_thread_response: dict = {}


def _try_proxy(
    proxy: Proxy,
    url: str,
    referer: str,
    encoding: str,
    timeout: float,
    tried_keys: set[str],
) -> Optional[Exception]:
    """尝试用指定代理请求；返回None表示成功，Exception表示失败"""
    global _thread_response
    start = time.perf_counter()

    try:
        if proxy.protocol == "socks5":
            result_raw, headers = _request_via_socks5(proxy, url, referer, timeout, headers=None)
        else:
            result_raw, headers = _request_via_http_proxy(proxy, url, referer, timeout, headers=None)

        elapsed_ms = (time.perf_counter() - start) * 1000
        proxy.record_success(elapsed_ms)
        _thread_response["raw"] = result_raw
        _thread_response["headers"] = headers
        return None


    except Exception as e:
        proxy.record_failure()
        logger.debug(f"[代理] {proxy.url} 失败: {e}")
        return e


def _get_cached_response() -> str:
    global _thread_response
    raw = _thread_response.get("raw", b"")
    headers = _thread_response.get("headers", {})
    return raw.decode("utf-8", errors="replace")


def _request_via_http_proxy(
    proxy: Proxy,
    url: str,
    referer: str,
    timeout: float,
    headers: Optional[Dict[str, str]] = None,
) -> Tuple[bytes, dict]:
    """通过HTTP代理发送请求"""
    proxy_handler = urllib.request.ProxyHandler({
        "https": proxy.auth_url,
        "http": proxy.auth_url,
    })
    opener = urllib.request.build_opener(proxy_handler)

    request_headers = {
        "User-Agent": _get_ua(),
        "Accept": "text/html,application/xhtml+xml,application/json,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "keep-alive",
    }
    if referer:
        request_headers["Referer"] = referer
    if headers:
        request_headers.update({k: v for k, v in headers.items() if v is not None})

    req = urllib.request.Request(url, headers=request_headers)
    with opener.open(req, timeout=timeout) as resp:
        raw = resp.read()
        return raw, dict(resp.headers)


def _request_via_socks5(
    proxy: Proxy,
    url: str,
    referer: str,
    timeout: float,
    headers: Optional[Dict[str, str]] = None,
) -> Tuple[bytes, dict]:
    """通过SOCKS5代理发送请求（requests库）"""
    import requests

    parsed = urlparse(url)
    scheme = parsed.scheme or "https"
    default_headers = {
        "User-Agent": _get_ua(),
        "Referer": referer or "https://finance.sina.com.cn",
    }
    if headers:
        default_headers.update(headers)

    proxies = {"http": proxy.auth_url, "https": proxy.auth_url}
    if proxy.username:
        # requests 的 SOCKS5 认证格式
        proxies = {
            "http": f"socks5://{quote(proxy.username, safe='')}:{quote(proxy.password, safe='')}@{proxy.host}:{proxy.port}",
            "https": f"socks5://{quote(proxy.username, safe='')}:{quote(proxy.password, safe='')}@{proxy.host}:{proxy.port}",
        }

    sess = requests.Session()
    resp = sess.get(url, proxies=proxies, headers=default_headers,
                    timeout=timeout, allow_redirects=True)
    return resp.content, dict(resp.headers)


def _direct_request(
    url: str,
    referer: str,
    encoding: str,
    timeout: float,
    headers: Optional[Dict[str, str]] = None,
) -> str:
    """直连请求（碰运气）"""
    request_headers = {
        "User-Agent": _get_ua(),
        "Accept": "text/html,application/xhtml+xml,application/json,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
    }
    if referer:
        request_headers["Referer"] = referer
    if headers:
        request_headers.update({k: v for k, v in headers.items() if v is not None})

    req = urllib.request.Request(url, headers=request_headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        return _decode_response(raw, encoding, dict(resp.headers))


# ════════════════════════════════════════════════════════════════════════════
# requests Session 代理版（供 akshare 注入）
# ════════════════════════════════════════════════════════════════════════════

def get_proxied_session():
    """返回一个配了代理的 requests.Session（供 akshare 使用）"""
    try:
        import requests as req_lib
        _seed_configured_proxies()
        session = req_lib.Session()
        session.headers.update({
            "User-Agent": _get_ua(),
            "Accept-Language": "zh-CN,zh;q=0.9",
        })
        proxy = _http_pool.get_best()
        if proxy:
            session.proxies = {
                "http": proxy.auth_url,
                "https": proxy.auth_url,
            }
        return session
    except ImportError:
        return None


# ════════════════════════════════════════════════════════════════════════════
# 数据源端点探活（东财封禁自愈）
# ════════════════════════════════════════════════════════════════════════════

_DATA_SOURCE_ENDPOINTS = [
    ("eastmoney_ulist",  "https://push2.eastmoney.com/api/qt/ulist.np/get?fields=f2,f3,f12,f14&secids=1.000001,0.399006",
     "https://quote.eastmoney.com", "utf-8"),
    ("eastmoney_clist",  "https://push2.eastmoney.com/api/qt/clist/get?pn=1&pz=3&np=1&fltt=2&invt=2&fid=f3&fs=m:0+t:6&fields=f2,f3,f12,f14",
     "https://quote.eastmoney.com", "utf-8"),
    ("tencent_quote",    "https://qt.gtimg.cn/q=sh000001,sz399001,sz399006",
     "https://finance.qq.com", "utf-8"),
    ("sina_quotes",      "https://hq.sinajs.cn/list=sh000001,sz399001,sz399006",
     "https://finance.sina.com.cn", "gbk"),
    ("sina_vip",         "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData?node=hs_a&num=3&sort=changepercent&asc=0&page=1",
     "https://finance.sina.com.cn", "utf-8"),
]

_active_endpoint = {"name": "eastmoney_ulist", "ok": True, "failures": 0, "last_try": 0.0}
_endpoint_lock = threading.Lock()


def probe_validate_endpoints() -> dict:
    """
    启动时或定期探活5个数据源端点，找到最快可达的那个。
    连续2次失败才切换。
    """
    global _active_endpoint
    results = []
    now = time.time()

    for name, url, referer, enc in _DATA_SOURCE_ENDPOINTS:
        ok = False
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Referer": referer,
            })
            with urllib.request.urlopen(req, timeout=4) as resp:
                text = resp.read().decode(enc, errors="ignore")
                ok = len(text) > 20
        except Exception:
            pass
        results.append({"name": name, "ok": ok, "url": url})
        if ok:
            with _endpoint_lock:
                if _active_endpoint["name"] != name or not _active_endpoint["ok"]:
                    _active_endpoint = {"name": name, "ok": True, "failures": 0, "last_try": now}
                    logger.info(f"[端点] 切换到 {name}")
            break

    if not any(r["ok"] for r in results):
        with _endpoint_lock:
            _active_endpoint["failures"] += 1
            _active_endpoint["last_try"] = now
            logger.warning(f"[端点] 全部探活失败，已连续{_active_endpoint['failures']}次")

    return {"active": _active_endpoint.copy(), "results": results, "probed_at": now}


def get_pool_status() -> dict:
    """代理池状态（供 Dashboard 显示）"""
    return {
        "http": {
            "total": _http_pool.size,
            "usable": _http_pool.usable_count,
            "last_refresh": _http_pool._last_refresh,
            "proxies": [p.to_dict() for p in _http_pool._proxies[:10]],
        },
        "socks5": {
            "total": _socks5_pool.size,
            "usable": _socks5_pool.usable_count,
            "last_refresh": _socks5_pool._last_refresh,
        },
        "active_endpoint": _active_endpoint.copy(),
        "static_socks5": _get_static_socks5().to_dict() if _get_static_socks5() else None,
    }


# ════════════════════════════════════════════════════════════════════════════
# 第六层：WAF检测 + Playwright浏览器兜底
# ════════════════════════════════════════════════════════════════════════════

_WAF_SIGNATURES = {
    "aliyun", "waf", "captcha", "raycloud", "yundun",
    "https://errors.google.com", "js是人类的好朋友",
    "_waf_bd", "aliyun_waf", "gtPwJE", "renderData",
    "txwaf", "jiasule", "baidu_waf", "360_waf",
    "security", "validat", "challenge", "blocked",
}
_WAF_STATUS_CODES = {403, 503, 504, 429}


def _is_waf_response(resp_text: str, status_code: int = 200) -> bool:
    """检测响应是否为WAF拦截页"""
    if status_code in _WAF_STATUS_CODES:
        return True
    if not resp_text:
        return False
    text_lower = resp_text.lower()
    return any(sig in text_lower for sig in _WAF_SIGNATURES)


# ── Playwright浏览器兜底（cookie复用）────────────────────────────────────

_browser_cookie_store: Dict[str, List[dict]] = {}
_browser_contexts: Dict[str, Any] = {}  # domain -> playwright context
_BROWSER_CONCURRENCY_LIMIT = 2
_browser_semaphore: Optional[Any] = None


def _get_browser_semaphore():
    global _browser_semaphore
    if _browser_semaphore is None:
        try:
            import threading
            _browser_semaphore = threading.Semaphore(_BROWSER_CONCURRENCY_LIMIT)
        except Exception:
            _browser_semaphore = None
    return _browser_semaphore


def fetch_with_browser(url: str, timeout: int = 30) -> str:
    """
    Playwright浏览器抓取（cookie复用，最多2个并发）
    用于：当 requests 被WAF拦截时兜底
    """
    from urllib.parse import urlparse
    parsed = urlparse(url)
    domain = parsed.hostname or ""

    semaphore = _get_browser_semaphore()
    if semaphore:
        semaphore.acquire()

    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            # 复用context（cookie保持）
            if domain not in _browser_contexts:
                try:
                    browser = p.chromium.launch(
                        headless=True,
                        args=[
                            "--disable-blink-features=AutomationControlled",
                            "--disable-dev-shm-usage",
                            "--no-sandbox",
                        ],
                        timeout=15000,
                    )
                except Exception as e:
                    if "Executable doesn't exist" in str(e):
                        raise RuntimeError(
                            "Playwright浏览器未安装，请运行: playwright install chromium"
                        ) from e
                    raise
                context = browser.new_context(
                    user_agent=(
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    locale="zh-CN",
                    timezone_id="Asia/Shanghai",
                    extra_http_headers={
                        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                    },
                )
                _browser_contexts[domain] = {"browser": browser, "context": context}
            else:
                cached = _browser_contexts[domain]
                browser = cached["browser"]
                context = cached["context"]

            page = context.new_page()
            try:
                page.goto(url, timeout=timeout * 1000, wait_until="networkidle")
                # 等待动态内容加载
                page.wait_for_timeout(2000)
                content = page.content()
            finally:
                page.close()

            # 更新cookie
            try:
                _browser_cookie_store[domain] = context.cookies()
            except Exception:
                pass

            return content

    except RuntimeError:
        raise  # 已给出明确错误信息
    except Exception as e:
        logger.warning(f"[浏览器] {url} 失败: {e}")
        raise RuntimeError(f"Playwright抓取失败: {e}") from e
    finally:
        if semaphore:
            semaphore.release()


def smart_fetch(
    url: str,
    referer: str = "",
    encoding: str = "utf-8",
    timeout: float = 10.0,
    force_browser: bool = False,
) -> str:
    """
    智能抓取：requests → WAF检测 → Playwright兜底
    策略：xueqiu/10jqka 默认强制browser（风控严格）
    """
    domain = urlparse(url).hostname or ""

    # 强制browser的域名（风控严格）
    browser_first_domains = {"xueqiu.com", "10jqka.com.cn", "t.10jqka.com.cn",
                              "xueqiu.com.cn"}
    is_strict = any(d in domain for d in browser_first_domains)

    if force_browser or is_strict:
        logger.debug(f"[智能抓取] {domain} → 强制浏览器")
        return fetch_with_browser(url, timeout=int(timeout))

    # Step 1: 尝试 requests
    try:
        result = proxied_get(url, referer=referer, encoding=encoding,
                            timeout=timeout)
        # Step 2: WAF检测
        if _is_waf_response(result):
            logger.info(f"[WAF检测] {domain} 被拦截，切换浏览器")
        else:
            return result
    except Exception as e:
        logger.debug(f"[智能抓取] requests失败: {e}")

    # Step 3: Playwright兜底
    try:
        return fetch_with_browser(url, timeout=int(timeout * 1.5))
    except Exception as e:
        raise RuntimeError(f"smart_fetch失败（requests+WAF兜底均失败）: {e}") from e


# ════════════════════════════════════════════════════════════════════════════
# 第七层：自进化策略管理器 + 统计持久化
# ════════════════════════════════════════════════════════════════════════════

import sqlite3
from pathlib import Path

_DB_PATH = Path(__file__).parent.parent / "data" / "dragonflow.db"


def _get_stats_db() -> sqlite3.Connection:
    """获取或创建统计数据库"""
    db_path = Path(__file__).parent.parent / "data" / "dragonflow_stats.db"
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS proxy_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            host TEXT NOT NULL,
            port INTEGER NOT NULL,
            protocol TEXT DEFAULT 'http',
            success_count INTEGER DEFAULT 0,
            fail_count INTEGER DEFAULT 0,
            total_latency_ms REAL DEFAULT 0,
            avg_latency_ms REAL DEFAULT 0,
            consecutive_fails INTEGER DEFAULT 0,
            last_used REAL DEFAULT 0,
            last_success REAL DEFAULT 0,
            last_fail REAL DEFAULT 0,
            updated_at REAL DEFAULT 0,
            UNIQUE(host, port, protocol)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS strategy_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy TEXT UNIQUE NOT NULL,
            success_count INTEGER DEFAULT 0,
            fail_count INTEGER DEFAULT 0,
            total_latency_ms REAL DEFAULT 0,
            avg_latency_ms REAL DEFAULT 0,
            updated_at REAL DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS domain_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            domain TEXT UNIQUE NOT NULL,
            strategy TEXT NOT NULL,
            success_count INTEGER DEFAULT 0,
            fail_count INTEGER DEFAULT 0,
            avg_latency_ms REAL DEFAULT 0,
            updated_at REAL DEFAULT 0
        )
    """)
    conn.commit()
    return conn


# ── 策略管理器 ───────────────────────────────────────────────────────────

class StrategyManager:
    """
    自进化策略选择器：根据历史成功率动态选择最优策略
    策略: "direct" | "http" | "socks5" | "browser"
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._stats: Dict[str, Dict] = {}  # strategy -> {success, fail, latency_sum, count}
        self._domain_stats: Dict[str, Dict] = {}  # domain -> strategy stats
        self._load_from_db()

    def _load_from_db(self):
        """启动时从SQLite加载历史统计"""
        try:
            conn = _get_stats_db()
            for row in conn.execute("SELECT strategy, success_count, fail_count, avg_latency_ms FROM strategy_stats"):
                strategy, success, fail, avg_lat = row
                self._stats[strategy] = {
                    "success": success,
                    "fail": fail,
                    "latency_sum": avg_lat * (success + fail) if (success + fail) > 0 else 0,
                    "count": success + fail,
                }
            for row in conn.execute("SELECT domain, strategy, success_count, fail_count, avg_latency_ms FROM domain_stats"):
                domain, strategy, success, fail, avg_lat = row
                self._domain_stats[domain] = {
                    "strategy": strategy,
                    "success": success,
                    "fail": fail,
                    "avg_latency": avg_lat or 999,
                }
            conn.close()
        except Exception as e:
            logger.debug(f"[策略] 加载统计失败: {e}")

    def _save_strategy_stats(self, strategy: str):
        """持久化策略统计到SQLite"""
        try:
            conn = _get_stats_db()
            stats = self._stats.get(strategy, {"success": 0, "fail": 0, "latency_sum": 0, "count": 0})
            avg_lat = (stats["latency_sum"] / stats["count"]) if stats["count"] > 0 else 0
            conn.execute("""
                INSERT INTO strategy_stats (strategy, success_count, fail_count, avg_latency_ms, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(strategy) DO UPDATE SET
                    success_count = success_count + excluded.success_count,
                    fail_count = fail_count + excluded.fail_count,
                    avg_latency_ms = excluded.avg_latency_ms,
                    updated_at = excluded.updated_at
            """, (strategy, stats["success"], stats["fail"], avg_lat, time.time()))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[策略] 保存统计失败: {e}")

    def _save_domain_stats(self, domain: str):
        """持久化domain统计到SQLite"""
        try:
            conn = _get_stats_db()
            ds = self._domain_stats.get(domain)
            if not ds:
                conn.close()
                return
            conn.execute("""
                INSERT INTO domain_stats (domain, strategy, success_count, fail_count, avg_latency_ms, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(domain) DO UPDATE SET
                    strategy = excluded.strategy,
                    success_count = excluded.success_count,
                    fail_count = excluded.fail_count,
                    avg_latency_ms = excluded.avg_latency_ms,
                    updated_at = excluded.updated_at
            """, (domain, ds.get('strategy','http'), ds['success'], ds['fail'],
                  ds.get('avg_latency', 999), time.time()))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[策略] domain统计保存失败: {e}")

    def choose(self, domain: str, context: str = "default") -> str:
        """
        选择最优策略：优先domain级别，再全局级别
        """
        with self._lock:
            # 1. 尝试domain特定策略
            if domain in self._domain_stats:
                ds = self._domain_stats[domain]
                total = ds["success"] + ds["fail"]
                if total >= 3:  # 样本足够
                    success_rate = ds["success"] / total if total > 0 else 0
                    if success_rate >= 0.6:
                        return ds["strategy"]

            # 2. 全局策略选择
            best, best_score = "http", -1.0
            for strategy, stats in self._stats.items():
                total = stats["success"] + stats["fail"]
                if total == 0:
                    continue
                success_rate = stats["success"] / total
                avg_lat = (stats["latency_sum"] / total) if total > 0 else 9999
                # 评分 = 成功率*0.7 - 归一化延迟*0.3
                score = success_rate * 0.7 - min(avg_lat / 10000, 1.0) * 0.3
                if score > best_score:
                    best, best_score = strategy, score

            return best

    def report(self, strategy: str, success: bool, latency_ms: float,
               domain: str = ""):
        """记录执行结果"""
        with self._lock:
            if strategy not in self._stats:
                self._stats[strategy] = {"success": 0, "fail": 0,
                                          "latency_sum": 0, "count": 0}
            s = self._stats[strategy]
            if success:
                s["success"] += 1
            else:
                s["fail"] += 1
            s["latency_sum"] += latency_ms
            s["count"] += 1

            # domain级别统计
            if domain:
                if domain not in self._domain_stats:
                    self._domain_stats[domain] = {"strategy": strategy,
                                                   "success": 0, "fail": 0,
                                                   "avg_latency": 999}
                ds = self._domain_stats[domain]
                ds["strategy"] = strategy  # 最近成功的策略
                if success:
                    ds["success"] += 1
                else:
                    ds["fail"] += 1
                total = ds["success"] + ds["fail"]
                ds["avg_latency"] = (
                    (ds["avg_latency"] * (total - 1) + latency_ms) / total
                ) if total > 0 else latency_ms

            # 定期持久化（每10次汇报写一次DB）
            if s["count"] % 10 == 0:
                self._save_strategy_stats(strategy)
            # domain统计持久化（每5次更新写一次）
            if domain and (ds.get('success', 0) + ds.get('fail', 0)) % 5 == 0:
                self._save_domain_stats(domain)

    def get_stats(self) -> dict:
        return {
            "strategies": {
                k: {"success": v["success"], "fail": v["fail"],
                    "rate": round(v["success"] / max(v["count"], 1), 3),
                    "avg_lat_ms": round(v["latency_sum"] / max(v["count"], 1), 1)}
                for k, v in self._stats.items()
            },
            "domains": dict(self._domain_stats),
        }


# 全局策略管理器实例
_strategy_manager: Optional[StrategyManager] = None


def get_strategy_manager() -> StrategyManager:
    global _strategy_manager
    if _strategy_manager is None:
        _strategy_manager = StrategyManager()
    return _strategy_manager


# ── proxy_stats 持久化 ──────────────────────────────────────────────────

def save_proxy_stats():
    """将当前池中代理的健康统计写入SQLite"""
    try:
        ensure_pool_ready()  # 先补充池
        conn = _get_stats_db()
        now = time.time()
        for proxy in list(_http_pool._proxies) + list(_socks5_pool._proxies):
            conn.execute("""
                INSERT INTO proxy_stats
                    (host, port, protocol, success_count, fail_count,
                     avg_latency_ms, consecutive_fails, last_used, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(host, port, protocol) DO UPDATE SET
                    success_count = excluded.success_count,
                    fail_count = excluded.fail_count,
                    avg_latency_ms = excluded.avg_latency_ms,
                    consecutive_fails = excluded.consecutive_fails,
                    last_used = MAX(last_used, excluded.last_used),
                    updated_at = excluded.updated_at
            """, (proxy.host, proxy.port, proxy.protocol,
                  proxy.success_count, proxy.fail_count,
                  proxy.avg_latency, proxy.consecutive_fails,
                  proxy.last_used, now))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.debug(f"[代理统计] 持久化失败: {e}")


# ── 健康检测进程（后台守护）───────────────────────────────────────────────

_proxy_health_thread: Optional[threading.Thread] = None
_proxy_health_running = False


def _proxy_health_loop():
    """后台健康检测：每5分钟保存统计，每10分钟刷新池"""
    global _proxy_health_running
    while _proxy_health_running:
        try:
            # 保存代理统计
            save_proxy_stats()
            # 主动刷新HTTP池（如果池空了）
            if _http_pool.usable_count < 2:
                refresh_http_pool(validate=True)
            # SOCKS5池按需刷新
            if _socks5_pool.needs_refresh():
                refresh_socks5_pool()
        except Exception as e:
            logger.debug(f"[健康检测] 异常: {e}")
        time.sleep(300)  # 5分钟


def start_proxy_health_daemon():
    global _proxy_health_thread, _proxy_health_running
    if _proxy_health_running:
        return
    _proxy_health_running = True
    _proxy_health_thread = threading.Thread(target=_proxy_health_loop,
                                             daemon=True, name="proxy-health")
    _proxy_health_thread.start()
    logger.info("[代理] 健康守护线程启动")


def stop_proxy_health_daemon():
    global _proxy_health_running
    _proxy_health_running = False
    if _proxy_health_thread:
        save_proxy_stats()
        logger.info("[代理] 健康守护线程停止")


# ════════════════════════════════════════════════════════════════════════════
# 第八层：curl_cffi JA3/TLS指纹伪装（Tier 1主力）
# ════════════════════════════════════════════════════════════════════════════

import random as _random

# 可用TLS指纹池（按优先级）
_TLS_FINGERPRINTS = [
    {"Name": "chrome120",  "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"},
    {"Name": "chrome119",  "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"},
    {"Name": "safari17_0", "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"},
    {"Name": "edge101",    "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/101.0.1210.39"},
]

# 严格WAF域名黑名单（直接跳过curl_cffi）
_STRICT_WAF_DOMAINS = {
    "xueqiu.com", "10jqka.com.cn", "t.10jqka.com.cn",
    "xueqiu.com.cn", "xueqiu.net",
}


def _get_tls_fingerprint() -> dict:
    """随机选择一个TLS指纹（均匀分布）"""
    return _random.choice(_TLS_FINGERPRINTS)


def _build_http_headers(base_ref: str = "") -> dict:
    """构建随机化的HTTP请求头（模拟不同浏览器序列）"""
    fp = _get_tls_fingerprint()
    accept_langs = [
        "zh-CN,zh;q=0.9,en;q=0.8",
        "en-US,en;q=0.9,zh-CN;q=0.8",
        "zh,zh-CN;q=0.9,en;q=0.8",
    ]
    headers = {
        "User-Agent": fp["ua"],
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": _random.choice(accept_langs),
        "Accept-Encoding": "gzip, deflate, br",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
    }
    if base_ref:
        headers["Referer"] = base_ref

    # Header顺序随机化（高维度指纹扰动）
    items = list(headers.items())
    _random.shuffle(items)
    return dict(items), fp["Name"]


def curl_tls_get(
    url: str,
    proxy_auth_url: str = "",
    referer: str = "",
    timeout: float = 10.0,
) -> Tuple[bytes, int, str]:
    """
    curl_cffi TLS指纹请求（Tier 1主力transport）
    返回: (raw_bytes, status_code, fingerprint_name)
    """
    from curl_cffi import requests as curl_requests

    headers, fp_name = _build_http_headers(referer)
    proxies = None
    if proxy_auth_url:
        proxies = {"http": proxy_auth_url, "https": proxy_auth_url}

    try:
        resp = curl_requests.get(
            url,
            impersonate=fp_name,
            headers=headers,
            proxies=proxies,
            timeout=int(timeout),
            allow_redirects=True,
            verify=False,  # 跳过无效证书警告
        )
        return resp.content, resp.status_code, fp_name
    except Exception as e:
        raise RuntimeError(f"curl_tls失败 [{fp_name}]: {e}") from e


def curl_tls_get_with_proxy(
    url: str,
    proxy: Optional["Proxy"] = None,
    referer: str = "",
    timeout: float = 10.0,
) -> Tuple[bytes, int, str]:
    """
    curl_cffi + Proxy对象（从ProxyPool获取）
    """
    proxy_url = proxy.auth_url if proxy else ""
    return curl_tls_get(url, proxy_url, referer, timeout)


# ════════════════════════════════════════════════════════════════════════════
# 第九层：升级版 smart_fetch（整合全部transport）
# ════════════════════════════════════════════════════════════════════════════

_STRICT_WAF_DOMAINS: set = {
    "xueqiu.com", "10jqka.com.cn", "t.10jqka.com.cn",
}


def smart_fetch_v2(
    url: str,
    referer: str = "",
    encoding: str = "utf-8",
    timeout: float = 10.0,
    force_browser: bool = False,
) -> str:
    """
    智能抓取 v2：curl_tls → WAF检测 → Playwright兜底

    传输策略优先级：
      1. curl_tls（curl_cffi JA3伪装，默认主力）
      2. browser（Playwright兜底，严格WAF域名）
    """
    from urllib.parse import urlparse
    parsed = urlparse(url)
    domain = parsed.hostname or ""

    is_strict = any(d in domain for d in _STRICT_WAF_DOMAINS)

    # ── 策略1: curl_cffi TLS指纹（主力）──────────────────────────
    if not is_strict and not force_browser:
        try:
            # 从HTTP池获取代理
            http_proxy = _http_pool.get_best()

            raw, status_code, fp_name = curl_tls_get_with_proxy(
                url,
                proxy=http_proxy,
                referer=referer or f"https://{domain}/",
                timeout=timeout,
            )

            # WAF检测
            text = raw.decode("utf-8", errors="replace")
            if _is_waf_response(text, status_code):
                logger.info(f"[smart_fetch] WAF [{fp_name}] {domain} → 切换浏览器")
                if http_proxy:
                    http_proxy.record_failure()
            else:
                if http_proxy:
                    elapsed = 0.0  # 简化
                    http_proxy.record_success(elapsed)
                # 汇报策略成功
                sm = get_strategy_manager()
                sm.report("curl_tls", True, 0, domain)
                return _decode_response(raw, encoding, {})

        except Exception as e:
            logger.debug(f"[smart_fetch] curl_tls {domain} 失败: {e}")
            if http_proxy if 'http_proxy' in dir() else False:
                http_proxy.record_failure()
            sm = get_strategy_manager()
            sm.report("curl_tls", False, 0, domain)

    # ── 策略2: Playwright浏览器（兜底）───────────────────────────
    try:
        logger.debug(f"[smart_fetch] 切换浏览器 {domain}")
        content = fetch_with_browser(url, timeout=int(timeout * 1.5))
        sm = get_strategy_manager()
        sm.report("browser", not _is_waf_response(content), 0, domain)
        if not _is_waf_response(content):
            return content
    except Exception as e:
        logger.warning(f"[smart_fetch] browser {domain} 失败: {e}")
        sm = get_strategy_manager()
        sm.report("browser", False, 0, domain)

    raise RuntimeError(f"smart_fetch全部失败: {url}")
