"""
DragonFlow 反馈驱动循环
═══════════════════════════════════════════════════════════════════════════════════════
设计：TradeRecorder → StatCollector → FeedbackEvaluator → SignalGenerator
═══════════════════════════════════════════════════════════════════════════════════════

执行 → 结果 → 评估 → 调整策略
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, date
from typing import Dict, List, Optional, Tuple

from sqlalchemy import func, text

from models import get_session, TradeRecord, MarketSnapshot

logger = logging.getLogger("feeds.feedback_loop")


# ════════════════════════════════════════════════════════════════════════════════
# 数据模型
# ════════════════════════════════════════════════════════════════════════════════

@dataclass
class TradeResult:
    """单笔交易执行结果"""
    code: str
    name: str
    direction: str           # BUY / SELL
    price: float
    shares: int
    amount: float
    timestamp: datetime
    strategy_tag: str       # 如 "base_pivot_trend"
    data_source: str        # eastmoney / sina / tencent
    pick_type: str          # quick_scan / watch / adaptive
    score: float            # 入选时的评分
    zone: str               # attack / buildup / neutral
    emotion: str
    pnl: float = 0.0       # 卖出时填写


@dataclass
class DataSourceStats:
    """数据源质量统计"""
    name: str
    total_requests: int = 0
    failed_requests: int = 0
    avg_score: float = 0.0
    signal_issued: int = 0
    signal_succeeded: int = 0


# ════════════════════════════════════════════════════════════════════════════════
# 交易记录器
# ════════════════════════════════════════════════════════════════════════════════

class TradeRecorder:
    """
    记录每笔交易信号 + 执行结果。
    每日收盘后运行，关联持仓记录与候选来源。
    """

    def record_buy(self, code: str, name: str, price: float, shares: int,
                   strategy_tag: str, data_source: str, pick_type: str,
                   score: float, zone: str, emotion: str) -> bool:
        """记录一笔买入"""
        session = get_session()
        try:
            trade = TradeRecord(
                code=code, name=name, direction="BUY",
                price=price, shares=shares, amount=price * shares,
                strategy_tag=strategy_tag, data_source=data_source,
                pick_type=pick_type, score=score, zone=zone, emotion=emotion,
                executed_at=datetime.now(),
            )
            session.add(trade)
            session.commit()
            logger.info(f"[feedback] BUY {code} {name} @{price}x{shares}")
            return True
        except Exception as e:
            logger.warning(f"[feedback] record_buy failed: {e}")
            session.rollback()
            return False
        finally:
            session.close()

    def record_sell(self, code: str, price: float,
                    pnl: float, strategy_tag: str) -> bool:
        """记录一笔卖出，并关联历史买入"""
        session = get_session()
        try:
            # 找到对应持仓
            from models import Position
            pos = session.query(Position).filter(
                Position.code == code, Position.direction == "BUY"
            ).first()
            if pos:
                pos.direction = "SELL"
                pos.closed_at = datetime.now()
                pos.pnl = pnl

            trade = TradeRecord(
                code=code, name="", direction="SELL",
                price=price, shares=0, amount=0,
                strategy_tag=strategy_tag,
                pnl=pnl,
                executed_at=datetime.now(),
            )
            session.add(trade)
            session.commit()
            logger.info(f"[feedback] SELL {code} pnl={pnl:+.2f}")
            return True
        except Exception as e:
            logger.warning(f"[feedback] record_sell failed: {e}")
            session.rollback()
            return False
        finally:
            session.close()


# ════════════════════════════════════════════════════════════════════════════════
# 统计收集器
# ════════════════════════════════════════════════════════════════════════════════

class StatCollector:
    """
    从数据库聚合统计数据。
    每日收盘后调用。
    """

    def get_strategy_stats(self) -> Dict[str, dict]:
        """各策略胜率/盈亏统计"""
        session = get_session()
        try:
            rows = session.execute(text("""
                SELECT
                    strategy_tag,
                    direction,
                    COUNT(*) as cnt,
                    AVG(pnl) as avg_pnl,
                    SUM(pnl) as total_pnl,
                    AVG(score) as avg_score
                FROM trade_records
                WHERE strategy_tag IS NOT NULL AND strategy_tag != ''
                GROUP BY strategy_tag, direction
            """)).fetchall()

            stats = defaultdict(dict)
            for r in rows:
                tag = r[0] or "unknown"
                direction = r[1] or "BUY"
                stats[tag][direction] = {
                    "count": r[2] or 0,
                    "avg_pnl": round(float(r[3] or 0), 2),
                    "total_pnl": round(float(r[4] or 0), 2),
                    "avg_score": round(float(r[5] or 0), 1),
                }
            return dict(stats)
        finally:
            session.close()

    def get_data_source_stats(self) -> Dict[str, DataSourceStats]:
        """各数据源成功率"""
        session = get_session()
        try:
            rows = session.execute(text("""
                SELECT
                    data_source,
                    COUNT(*) as total,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins
                FROM trade_records
                WHERE direction = 'SELL' AND data_source IS NOT NULL
                GROUP BY data_source
            """)).fetchall()

            stats = {}
            for r in rows:
                ds = r[0] or "unknown"
                total = r[1] or 0
                wins = r[2] or 0
                stats[ds] = DataSourceStats(
                    name=ds,
                    total_requests=total,
                    failed_requests=total - wins,
                    signal_succeeded=wins,
                )
            return stats
        finally:
            session.close()

    def get_win_rate(self) -> float:
        """总胜率"""
        session = get_session()
        try:
            row = session.execute(text("""
                SELECT COUNT(*), SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END)
                FROM trade_records WHERE direction = 'SELL'
            """)).fetchone()
            if row and row[0] and row[0] > 0:
                return (row[1] or 0) / row[0]
            return 0.0
        finally:
            session.close()


# ════════════════════════════════════════════════════════════════════════════════
# 反馈评估器
# ════════════════════════════════════════════════════════════════════════════════

class FeedbackEvaluator:
    """
    评估反馈数据，决定是否触发策略调整。
    """

    WIN_RATE_THRESHOLD = 0.50    # 胜率低于此值触发警告
    DATA_SOURCE_SUCCESS_THRESHOLD = 0.60  # 数据源成功率低于此值触发切换

    def __init__(self):
        self.recorder = TradeRecorder()
        self.collector = StatCollector()

    def daily_evaluate(self) -> dict:
        """
        每日收盘后评估。
        返回：{
            "win_rate": float,
            "strategy_stats": dict,
            "data_source_stats": dict,
            "adjustments": [str],
        }
        """
        win_rate = self.collector.get_win_rate()
        strategy_stats = self.collector.get_strategy_stats()
        ds_stats = self.collector.get_data_source_stats()

        adjustments = []

        # 胜率评估
        if win_rate < self.WIN_RATE_THRESHOLD:
            adjustments.append(f"⚠️ 胜率{win_rate:.1%}<{self.WIN_RATE_THRESHOLD:.0%}，建议检查策略")
            logger.warning(f"[feedback] 胜率过低: {win_rate:.1%}")

        # 数据源评估
        for ds_name, stat in ds_stats.items():
            if stat.total_requests >= 5 and stat.success_rate < self.DATA_SOURCE_SUCCESS_THRESHOLD:
                adjustments.append(f"⚠️ {ds_name}成功率{stat.success_rate:.1%}，建议降级")
                logger.warning(f"[feedback] 数据源{ds_name}成功率过低: {stat.success_rate:.1%}")

        return {
            "evaluated_at": datetime.now().isoformat(),
            "win_rate": round(win_rate, 4),
            "strategy_stats": strategy_stats,
            "data_source_stats": {
                k: {"total": v.total_requests, "wins": v.signal_succeeded,
                    "success_rate": round(v.success_rate, 3)}
                for k, v in ds_stats.items()
            },
            "adjustments": adjustments,
        }

    def should_switch_data_source(self) -> Optional[str]:
        """返回需要切换的数据源名称，None表示无需切换"""
        ds_stats = self.collector.get_data_source_stats()
        for ds_name, stat in ds_stats.items():
            if stat.total_requests >= 10 and stat.success_rate < self.DATA_SOURCE_SUCCESS_THRESHOLD:
                return ds_name
        return None
