"""
DragonFlow 增强型 HTTP 客户端
═══════════════════════════════════════════════════════════════════════════════════════
基于 curl_cffi（JA3指纹模拟） + tenacity（指数退避重试）
═══════════════════════════════════════════════════════════════════════════════════════

curl_cffi 优势：
  - 模拟 Chrome120/Edge 的 TLS 握手指纹
  - 绕过基于 JA3 的反爬检测
  - API 与 requests 完全一致

tenacity 优势：
  - 指数退避：1s → 2s → 4s → 8s
  - 自动处理限流/临时失败
  - 降低 VPS IP 被标记的概率

Cloudflare Worker 端点（需部署后替换 YOUR_WORKER_SUBDOMAIN）：
  - CF Worker URL: https://dragonflow-proxy.你的workers.dev/eastmoney/clist
  - 本地开发: http://localhost:8788/eastmoney/clist
"""

from __future__ import annotations

import logging
from typing import Optional

from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)
from curl_cffi import requests as curl_requests
from curl_cffi.requests import Session as CurlSession

logger = logging.getLogger("feeds.curl_client")

# ════════════════════════════════════════════════════════════════════════════════
# Cloudflare Worker 端点配置
# ════════════════════════════════════════════════════════════════════════════════

# ⚠️ 部署 Cloudflare Worker 后，替换为你的 worker URL
CF_WORKER_BASE = "https://dragonflow-proxy.workers.dev"  # ← 部署后替换

# 本地开发调试（wrangler dev 运行时）
LOCAL_DEV_MODE = False
LOCAL_DEV_BASE = "http://localhost:8788"

# ════════════════════════════════════════════════════════════════════════════════
# curl_cffi 会话管理
# ════════════════════════════════════════════════════════════════════════════════

# 全局共享 Session（复用 TCP 连接，提升性能）
_global_session: Optional[CurlSession] = None


def get_session(impersonate: str = "chrome120") -> CurlSession:
    """获取共享的 curl_cffi Session"""
    global _global_session
    if _global_session is None:
        _global_session = CurlSession(impersonate=impersonate)
    return _global_session


# ════════════════════════════════════════════════════════════════════════════════
# 异常定义
# ════════════════════════════════════════════════════════════════════════════════

class UpstreamError(Exception):
    """上游服务错误（超时/403/502/限流）"""
    pass


class AllRetriesFailed(UpstreamError):
    """所有重试次数用尽后仍然失败"""
    pass


# ════════════════════════════════════════════════════════════════════════════════
# 重试配置
# ════════════════════════════════════════════════════════════════════════════════

RETRY_CONFIG = {
    "stop": stop_after_attempt(4),                # 最多4次
    "wait": wait_exponential(multiplier=1, min=1, max=16),  # 指数退避 1→2→4→8s
    "retry": retry_if_exception_type((TimeoutError, UpstreamError, OSError)),
    "before_sleep": lambda retry_state: logger.warning(
        f"[curl] 重试 {retry_state.attempt_number}/4，"
        f"等待{retry_state.next_action.sleep:.1f}s，错误: {retry_state.outcome.exception()}"
    ),
}


def _build_retry_decorator():
    from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
    return retry(
        stop=stop_after_attempt(4),
        wait=wait_exponential(multiplier=1, min=1, max=16),
        retry=retry_if_exception_type((TimeoutError, UpstreamError, OSError)),
        before_sleep=lambda rs: logger.warning(
            f"[curl] 重试 {rs.attempt_number}/4，wait={rs.next_action.sleep:.1f}s"
            f" | err: {str(rs.outcome.exception())[:80]}"
        ),
        reraise=True,
    )


# ════════════════════════════════════════════════════════════════════════════════
# 核心请求函数
# ════════════════════════════════════════════════════════════════════════════════

def _get_base_url() -> str:
    if LOCAL_DEV_MODE:
        return LOCAL_DEV_BASE
    return CF_WORKER_BASE


def get(url: str, params: dict = None, timeout: float = 8.0,
        headers: dict = None, impersonate: str = "chrome120") -> str:
    """
    GET 请求（自动重试 + CF Worker 路由）

    url: 完整URL，或相对路径（如 "/eastmoney/clist?fid=f3"）
    """
    # 相对路径 → 拼接 CF Worker base
    if url.startswith("/"):
        base = _get_base_url()
        url = base + url

    extra_headers = headers or {}

    @_build_retry_decorator()
    def _do_get():
        try:
            session = get_session(impersonate=impersonate)
            resp = session.get(
                url,
                params=params,
                headers=extra_headers,
                timeout=timeout,
                verify=True,
            )
            if resp.status_code == 403:
                raise UpstreamError(f"403 Forbidden: {url}")
            if resp.status_code == 502:
                raise UpstreamError(f"502 Bad Gateway: {url}")
            if resp.status_code >= 500:
                raise UpstreamError(f"HTTP {resp.status_code}: {url}")
            return resp.text
        except TimeoutError:
            raise
        except (UpstreamError, OSError):
            raise
        except Exception as e:
            # tenacity 不捕获其他异常，所以这里转成 UpstreamError
            raise UpstreamError(str(e)) from e

    return _do_get()


def post(url: str, data: dict = None, json: dict = None,
         timeout: float = 8.0, headers: dict = None,
         impersonate: str = "chrome120") -> str:
    """POST 请求（自动重试）"""
    if url.startswith("/"):
        base = _get_base_url()
        url = base + url

    extra_headers = headers or {}

    @_build_retry_decorator()
    def _do_post():
        try:
            session = get_session(impersonate=impersonate)
            resp = session.post(
                url,
                data=data,
                json=json,
                headers=extra_headers,
                timeout=timeout,
                verify=True,
            )
            if resp.status_code >= 400:
                raise UpstreamError(f"HTTP {resp.status_code}")
            return resp.text
        except (TimeoutError, UpstreamError, OSError):
            raise
        except Exception as e:
            raise UpstreamError(str(e)) from e

    return _do_post()


# ════════════════════════════════════════════════════════════════════════════════
# 快捷封装（东财/新浪/腾讯 专用）
# ════════════════════════════════════════════════════════════════════════════════

def eastmoney_clist(params: dict, timeout: float = 8.0) -> str:
    """东财涨幅列表（通过 CF Worker）"""
    return get("/eastmoney/clist", params=params, timeout=timeout)


def eastmoney_ulist(params: dict, timeout: float = 8.0) -> str:
    """东财指数行情（通过 CF Worker）"""
    return get("/eastmoney/ulist", params=params, timeout=timeout)


def sina_vip(path: str = "/Market_Center.getHQNodeData", params: dict = None,
             timeout: float = 8.0) -> str:
    """新浪VIP行情（通过 CF Worker）"""
    q = params or {}
    url = f"/sina/vip{path}"
    return get(url, params=q, timeout=timeout)


def sina_hq(codes: str, timeout: float = 5.0) -> str:
    """新浪实时行情hq.sinajs.cn（通过 CF Worker）"""
    return get(f"/sina/hq?list={codes}", timeout=timeout)


def tencent_quote(codes: str, timeout: float = 5.0) -> str:
    """腾讯行情 qt.gtimg.cn（通过 CF Worker）"""
    return get(f"/tencent/quote?list={codes}", timeout=timeout)


def datacenter_em(params: dict, timeout: float = 8.0) -> str:
    """东财数据中心（通过 CF Worker）"""
    return get("/datacenter/em", params=params, timeout=timeout)
