"""
复合快照聚合
═══════════════════════════════════════════════════════════════════════════
将 sina_realtime + akshare_data 聚合为统一快照，供策略/报告/Dashboard使用。

三级快照：
  - realtime_snapshot: 3秒级（仅新浪API，用于盘中tick）
  - analysis_snapshot: 分钟级（新浪+akshare核心数据，用于监控决策）
  - full_snapshot:     15分钟级（全量数据，用于报告生成）
"""
from __future__ import annotations

import datetime
from concurrent.futures import ThreadPoolExecutor
from typing import Dict

from loguru import logger

from feeds.resilient import resilient_fetch_indices, resilient_fetch_stocks
from feeds.akshare_data import (
    get_zt_stats, get_market_breadth, get_sector_flow,
    get_main_net_flow, get_north_flow, get_financial_news,
    get_lhb, enrich_stock_data,
)


def build_realtime_snapshot() -> Dict:
    """
    3秒级实时快照（仅新浪API，极低延迟）
    用于 AutoPilot tick 循环
    """
    try:
        indices = resilient_fetch_indices()
    except Exception:
        indices = []

    return {
        "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "sina_realtime",
        "indices": indices,
    }


def build_analysis_snapshot() -> Dict:
    """
    分钟级分析快照（新浪 + akshare 核心数据）
    用于盘中策略决策
    """
    try:
        indices = resilient_fetch_indices()
    except Exception:
        indices = []

    with ThreadPoolExecutor(max_workers=4) as pool:
        zt_future = pool.submit(get_zt_stats)
        breadth_future = pool.submit(get_market_breadth)
        sector_future = pool.submit(get_sector_flow)
        _TIMEOUT_SEC = 8.0  # 防止线程阻塞导致API超时

        try:
            zt_stats = zt_future.result(timeout=_TIMEOUT_SEC)
        except Exception:
            zt_stats = {}
        try:
            breadth = breadth_future.result(timeout=_TIMEOUT_SEC)
        except Exception:
            breadth = {}
        try:
            sector_flow = sector_future.result(timeout=_TIMEOUT_SEC)
        except Exception:
            sector_flow = []
        main_flow = round(sum(item.get("net_flow", 0) for item in sector_flow) / 1e8, 2) if sector_flow else 0.0

    return {
        "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "analysis",
        "indices": indices,
        "zt_stats": zt_stats,
        "breadth": breadth,
        "main_flow_100m": main_flow,
        "sector_flow_top5": sector_flow[:5],
    }


def build_full_snapshot() -> Dict:
    """
    15分钟级完整快照（全量数据）
    用于报告生成和收盘分析
    """
    try:
        indices = resilient_fetch_indices()
    except Exception:
        indices = []

    with ThreadPoolExecutor(max_workers=6) as pool:
        zt_future = pool.submit(get_zt_stats)
        breadth_future = pool.submit(get_market_breadth)
        sector_future = pool.submit(get_sector_flow)
        north_future = pool.submit(get_north_flow)
        news_future = pool.submit(get_financial_news, 10)
        zt_stats = zt_future.result()
        breadth = breadth_future.result()
        sectors = sector_future.result()
        north = north_future.result()
        news = news_future.result()
        main_flow = round(sum(item.get("net_flow", 0) for item in sectors) / 1e8, 2) if sectors else 0.0

    lhb_df = get_lhb()
    lhb_list = lhb_df.to_dict(orient="records") if not lhb_df.empty else []

    return {
        "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "full",
        "indices": indices,
        "zt_stats": zt_stats,
        "breadth": breadth,
        "main_flow_100m": main_flow,
        "north_flow_100m": north,
        "sector_flow": sectors,
        "lhb": lhb_list,
        "news": news,
    }


def build_market_env_data() -> Dict:
    """
    提取策略 zone_classifier 所需的全部市场环境数据
    返回可直接传入 classify_zone() 的参数
    """
    with ThreadPoolExecutor(max_workers=3) as pool:
        zt_future = pool.submit(get_zt_stats)
        breadth_future = pool.submit(get_market_breadth)
        sector_future = pool.submit(get_sector_flow)
        zt_stats = zt_future.result()
        breadth = breadth_future.result()
        sectors = sector_future.result()
        main_flow = round(sum(item.get("net_flow", 0) for item in sectors) / 1e8, 2) if sectors else 0.0

    return {
        "highest_board": zt_stats.get("highest_board", 0),
        "limit_up_count": zt_stats.get("zt_count", 0),
        "broken_rate": zt_stats.get("broken_rate", 0.5),
        "up_down_ratio": breadth.get("up_down_ratio", 1.0),
        "main_flow_100m": main_flow,
    }
