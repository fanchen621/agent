"""
弹性数据层：自动故障转移 + 反限流
═══════════════════════════════════════════════════════════════════════════
多数据源链（新浪/腾讯/东方财富/网易），自动切换：
  - 健康分数管理（连续成功+1，失败-5）
  - 限流检测（403/429/空返回）→ 指数退避
  - UA轮换 + Referer伪装
  - 降级通知

替代 sina_realtime.py 作为主要数据获取入口。
"""
from __future__ import annotations

import json
import random
import time
import urllib.request
import urllib.error
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional, Callable, Tuple

from loguru import logger

from config import DATA_SOURCE_CONFIG
from feeds.proxy_engine import proxied_get, ensure_pool_ready

# ─── 数据源健康管理 ──────────────────────────────────────────────────────────

class SourceHealth:
    def __init__(self, name: str, init_score: int = 10):
        self.name = name
        self.score = init_score
        self.consecutive_fails = 0
        self.last_fail_time = 0.0
        self.last_success_time = 0.0
        self.total_calls = 0
        self.total_fails = 0
        self.backoff_until = 0.0    # 退避截止时间
        self.current_interval = DATA_SOURCE_CONFIG["base_interval"]

    def record_success(self):
        self.score = min(self.score + DATA_SOURCE_CONFIG["health_reward"], 20)
        self.consecutive_fails = 0
        self.last_success_time = time.time()
        self.total_calls += 1
        self.current_interval = DATA_SOURCE_CONFIG["base_interval"]

    def record_failure(self, is_rate_limit: bool = False):
        self.score += DATA_SOURCE_CONFIG["health_penalty"]
        self.consecutive_fails += 1
        self.last_fail_time = time.time()
        self.total_calls += 1
        self.total_fails += 1
        if is_rate_limit:
            backoff = min(
                self.current_interval * DATA_SOURCE_CONFIG["backoff_factor"],
                DATA_SOURCE_CONFIG["max_backoff"])
            self.current_interval = backoff
            self.backoff_until = time.time() + backoff
            logger.warning(f"[弹性] {self.name} 被限流，退避{backoff:.0f}秒")

    @property
    def is_available(self) -> bool:
        if time.time() < self.backoff_until:
            return False
        return self.score >= DATA_SOURCE_CONFIG["health_min_to_use"]

    @property
    def error_rate(self) -> float:
        return self.total_fails / self.total_calls if self.total_calls > 0 else 0

    def to_dict(self) -> dict:
        return {
            "name": self.name, "score": self.score,
            "available": self.is_available,
            "consecutive_fails": self.consecutive_fails,
            "error_rate": round(self.error_rate, 3),
            "backoff_until": self.backoff_until,
        }


# ─── 全局健康状态 ─────────────────────────────────────────────────────────────

_source_health: Dict[str, SourceHealth] = {}
_active_index_source = "tencent"  # 腾讯直连 0.057s，最快
_active_stock_source = "sina"       # 新浪走SOCKS5代理，数据最全


def get_source_health(name: str) -> SourceHealth:
    if name not in _source_health:
        _source_health[name] = SourceHealth(name, DATA_SOURCE_CONFIG["health_score_init"])
    return _source_health[name]


def get_all_source_status() -> List[dict]:
    return [h.to_dict() for h in _source_health.values()]


# ─── HTTP 请求工具 ────────────────────────────────────────────────────────────

def _get_ua() -> str:
    return random.choice(DATA_SOURCE_CONFIG["user_agents"])


def _http_get(url: str, referer: str = "", encoding: str = "utf-8",
              timeout: float = 3.0) -> str:
    """通用HTTP GET — 全部走代理引擎（解决腾讯云IP封禁）"""
    return proxied_get(url, referer=referer, encoding=encoding, timeout=timeout)


def _is_rate_limited(error) -> bool:
    """判断是否被限流"""
    if isinstance(error, urllib.error.HTTPError):
        return error.code in (403, 429, 503)
    return False


# ════════════════════════════════════════════════════════════════════════════
# 指数数据源实现
# ════════════════════════════════════════════════════════════════════════════

def _fetch_indices_sina() -> List[Dict]:
    """新浪指数"""
    text = _http_get(
        "https://hq.sinajs.cn/list=sh000001,sz399001,sz399006",
        referer="https://finance.sina.com.cn", encoding="gbk")
    return _parse_sina_index_text(text)


def _fetch_indices_tencent() -> List[Dict]:
    """腾讯指数"""
    text = _http_get(
        "https://qt.gtimg.cn/q=sh000001,sz399001,sz399006",
        referer="https://finance.qq.com", encoding="gbk")
    return _parse_tencent_index_text(text)


def _fetch_indices_eastmoney() -> List[Dict]:
    """东方财富指数"""
    url = ("https://push2.eastmoney.com/api/qt/ulist.np/get?"
           "fields=f1,f2,f3,f4,f12,f14&secids=1.000001,0.399001,0.399006")
    text = _http_get(url, referer="https://www.eastmoney.com")
    return _parse_eastmoney_index_json(text)


def _fetch_indices_netease() -> List[Dict]:
    """网易指数"""
    text = _http_get(
        "https://api.money.126.net/data/feed/0000001,1399001,1399006",
        referer="https://money.163.com")
    return _parse_netease_index_json(text)


# ─── 指数解析器 ───────────────────────────────────────────────────────────────

INDEX_NAMES = {"sh000001": "上证指数", "sz399001": "深证成指", "sz399006": "创业板指"}


def _parse_sina_index_text(text: str) -> List[Dict]:
    out = []
    for ln in text.strip().splitlines():
        if "=" not in ln:
            continue
        try:
            left, right = ln.split("=", 1)
            code = left.strip().split("_")[-1]
            parts = right.strip().strip(";").strip('"').split(",")
            if len(parts) < 6:
                continue
            prev = float(parts[2] or 0)
            last = float(parts[3] or 0)
            pct = ((last - prev) / prev * 100) if prev else 0
            out.append({"code": code, "name": parts[0] or INDEX_NAMES.get(code, code),
                        "last": round(last, 3), "prev_close": round(prev, 3),
                        "pct": round(pct, 3)})
        except Exception:
            continue
    return out


def _parse_tencent_index_text(text: str) -> List[Dict]:
    code_map = {"sh000001": "sh000001", "sz399001": "sz399001", "sz399006": "sz399006"}
    out = []
    for ln in text.strip().splitlines():
        if "=" not in ln:
            continue
        try:
            left, right = ln.split("=", 1)
            parts = right.strip().strip(";").strip('"').split("~")
            if len(parts) < 45:
                continue
            name = parts[1]
            code_raw = parts[2]
            last = float(parts[3] or 0)
            prev = float(parts[4] or 0)
            pct = float(parts[32] or 0)
            code = f"sh{code_raw}" if code_raw.startswith("0") and len(code_raw) == 6 else f"sz{code_raw}"
            # 腾讯格式特殊处理
            if "000001" in left:
                code = "sh000001"
            elif "399001" in left:
                code = "sz399001"
            elif "399006" in left:
                code = "sz399006"
            out.append({"code": code, "name": name,
                        "last": round(last, 3), "prev_close": round(prev, 3),
                        "pct": round(pct, 3)})
        except Exception:
            continue
    return out


def _parse_eastmoney_index_json(text: str) -> List[Dict]:
    code_map = {"000001": "sh000001", "399001": "sz399001", "399006": "sz399006"}
    out = []
    try:
        data = json.loads(text)
        for item in (data.get("data", {}).get("diff", []) or []):
            code_raw = str(item.get("f12", ""))
            code = code_map.get(code_raw, code_raw)
            name = item.get("f14", INDEX_NAMES.get(code, code))
            last = float(item.get("f2", 0)) / 100 if item.get("f2") else 0
            pct = float(item.get("f3", 0)) / 100 if item.get("f3") else 0
            if last > 100:  # 东方财富有时返回未除100的值
                pass
            out.append({"code": code, "name": name,
                        "last": round(last, 3), "pct": round(pct, 3),
                        "prev_close": 0})
    except Exception:
        pass
    return out


def _parse_netease_index_json(text: str) -> List[Dict]:
    code_map = {"0000001": "sh000001", "1399001": "sz399001", "1399006": "sz399006"}
    out = []
    try:
        # 网易返回 _ntes_quote_callback({...});
        text = text.strip()
        if text.startswith("_ntes_quote_callback"):
            text = text[text.index("(") + 1:text.rindex(")")]
        data = json.loads(text)
        for key, item in data.items():
            code = code_map.get(key, key)
            name = item.get("name", INDEX_NAMES.get(code, ""))
            last = float(item.get("price", 0))
            prev = float(item.get("yestclose", 0))
            pct = float(item.get("percent", 0)) * 100
            out.append({"code": code, "name": name,
                        "last": round(last, 3), "prev_close": round(prev, 3),
                        "pct": round(pct, 3)})
    except Exception:
        pass
    return out


# ════════════════════════════════════════════════════════════════════════════
# 个股数据源实现
# ════════════════════════════════════════════════════════════════════════════

def _to_sina_code(code: str) -> str:
    code = code.strip().replace("sh", "").replace("sz", "")
    if code.startswith("6"):
        return f"sh{code}"
    return f"sz{code}"


def _fetch_stocks_sina(codes: List[str]) -> Dict[str, Dict]:
    sina_codes = [_to_sina_code(c) for c in codes]
    result = {}
    for i in range(0, len(sina_codes), 40):
        batch = sina_codes[i:i + 40]
        text = _http_get(
            f"https://hq.sinajs.cn/list={','.join(batch)}",
            referer="https://finance.sina.com.cn", encoding="gbk")
        for ln in text.strip().splitlines():
            if "=" not in ln:
                continue
            try:
                left, right = ln.split("=", 1)
                code_raw = left.strip().split("_")[-1]
                parts = right.strip().strip(";").strip('"').split(",")
                if len(parts) < 32:
                    continue
                code = code_raw.replace("sh", "").replace("sz", "")
                prev = float(parts[2] or 0)
                last = float(parts[3] or 0)
                if last <= 0:
                    continue
                pct = (last - prev) / prev * 100 if prev else 0
                result[code] = {
                    "code": code, "name": parts[0],
                    "price": round(last, 2), "prev_close": round(prev, 2),
                    "change_pct": round(pct, 2),
                    "volume": float(parts[8] or 0),
                    "amount": float(parts[9] or 0),
                    "amount_100m": round(float(parts[9] or 0) / 1e8, 2),
                }
            except Exception:
                continue
    return result


def _fetch_stocks_eastmoney(codes: List[str]) -> Dict[str, Dict]:
    secids = []
    for c in codes:
        c = c.strip().replace("sh", "").replace("sz", "")
        if c.startswith("6"):
            secids.append(f"1.{c}")
        else:
            secids.append(f"0.{c}")
    url = ("https://push2.eastmoney.com/api/qt/ulist.np/get?"
           f"fields=f1,f2,f3,f4,f5,f6,f12,f14&secids={','.join(secids[:50])}")
    text = _http_get(url, referer="https://www.eastmoney.com")
    result = {}
    try:
        data = json.loads(text)
        for item in (data.get("data", {}).get("diff", []) or []):
            code = str(item.get("f12", ""))
            name = item.get("f14", "")
            last = float(item.get("f2", 0))
            pct = float(item.get("f3", 0))
            vol = float(item.get("f5", 0))
            amt = float(item.get("f6", 0))
            if last <= 0:
                continue
            # 东方财富push2有时数值需要/100
            if last > 200 or abs(pct) > 30:
                last /= 100
                pct /= 100
            result[code] = {
                "code": code, "name": name,
                "price": round(last, 2), "change_pct": round(pct, 2),
                "volume": vol, "amount": amt,
                "amount_100m": round(amt / 1e8, 2) if amt > 1e6 else round(amt, 2),
            }
    except Exception:
        pass
    return result


async def _fetch_stocks_tencent_async(codes: List[str]) -> Dict[str, Dict]:
    """腾讯直连异步并发获取（aiohttp，零线程开销，<1秒扫全市场）"""
    import aiohttp
    qq_codes = []
    for c in codes:
        c = c.strip().replace("sh", "").replace("sz", "")
        qq_codes.append(f"sh{c}" if c.startswith("6") else f"sz{c}")

    BATCH = 100  # 每个请求100只股票
    SEMAPHORE_LIMIT = 100
    sem = asyncio.Semaphore(SEMAPHORE_LIMIT)

    async def _fetch_batch(session: aiohttp.ClientSession, batch: List[str]) -> List[Tuple[str, Dict]]:
        async with sem:
            url = f"https://qt.gtimg.cn/q={','.join(batch)}"
            try:
                async with session.get(url, headers={"Referer": "https://finance.qq.com", "User-Agent": "Mozilla/5.0"}, timeout=aiohttp.ClientTimeout(total=2.0)) as resp:
                    text = await resp.text(encoding="gbk")
                    results = []
                    for ln in text.strip().splitlines():
                        if "=" not in ln:
                            continue
                        try:
                            parts = ln.split("=", 1)[1].strip().strip(";").strip('"').split("~")
                            if len(parts) < 45:
                                continue
                            code = parts[2]
                            last = float(parts[3] or 0)
                            if last <= 0:
                                continue
                            results.append((code, {
                                "code": code, "name": parts[1],
                                "price": round(last, 2),
                                "prev_close": round(float(parts[4] or 0), 2),
                                "change_pct": round(float(parts[32] or 0), 2),
                                "volume": float(parts[36] or 0),
                                "amount": float(parts[37] or 0),
                                "amount_100m": round(float(parts[37] or 0) / 1e8, 2) if float(parts[37] or 0) > 1e6 else round(float(parts[37] or 0), 2),
                            }))
                        except Exception:
                            continue
                    return results
            except Exception:
                return []

    batches = [qq_codes[i:i + BATCH] for i in range(0, len(qq_codes), BATCH)]
    conn = aiohttp.TCPConnector(limit=100, ttl_dns_cache=300)
    async with aiohttp.ClientSession(connector=conn) as session:
        tasks = [_fetch_batch(session, batch) for batch in batches]
        batch_results = await asyncio.gather(*tasks)

    result = {}
    for batch in batch_results:
        for code, data in batch:
            result[code] = data
    return result


def _fetch_stocks_tencent(codes: List[str]) -> Dict[str, Dict]:
    """同步包装，兼容现有调用链"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop.run_until_complete(_fetch_stocks_tencent_async(codes))
    except RuntimeError:
        return asyncio.run(_fetch_stocks_tencent_async(codes))


# ════════════════════════════════════════════════════════════════════════════
# 弹性获取核心（自动故障转移）
# ════════════════════════════════════════════════════════════════════════════

_INDEX_FETCHERS: Dict[str, Callable] = {
    "sina": _fetch_indices_sina,
    "tencent": _fetch_indices_tencent,
    "eastmoney": _fetch_indices_eastmoney,
    "netease": _fetch_indices_netease,
}

_STOCK_FETCHERS: Dict[str, Callable] = {
    "sina": _fetch_stocks_sina,
    "eastmoney": _fetch_stocks_eastmoney,
    "tencent": _fetch_stocks_tencent,
}

_last_good_indices: List[Dict] = []
_last_good_stocks: Dict[str, Dict] = {}
_index_gap_cache: Dict[str, Tuple[float, float]] = {}
_stock_gap_cache: Dict[str, Tuple[float, float]] = {}
_latest_data_quality: Dict[str, Dict[str, object]] = {
    "index": {
        "source": _active_index_source,
        "compared_to": "",
        "updated_at": "",
        "validated_at": "",
        "count": 0,
        "validated_count": 0,
        "avg_confidence": 0.0,
        "min_confidence": 0.0,
        "max_gap_pct": None,
    },
    "stock": {
        "source": _active_stock_source,
        "compared_to": "",
        "updated_at": "",
        "validated_at": "",
        "count": 0,
        "validated_count": 0,
        "avg_confidence": 0.0,
        "min_confidence": 0.0,
        "max_gap_pct": None,
    },
}


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _safe_float(value, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _iso_time(ts: float) -> str:
    if ts <= 0:
        return ""
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


def _health_confidence(health: SourceHealth) -> float:
    base = 0.46 + (_clamp(float(health.score), 0.0, 20.0) / 50.0)
    penalty = _clamp(health.error_rate * 0.28, 0.0, 0.28)
    return round(_clamp(base - penalty, 0.15, 0.9), 3)


def _gap_adjusted_confidence(base_confidence: float, gap_pct: Optional[float]) -> float:
    if gap_pct is None:
        return round(_clamp(base_confidence - 0.02, 0.1, 0.92), 3)
    if gap_pct <= 0.15:
        base_confidence += 0.12
    elif gap_pct <= 0.4:
        base_confidence += 0.08
    elif gap_pct <= 0.8:
        base_confidence += 0.03
    elif gap_pct <= 1.5:
        base_confidence -= 0.08
    elif gap_pct <= DATA_SOURCE_CONFIG["consensus_critical_gap_pct"]:
        base_confidence -= 0.18
    else:
        base_confidence -= 0.32
    return round(_clamp(base_confidence, 0.05, 0.98), 3)


def _price_gap_pct(left: float, right: float) -> Optional[float]:
    left_val = _safe_float(left)
    right_val = _safe_float(right)
    if left_val <= 0 or right_val <= 0:
        return None
    midpoint = (left_val + right_val) / 2.0
    if midpoint <= 0:
        return None
    return round(abs(left_val - right_val) / midpoint * 100.0, 3)


def _get_recent_gap(cache: Dict[str, Tuple[float, float]], code: str) -> Optional[float]:
    item = cache.get(code)
    if not item:
        return None
    ts, gap = item
    if time.time() - ts > DATA_SOURCE_CONFIG["validation_ttl"] * 2:
        return None
    return gap


def _compare_index_rows(primary_rows: List[Dict], backup_rows: List[Dict]) -> Dict[str, float]:
    backup_map = {str(row.get("code", "")): row for row in backup_rows}
    gap_map: Dict[str, float] = {}
    for row in primary_rows:
        code = str(row.get("code", ""))
        gap = _price_gap_pct(row.get("last", 0.0), backup_map.get(code, {}).get("last", 0.0))
        if gap is not None:
            gap_map[code] = gap
            _index_gap_cache[code] = (time.time(), gap)
    return gap_map


def _compare_stock_rows(primary_rows: Dict[str, Dict], backup_rows: Dict[str, Dict]) -> Dict[str, float]:
    gap_map: Dict[str, float] = {}
    for code, row in primary_rows.items():
        gap = _price_gap_pct(row.get("price", 0.0), backup_rows.get(code, {}).get("price", 0.0))
        if gap is not None:
            gap_map[code] = gap
            _stock_gap_cache[str(code)] = (time.time(), gap)
    return gap_map


def _refresh_index_runtime_meta(rows: List[Dict]) -> List[Dict]:
    now = time.time()
    refreshed: List[Dict] = []
    for row in rows:
        item = dict(row)
        fetched_at = _safe_float(item.get("fetched_at", now), now)
        item["quote_age_sec"] = round(max(0.0, now - fetched_at), 2)
        refreshed.append(item)
    return refreshed


def _refresh_stock_runtime_meta(rows: Dict[str, Dict]) -> Dict[str, Dict]:
    now = time.time()
    refreshed: Dict[str, Dict] = {}
    for code, row in rows.items():
        item = dict(row)
        fetched_at = _safe_float(item.get("fetched_at", now), now)
        item["quote_age_sec"] = round(max(0.0, now - fetched_at), 2)
        refreshed[str(code)] = item
    return refreshed


def _update_quality_summary(
    kind: str,
    source_name: str,
    compared_to: str,
    confidences: List[float],
    gaps: List[float],
) -> None:
    now = time.time()
    summary = _latest_data_quality[kind]
    summary["source"] = source_name
    summary["compared_to"] = compared_to
    summary["updated_at"] = _iso_time(now)
    if gaps:
        summary["validated_at"] = _iso_time(now)
    summary["count"] = len(confidences)
    summary["validated_count"] = len(gaps)
    summary["avg_confidence"] = round(sum(confidences) / len(confidences), 3) if confidences else 0.0
    summary["min_confidence"] = round(min(confidences), 3) if confidences else 0.0
    summary["max_gap_pct"] = round(max(gaps), 3) if gaps else None


def get_latest_data_quality() -> Dict[str, Dict[str, object]]:
    return {
        "index": dict(_latest_data_quality["index"]),
        "stock": dict(_latest_data_quality["stock"]),
    }


def _annotate_indices(
    rows: List[Dict],
    source_name: str,
    health: SourceHealth,
    compared_to: str = "",
) -> List[Dict]:
    base_confidence = _health_confidence(health)
    annotated: List[Dict] = []
    confidences: List[float] = []
    gaps: List[float] = []
    now = time.time()
    for row in rows:
        item = dict(row)
        code = str(item.get("code", ""))
        gap = _get_recent_gap(_index_gap_cache, code)
        confidence = _gap_adjusted_confidence(base_confidence, gap)
        item.update({
            "source_name": source_name,
            "source_compared_to": compared_to,
            "data_confidence": confidence,
            "consensus_gap_pct": gap,
            "fetched_at": now,
            "quote_age_sec": 0.0,
        })
        annotated.append(item)
        confidences.append(confidence)
        if gap is not None:
            gaps.append(gap)
    _update_quality_summary("index", source_name, compared_to, confidences, gaps)
    return annotated


def _annotate_stocks(
    rows: Dict[str, Dict],
    source_name: str,
    health: SourceHealth,
    compared_to: str = "",
) -> Dict[str, Dict]:
    base_confidence = _health_confidence(health)
    annotated: Dict[str, Dict] = {}
    confidences: List[float] = []
    gaps: List[float] = []
    now = time.time()
    for code, row in rows.items():
        item = dict(row)
        gap = _get_recent_gap(_stock_gap_cache, str(code))
        confidence = _gap_adjusted_confidence(base_confidence, gap)
        item.update({
            "source_name": source_name,
            "source_compared_to": compared_to,
            "data_confidence": confidence,
            "consensus_gap_pct": gap,
            "fetched_at": now,
            "quote_age_sec": 0.0,
        })
        annotated[str(code)] = item
        confidences.append(confidence)
        if gap is not None:
            gaps.append(gap)
    _update_quality_summary("stock", source_name, compared_to, confidences, gaps)
    return annotated


def _validate_indices(primary_source: str, primary_rows: List[Dict]) -> str:
    last_validation = str(_latest_data_quality["index"].get("validated_at", "") or "")
    if last_validation:
        try:
            last_ts = time.mktime(time.strptime(last_validation, "%Y-%m-%d %H:%M:%S"))
            if time.time() - last_ts < DATA_SOURCE_CONFIG["validation_ttl"]:
                return str(_latest_data_quality["index"].get("compared_to", "") or "")
        except Exception:
            pass

    for backup_source in DATA_SOURCE_CONFIG["index_priority"]:
        if backup_source == primary_source:
            continue
        health = get_source_health(f"index_{backup_source}")
        if not health.is_available:
            continue
        fetcher = _INDEX_FETCHERS.get(backup_source)
        if not fetcher:
            continue
        try:
            time.sleep(health.current_interval)
            backup_rows = fetcher()
            if backup_rows:
                health.record_success()
                _compare_index_rows(primary_rows, backup_rows)
                return backup_source
            health.record_failure()
        except Exception as exc:
            health.record_failure(is_rate_limit=_is_rate_limited(exc))
            logger.debug(f"[弹性] {backup_source}指数验证失败: {exc}")
    return ""


def _validate_stocks(primary_source: str, primary_rows: Dict[str, Dict], codes: List[str]) -> str:
    if not primary_rows or len(codes) > DATA_SOURCE_CONFIG["max_validate_stock_batch"]:
        return ""

    last_validation = str(_latest_data_quality["stock"].get("validated_at", "") or "")
    if last_validation:
        try:
            last_ts = time.mktime(time.strptime(last_validation, "%Y-%m-%d %H:%M:%S"))
            if time.time() - last_ts < DATA_SOURCE_CONFIG["validation_ttl"]:
                return str(_latest_data_quality["stock"].get("compared_to", "") or "")
        except Exception:
            pass

    for backup_source in DATA_SOURCE_CONFIG["stock_priority"]:
        if backup_source == primary_source:
            continue
        health = get_source_health(f"stock_{backup_source}")
        if not health.is_available:
            continue
        fetcher = _STOCK_FETCHERS.get(backup_source)
        if not fetcher:
            continue
        try:
            time.sleep(health.current_interval)
            backup_rows = fetcher(codes)
            if backup_rows:
                health.record_success()
                _compare_stock_rows(primary_rows, backup_rows)
                return backup_source
            health.record_failure()
        except Exception as exc:
            health.record_failure(is_rate_limit=_is_rate_limited(exc))
            logger.debug(f"[弹性] {backup_source}个股验证失败: {exc}")
    return ""


def resilient_fetch_indices() -> List[Dict]:
    """
    弹性获取指数行情，自动在多数据源间切换。
    失败时返回上次成功数据。
    """
    global _last_good_indices, _active_index_source

    priority = DATA_SOURCE_CONFIG["index_priority"]
    for source_name in priority:
        health = get_source_health(f"index_{source_name}")
        if not health.is_available:
            continue

        fetcher = _INDEX_FETCHERS.get(source_name)
        if not fetcher:
            continue

        try:
            time.sleep(health.current_interval)
            result = fetcher()
            if result and len(result) > 0:
                health.record_success()
                compared_to = _validate_indices(source_name, result)
                annotated = _annotate_indices(result, source_name, health, compared_to)
                _last_good_indices = annotated
                if _active_index_source != source_name:
                    logger.info(f"[弹性] 指数源切换: {_active_index_source} -> {source_name}")
                    _active_index_source = source_name
                return _refresh_index_runtime_meta(annotated)
            else:
                health.record_failure()
        except Exception as e:
            rate_limited = _is_rate_limited(e)
            health.record_failure(is_rate_limit=rate_limited)
            logger.debug(f"[弹性] {source_name}指数失败: {e}")

    # 全部失败，返回缓存
    if _last_good_indices:
        logger.warning("[弹性] 所有指数源失败，使用缓存")
        return _refresh_index_runtime_meta(_last_good_indices)
    raise RuntimeError("所有指数数据源不可用")


def resilient_fetch_stocks(codes: List[str]) -> Dict[str, Dict]:
    """弹性获取个股行情"""
    global _last_good_stocks, _active_stock_source

    if not codes:
        return {}

    codes = [str(code).replace("sh", "").replace("sz", "") for code in codes if str(code).strip()]

    priority = DATA_SOURCE_CONFIG["stock_priority"]
    for source_name in priority:
        health = get_source_health(f"stock_{source_name}")
        if not health.is_available:
            continue

        fetcher = _STOCK_FETCHERS.get(source_name)
        if not fetcher:
            continue

        try:
            time.sleep(health.current_interval)
            result = fetcher(codes)
            if result:
                health.record_success()
                compared_to = _validate_stocks(source_name, result, codes)
                annotated = _annotate_stocks(result, source_name, health, compared_to)
                _last_good_stocks.update(annotated)
                if _active_stock_source != source_name:
                    logger.info(f"[弹性] 个股源切换: {_active_stock_source} -> {source_name}")
                    _active_stock_source = source_name
                return _refresh_stock_runtime_meta(annotated)
            else:
                health.record_failure()
        except Exception as e:
            rate_limited = _is_rate_limited(e)
            health.record_failure(is_rate_limit=rate_limited)
            logger.debug(f"[弹性] {source_name}个股失败: {e}")

    # 全部失败返回缓存
    logger.warning("[弹性] 所有个股源失败，使用缓存")
    cached = {c: _last_good_stocks[c] for c in codes if c in _last_good_stocks}
    return _refresh_stock_runtime_meta(cached)


def get_active_sources() -> Dict[str, str]:
    """获取当前活跃数据源"""
    return {"index": _active_index_source, "stock": _active_stock_source}


def reset_all_sources():
    """重置所有数据源健康状态"""
    for h in _source_health.values():
        h.score = DATA_SOURCE_CONFIG["health_score_init"]
        h.consecutive_fails = 0
        h.backoff_until = 0
        h.current_interval = DATA_SOURCE_CONFIG["base_interval"]
    logger.info("[弹性] 所有数据源健康状态已重置")
