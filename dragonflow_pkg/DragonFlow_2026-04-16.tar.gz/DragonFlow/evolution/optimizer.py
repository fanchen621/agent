from __future__ import annotations

import datetime
from collections import Counter
from typing import Any, Dict, List, Optional

from loguru import logger

from config import EVOLUTION_BOUNDS, EVOLUTION_THRESHOLDS, PERFORMANCE_TARGET, RISK_CONTROL, TRADE_RULES
from evolution.smart_optimizer import FactorImportanceTracker, compress_trade_details
from models import (
    DailyReport,
    EvolutionLog,
    MarketSnapshot,
    RiskEvent,
    StrategyStats,
    get_param,
    get_session,
    set_param,
)
from openclaw_adapter import update_state


_factor_tracker: Optional[FactorImportanceTracker] = None


def _count_week_changes(session) -> int:
    today = datetime.date.today()
    week_start = today - datetime.timedelta(days=today.weekday())
    logs = session.query(EvolutionLog).filter(
        EvolutionLog.created_at >= datetime.datetime.combine(week_start, datetime.time.min),
        EvolutionLog.approved == True,
    ).all()
    return sum(1 for log in logs if log.new_params)


def _log_risk_event(session, event_type: str, desc: str, penalty: str):
    session.add(RiskEvent(
        date=datetime.date.today(),
        event_type=event_type,
        description=desc,
        penalty=penalty,
    ))


def _dominant_regime(session, since: datetime.date) -> str:
    reports = session.query(DailyReport).filter(
        DailyReport.report_type == "closing",
        DailyReport.date >= since,
    ).order_by(DailyReport.date.desc()).all()
    counter = Counter(report.zone for report in reports if report.zone)
    if not counter:
        return "range"
    return counter.most_common(1)[0][0]


def _get_factor_tracker() -> FactorImportanceTracker:
    global _factor_tracker
    if _factor_tracker is not None:
        return _factor_tracker

    session = get_session()
    try:
        snapshot = session.query(MarketSnapshot).filter(
            MarketSnapshot.snapshot_type == "adaptive_factor_state",
        ).order_by(MarketSnapshot.timestamp.desc()).first()
        if snapshot and snapshot.data:
            _factor_tracker = FactorImportanceTracker.from_dict(dict(snapshot.data or {}))
            return _factor_tracker
    except Exception as exc:
        logger.debug(f"[evolution] failed to restore adaptive factor state: {exc}")
    finally:
        session.close()

    _factor_tracker = FactorImportanceTracker()
    return _factor_tracker


def _save_factor_tracker_state(tracker: FactorImportanceTracker) -> None:
    session = get_session()
    try:
        session.add(MarketSnapshot(
            snapshot_type="adaptive_factor_state",
            timestamp=datetime.datetime.now(),
            date=datetime.date.today(),
            data=tracker.to_dict(),
        ))
        session.commit()
    except Exception as exc:
        session.rollback()
        logger.debug(f"[evolution] save adaptive factor state failed: {exc}")
    finally:
        session.close()


def update_adaptive_factor_tracker(trade_details: List[Dict[str, Any]], source: str = "runtime") -> Dict[str, Any]:
    tracker = _get_factor_tracker()
    normalized_details = compress_trade_details(trade_details)
    multipliers = tracker.update_from_trades(normalized_details)
    _save_factor_tracker_state(tracker)
    top_factors = tracker.get_top_factors(5)
    noise_factors = tracker.get_noise_factors(3)
    return {
        "source": source,
        "multipliers": multipliers,
        "top_factors": top_factors,
        "noise_factors": noise_factors,
        "sample_count": tracker.to_dict().get("sample_count", 0),
        "raw_samples": len(trade_details or []),
        "normalized_samples": len(normalized_details),
    }


def get_adaptive_factor_multipliers() -> Dict[str, float]:
    return dict(_get_factor_tracker().multipliers)


def _collect_trade_details_with_factors(session, since: datetime.date) -> List[Dict[str, Any]]:
    details: List[Dict[str, Any]] = []
    try:
        from models import EvolutionPaperTrade

        paper_trades = session.query(EvolutionPaperTrade).filter(
            EvolutionPaperTrade.date >= since,
            EvolutionPaperTrade.direction == "SELL",
        ).all()
        for trade in paper_trades:
            ctx = dict(trade.context or {})
            breakdown = dict(ctx.get("breakdown") or {})
            if not breakdown:
                continue
            details.append({
                "code": trade.code or "",
                "date": str(trade.date or ""),
                "pnl_pct": float(trade.pnl_pct or 0.0),
                "pnl": float(trade.pnl or 0.0),
                "pick_type": trade.pick_type or "",
                "zone": trade.zone or "",
                "factor_scores": breakdown,
            })
    except Exception as exc:
        logger.debug(f"[evolution] collect factor trades failed: {exc}")

    return details


def _build_regime_actions(
    dominant_regime: str,
    avg_wr: float,
    avg_pr: float,
    total_pnl: float,
    max_dd: float,
    consecutive_loss_days: int,
) -> List[Dict]:
    actions: List[Dict] = []

    if dominant_regime in ("super_attack", "attack"):
        if avg_wr < EVOLUTION_THRESHOLDS["win_rate_poor"]:
            actions.append({
                "param": "min_buy_volume_ratio",
                "delta": 0.15,
                "direction": "+",
                "reason": "attack regime but entry quality is weak",
            })
            actions.append({
                "param": "max_chase_pct",
                "delta": 0.25,
                "direction": "-",
                "reason": "attack regime but chase extension is hurting win rate",
            })
        elif avg_pr >= EVOLUTION_THRESHOLDS["profit_ratio_excellent"] and total_pnl > 0:
            actions.append({
                "param": "take_profit_2_pct",
                "delta": 0.004,
                "direction": "+",
                "reason": "attack regime has room to let winners run longer",
            })
    elif dominant_regime == "range":
        actions.append({
            "param": "max_chase_pct",
            "delta": 0.3,
            "direction": "-",
            "reason": "range regime should avoid extended entries",
        })
        if avg_pr < EVOLUTION_THRESHOLDS["profit_ratio_poor"]:
            actions.append({
                "param": "take_profit_1_pct",
                "delta": 0.003,
                "direction": "-",
                "reason": "range regime should harvest earlier",
            })
    else:
        actions.append({
            "param": "min_buy_volume_ratio",
            "delta": 0.2,
            "direction": "+",
            "reason": "risk regime needs cleaner confirmations",
        })
        actions.append({
            "param": "max_chase_pct",
            "delta": 0.4,
            "direction": "-",
            "reason": "risk regime should strongly avoid chasing",
        })

    if consecutive_loss_days >= 3:
        actions.append({
            "param": "max_chase_pct",
            "delta": 0.35,
            "direction": "-",
            "reason": "three consecutive losing days",
        })

    if max_dd >= EVOLUTION_THRESHOLDS["max_dd_warn"]:
        actions.append({
            "param": "take_profit_1_pct",
            "delta": 0.002,
            "direction": "-",
            "reason": "drawdown is elevated, reduce holding greed",
        })

    return actions


def run_evolution_check(auto_adjust: bool = False):
    logger.info("[evolution] running adaptive evolution check")
    session = get_session()
    try:
        lookback = EVOLUTION_THRESHOLDS["lookback_days"]
        since = datetime.date.today() - datetime.timedelta(days=lookback * 2)
        day_stats = session.query(StrategyStats).filter(
            StrategyStats.period_type == "day",
            StrategyStats.period_start >= since,
        ).order_by(StrategyStats.period_start.desc()).limit(lookback).all()

        if len(day_stats) < 3:
            logger.info(f"[evolution] not enough daily stats: {len(day_stats)}")
            return {"insights": ["insufficient daily stats"], "applied": []}

        avg_wr = sum(float(stat.win_rate or 0) for stat in day_stats) / len(day_stats)
        avg_pr = sum(float(stat.profit_ratio or 0) for stat in day_stats) / len(day_stats)
        total_pnl = sum(float(stat.total_pnl or 0) for stat in day_stats)
        max_dd = max(float(stat.max_drawdown or 0) for stat in day_stats)

        consecutive_loss_days = 0
        for stat in day_stats:
            if float(stat.total_pnl or 0) < 0:
                consecutive_loss_days += 1
            else:
                break

        dominant_regime = _dominant_regime(session, since)
        insights = [
            f"dominant regime: {dominant_regime}",
            f"avg win rate: {avg_wr * 100:.1f}%",
            f"avg profit ratio: {avg_pr:.2f}",
            f"total pnl: {total_pnl:+.2f}",
            f"max drawdown: {max_dd:.2f}%",
        ]

        factor_update: Dict[str, Any] = {}
        trade_details = _collect_trade_details_with_factors(session, since)
        if trade_details:
            factor_update = update_adaptive_factor_tracker(
                trade_details,
                source=f"optimizer:{dominant_regime}",
            )
            top_factors = factor_update.get("top_factors") or []
            noise_factors = factor_update.get("noise_factors") or []
            if top_factors:
                insights.append(
                    "top factors: " + ", ".join(
                        f"{name}({effect:+.2f})"
                        for name, effect, _ in top_factors[:3]
                    )
                )
            if noise_factors:
                insights.append(
                    "noise factors: " + ", ".join(
                        f"{name}({effect:+.2f})"
                        for name, effect, _ in noise_factors
                    )
                )

        if max_dd >= RISK_CONTROL["total_max_drawdown_pct"]:
            insights.append("force stop risk threshold hit")
            _log_risk_event(
                session,
                "force_stop",
                f"drawdown {max_dd:.2f}% exceeded total limit",
                "stop trading until manually reviewed",
            )
        elif max_dd >= RISK_CONTROL["month_max_drawdown_pct"]:
            insights.append("monthly drawdown warning")
            _log_risk_event(
                session,
                "drawdown_warn",
                f"drawdown {max_dd:.2f}% exceeded monthly limit",
                "degrade to paper-trading mode",
            )

        candidate_actions = _build_regime_actions(
            dominant_regime=dominant_regime,
            avg_wr=avg_wr,
            avg_pr=avg_pr,
            total_pnl=total_pnl,
            max_dd=max_dd,
            consecutive_loss_days=consecutive_loss_days,
        )

        applied = []
        if auto_adjust and candidate_actions:
            used_params = set()
            max_changes = max(0, EVOLUTION_THRESHOLDS.get("max_param_changes_per_week", 1) - _count_week_changes(session))
            for action in candidate_actions:
                if len(applied) >= max_changes:
                    break
                if action["param"] in used_params:
                    continue

                current_value = float(get_param(action["param"], 0) or 0)
                if action["direction"] == "+":
                    new_value = current_value + action["delta"]
                else:
                    new_value = current_value - action["delta"]

                if action["param"] in EVOLUTION_BOUNDS:
                    low, high = EVOLUTION_BOUNDS[action["param"]]
                    new_value = max(low, min(high, new_value))
                new_value = round(new_value, 4)
                if abs(new_value - current_value) < 1e-6:
                    continue

                if set_param(action["param"], new_value, updated_by="evolution"):
                    applied.append({
                        "param": action["param"],
                        "old": current_value,
                        "new": new_value,
                        "reason": action["reason"],
                    })
                    used_params.add(action["param"])
                    insights.append(
                        f"adjusted {action['param']}: {current_value} -> {new_value} ({action['reason']})"
                    )

        log = EvolutionLog(
            trigger_reason=f"daily regime={dominant_regime}",
            analysis="\n".join(insights),
            old_params={item["param"]: item["old"] for item in applied},
            new_params={item["param"]: item["new"] for item in applied},
            performance_before={
                "avg_win_rate": avg_wr,
                "avg_profit_ratio": avg_pr,
                "total_pnl": total_pnl,
                "max_drawdown": max_dd,
                "consecutive_loss_days": consecutive_loss_days,
                "dominant_regime": dominant_regime,
                "adaptive_factors": factor_update,
            },
            approved=bool(applied),
        )
        session.add(log)
        session.commit()

        logger.info(
            f"[evolution] regime={dominant_regime} "
            f"wr={avg_wr * 100:.1f}% pr={avg_pr:.2f} "
            f"dd={max_dd:.2f}% applied={len(applied)}"
        )
        return {"insights": insights, "applied": applied, "factor_update": factor_update}

    except Exception as exc:
        session.rollback()
        logger.error(f"[evolution] failed: {exc}")
        return {"insights": [f"evolution failed: {exc}"], "applied": []}
    finally:
        session.close()


def _return_pct(total_pnl: float) -> float:
    capital = float(get_param("initial_capital", TRADE_RULES["initial_capital"]) or TRADE_RULES["initial_capital"])
    if capital <= 0:
        return 0.0
    return round(float(total_pnl or 0.0) / capital * 100.0, 2)


def _stat_payload(stat: StrategyStats | None) -> Dict:
    if stat is None:
        return {}
    return {
        "period_start": str(stat.period_start) if stat.period_start else "",
        "period_end": str(stat.period_end) if stat.period_end else "",
        "trades": int(stat.total_trades or 0),
        "win_rate": float(stat.win_rate or 0.0),
        "profit_ratio": float(stat.profit_ratio or 0.0),
        "pnl": float(stat.total_pnl or 0.0),
        "max_dd": float(stat.max_drawdown or 0.0),
        "return_pct": _return_pct(float(stat.total_pnl or 0.0)),
    }


def _backtest_health(month_return_pct: float, month_drawdown_pct: float, sample_count: int) -> tuple[str, str]:
    if sample_count <= 0:
        return "bootstrapping", "等待样本积累"
    if month_drawdown_pct >= RISK_CONTROL["backtest_max_month_dd"]:
        return "risk_warn", "回撤超阈值"
    if month_return_pct >= PERFORMANCE_TARGET["monthly_return_pct"]:
        return "on_target", "达到月化目标区间"
    if month_return_pct >= PERFORMANCE_TARGET["monthly_return_pct"] * 0.6:
        return "catching_up", "接近目标区间"
    if month_return_pct >= 0:
        return "tracking", "持续跟踪优化中"
    return "underwater", "收益落后目标"


def run_dynamic_backtest_snapshot() -> Dict:
    """生成可视化动态回测快照，不主动改参。"""
    session = get_session()
    try:
        latest_day = session.query(StrategyStats).filter(
            StrategyStats.period_type == "day",
        ).order_by(StrategyStats.period_start.desc()).first()
        latest_week = session.query(StrategyStats).filter(
            StrategyStats.period_type == "week",
        ).order_by(StrategyStats.period_start.desc()).first()
        latest_month = session.query(StrategyStats).filter(
            StrategyStats.period_type == "month",
        ).order_by(StrategyStats.period_start.desc()).first()
        last_evolution = session.query(EvolutionLog).order_by(EvolutionLog.created_at.desc()).first()

        month_payload = _stat_payload(latest_month)
        day_payload = _stat_payload(latest_day)
        week_payload = _stat_payload(latest_week)

        month_return_pct = float(month_payload.get("return_pct", 0.0) or 0.0)
        month_drawdown_pct = float(
            month_payload.get("max_dd", day_payload.get("max_dd", 0.0)) or 0.0
        )
        target_gap_pct = round(month_return_pct - PERFORMANCE_TARGET["monthly_return_pct"], 2)
        distance_to_target_pct = round(PERFORMANCE_TARGET["monthly_return_pct"] - month_return_pct, 2)
        risk_budget_left_pct = round(max(0.0, RISK_CONTROL["backtest_max_month_dd"] - month_drawdown_pct), 2)
        health, health_label = _backtest_health(
            month_return_pct=month_return_pct,
            month_drawdown_pct=month_drawdown_pct,
            sample_count=int(day_payload.get("trades", 0) or 0),
        )

        payload = {
            "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "monthly_target_pct": float(PERFORMANCE_TARGET["monthly_return_pct"]),
            "single_trade_loss_limit_pct": float(PERFORMANCE_TARGET["single_trade_max_loss_pct"]),
            "month_return_pct": month_return_pct,
            "target_gap_pct": target_gap_pct,
            "distance_to_target_pct": distance_to_target_pct,
            "month_drawdown_pct": round(month_drawdown_pct, 2),
            "risk_budget_left_pct": risk_budget_left_pct,
            "status": health,
            "status_label": health_label,
            "day": day_payload,
            "week": week_payload,
            "month": month_payload,
            "last_evolution": {
                "date": str(last_evolution.created_at) if last_evolution and last_evolution.created_at else "",
                "trigger": last_evolution.trigger_reason if last_evolution else "",
                "auto_adjusted": bool(last_evolution.approved) if last_evolution else False,
                "changes": dict(last_evolution.new_params or {}) if last_evolution else {},
            },
        }

        session.add(MarketSnapshot(
            snapshot_type="dynamic_backtest",
            timestamp=datetime.datetime.now(),
            date=datetime.date.today(),
            data=payload,
        ))
        session.commit()

        update_state(
            last_dynamic_backtest=payload["ts"],
            monthly_return_pct=month_return_pct,
            monthly_target_gap_pct=target_gap_pct,
            dynamic_backtest_health=health,
        )
        return payload
    except Exception as exc:
        session.rollback()
        logger.error(f"[dynamic_backtest] failed: {exc}")
        return {
            "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "monthly_target_pct": float(PERFORMANCE_TARGET["monthly_return_pct"]),
            "single_trade_loss_limit_pct": float(PERFORMANCE_TARGET["single_trade_max_loss_pct"]),
            "month_return_pct": 0.0,
            "target_gap_pct": -float(PERFORMANCE_TARGET["monthly_return_pct"]),
            "distance_to_target_pct": float(PERFORMANCE_TARGET["monthly_return_pct"]),
            "month_drawdown_pct": 0.0,
            "risk_budget_left_pct": float(RISK_CONTROL["backtest_max_month_dd"]),
            "status": "bootstrapping",
            "status_label": f"快照生成失败: {exc}",
            "day": {},
            "week": {},
            "month": {},
            "last_evolution": {},
        }
    finally:
        session.close()


def get_dynamic_backtest_status() -> Dict:
    session = get_session()
    try:
        snapshot = session.query(MarketSnapshot).filter(
            MarketSnapshot.snapshot_type == "dynamic_backtest",
        ).order_by(MarketSnapshot.timestamp.desc()).first()
        if snapshot and snapshot.data:
            return snapshot.data
    finally:
        session.close()
    return run_dynamic_backtest_snapshot()


def get_evolution_history(limit: int = 30) -> list:
    session = get_session()
    try:
        logs = session.query(EvolutionLog).order_by(EvolutionLog.created_at.desc()).limit(limit).all()
        return [{
            "date": str(log.created_at.date()) if log.created_at else "",
            "trigger": log.trigger_reason or "",
            "insights": log.analysis or "",
            "changes": log.new_params or {},
            "performance": log.performance_before or {},
            "auto_adjusted": log.approved,
        } for log in logs]
    finally:
        session.close()


# ════════════════════════════════════════════════════════════════════════════
# 每日回测报告（自动化）
# ════════════════════════════════════════════════════════════════════════════

def _collect_backtest_signals(days: int = 60) -> List[Dict]:
    """
    从最近 N 天的 SELL 成交记录重建回测信号。
    对于没有实盘数据的场景（如首次启动），返回空列表 →
    调用方会跳过报告生成。
    """
    from models import TradeRecord
    session = get_session()
    try:
        since = datetime.date.today() - datetime.timedelta(days=days)
        sells = session.query(TradeRecord).filter(
            TradeRecord.date >= since,
            TradeRecord.direction == "SELL",
        ).all()
        signals: List[Dict] = []
        for s in sells:
            entry_price = float(s.buy_price or 0)
            exit_price = float(s.price or 0)
            if entry_price <= 0 or exit_price <= 0:
                continue
            # 取 high/low 为保守估计（本地没有分时线时用 entry/exit 的范围）
            high = max(entry_price, exit_price)
            low = min(entry_price, exit_price)
            signals.append({
                "date": str(s.date),
                "code": s.code,
                "name": s.name or "",
                "entry_price": entry_price,
                "low_3d": low,
                "high_3d": high,
                "close_d3": exit_price,
                "zone": s.zone or "attack",
                "emotion": s.emotion or "",
                "signal_type": s.signal_type or "adaptive",
            })
        return signals
    finally:
        session.close()


def _backtest_report_dir():
    from openclaw_adapter import get_reports_dir
    d = get_reports_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d


def generate_daily_backtest_report() -> Dict:
    """
    基于历史成交记录运行一次完整回测，生成 markdown + json 报告并落盘。
    无样本时降级为当前参数快照 + dynamic_backtest_snapshot 的说明报告。
    """
    import json
    from evolution.backtest import run_backtest

    ts = datetime.datetime.now()
    report_dir = _backtest_report_dir()
    date_str = ts.strftime("%Y%m%d")

    signals = _collect_backtest_signals(days=60)
    sample_count = len(signals)

    if sample_count >= 5:
        result = run_backtest(signals, initial_capital=float(TRADE_RULES["initial_capital"]))
        total_trades = result.total_trades
        win_rate = round(result.win_rate * 100, 2)
        profit_ratio = round(result.profit_ratio, 2)
        total_pnl = round(result.total_pnl, 2)
        max_dd = round(result.max_drawdown_pct, 2)
        passed = bool(result.passed)
        fail_reasons = list(result.fail_reasons or [])
        monthly_returns = dict(result.monthly_returns or {})
        trades = [{
            "date": trade.date,
            "code": trade.code,
            "name": trade.name,
            "entry": trade.entry_price,
            "exit": trade.exit_price,
            "pnl": trade.pnl,
            "pnl_pct": trade.pnl_pct,
            "exit_reason": trade.exit_reason,
        } for trade in result.trades]
    else:
        total_trades = sample_count
        win_rate = 0.0
        profit_ratio = 0.0
        total_pnl = 0.0
        max_dd = 0.0
        passed = False
        fail_reasons = [f"insufficient trade samples ({sample_count})"]
        monthly_returns = {}
        trades = []

    # 构建 markdown 摘要
    lines = [
        f"# DragonFlow 每日回测报告 {ts.date().isoformat()}",
        "",
        f"- 生成时间: {ts.strftime('%H:%M:%S')}",
        f"- 样本数: {total_trades}",
        f"- 胜率: {win_rate:.2f}%",
        f"- 盈亏比: {profit_ratio:.2f}",
        f"- 总盈亏: {total_pnl:+.2f}",
        f"- 最大回撤: {max_dd:.2f}%",
        f"- 回测达标: {'PASS' if passed else 'FAIL'}",
    ]
    if fail_reasons:
        lines.append("")
        lines.append("## 不达标原因")
        for r in fail_reasons:
            lines.append(f"- {r}")
    if monthly_returns:
        lines.append("")
        lines.append("## 月度收益")
        for month, pnl in sorted(monthly_returns.items()):
            lines.append(f"- {month}: {pnl:+.2f}")
    if trades:
        lines.append("")
        lines.append(f"## 近期 {min(len(trades), 10)} 笔交易")
        for t in trades[:10]:
            lines.append(
                f"- {t['date']} {t['code']} {t['name']} "
                f"{t['entry']:.2f}->{t['exit']:.2f} "
                f"pnl={t['pnl']:+.2f} ({t['pnl_pct']:+.2f}%) [{t['exit_reason']}]"
            )

    summary = "\n".join(lines)
    payload = {
        "ts": ts.strftime("%Y-%m-%d %H:%M:%S"),
        "date": ts.date().isoformat(),
        "total_trades": total_trades,
        "win_rate": win_rate,
        "profit_ratio": profit_ratio,
        "total_pnl": total_pnl,
        "max_drawdown_pct": max_dd,
        "passed": passed,
        "fail_reasons": fail_reasons,
        "monthly_returns": monthly_returns,
        "trades": trades,
        "summary": summary,
    }

    md_path = report_dir / f"backtest_{date_str}.md"
    json_path = report_dir / f"backtest_{date_str}.json"
    try:
        md_path.write_text(summary, encoding="utf-8")
        json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        payload["report_path"] = str(md_path)
        logger.info(f"[daily_backtest] 报告已写入 {md_path}")
    except Exception as exc:
        logger.error(f"[daily_backtest] 写入报告失败: {exc}")
        payload["report_path"] = ""

    # 存入 MarketSnapshot 以便 API 快速返回
    session = get_session()
    try:
        session.add(MarketSnapshot(
            snapshot_type="daily_backtest_report",
            timestamp=ts,
            date=ts.date(),
            data=payload,
        ))
        session.commit()
    except Exception as exc:
        session.rollback()
        logger.warning(f"[daily_backtest] 快照入库失败: {exc}")
    finally:
        session.close()

    return payload


def get_latest_backtest_report() -> Dict:
    session = get_session()
    try:
        snapshot = session.query(MarketSnapshot).filter(
            MarketSnapshot.snapshot_type == "daily_backtest_report",
        ).order_by(MarketSnapshot.timestamp.desc()).first()
        if snapshot and snapshot.data:
            return snapshot.data
    finally:
        session.close()
    return {}
