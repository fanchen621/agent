from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Dict, List, Tuple


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def normalize_factor_name(name: Any) -> str:
    text = str(name or "").strip()
    if not text:
        return ""
    if text.startswith("mf_"):
        return text[3:]
    return ""


def compress_trade_details(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Collapse repeated same-cycle trade samples into code-level observations.

    Openclaw/runtime replays can occasionally generate many repeated BUY/SELL rows for
    the same code and pick type within one cycle. Feeding those raw rows directly into
    factor learning makes the adaptive direction unstable because a single symbol can
    dominate the whole sample. Here we aggregate them into one representative sample.
    """
    groups: Dict[Tuple[str, str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for idx, trade in enumerate(trades or []):
        item = dict(trade or {})
        code = str(item.get("code") or "").strip()
        pick_type = str(item.get("pick_type") or "").strip()
        zone = str(item.get("zone") or "").strip()
        date = str(item.get("date") or "").strip()
        key = (date, code or f"__row_{idx}", pick_type, zone)
        groups[key].append(item)

    compressed: List[Dict[str, Any]] = []
    for items in groups.values():
        if len(items) == 1:
            item = dict(items[0])
            item["sample_repeat_count"] = max(1, int(item.get("sample_repeat_count") or 1))
            compressed.append(item)
            continue

        factor_scores: Dict[str, List[float]] = defaultdict(list)
        for item in items:
            for name, value in dict(item.get("factor_scores") or {}).items():
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    continue
                factor_scores[str(name)].append(float(value))

        sample = dict(items[0])
        sample["pnl"] = round(sum(_safe_float(item.get("pnl")) for item in items), 4)
        sample["pnl_pct"] = round(
            sum(_safe_float(item.get("pnl_pct")) for item in items) / max(1, len(items)),
            4,
        )
        sample["factor_scores"] = {
            name: round(sum(values) / max(1, len(values)), 4)
            for name, values in factor_scores.items()
            if values
        }
        sample["sample_repeat_count"] = len(items)
        compressed.append(sample)

    return compressed


class FactorImportanceTracker:
    """
    Learn multiplicative adjustments for multi-factor weights from realized trade outcomes.

    The runtime breakdown currently stores multi-factor details as `mf_<factor_name>`.
    This tracker only learns from those keys so it does not mix unrelated runtime metrics
    such as route weight, confidence, or capital flow into the adaptive factor layer.
    """

    def __init__(
        self,
        multipliers: Dict[str, float] | None = None,
        effectiveness: Dict[str, float] | None = None,
        sample_count: int = 0,
        ema_alpha: float = 0.18,
    ):
        self.multipliers: Dict[str, float] = {
            str(name): _clamp(_safe_float(value, 1.0), 0.7, 1.35)
            for name, value in (multipliers or {}).items()
            if str(name)
        }
        self._effectiveness: Dict[str, float] = {
            str(name): _safe_float(value)
            for name, value in (effectiveness or {}).items()
            if str(name)
        }
        self._sample_count = max(0, int(sample_count or 0))
        self.ema_alpha = _clamp(_safe_float(ema_alpha, 0.18), 0.05, 0.5)

    def update_from_trades(self, trades: List[Dict[str, Any]]) -> Dict[str, float]:
        contributions: Dict[str, float] = defaultdict(float)
        counts: Dict[str, int] = defaultdict(int)

        for trade in trades or []:
            pnl_pct = _safe_float(trade.get("pnl_pct"))
            if abs(pnl_pct) < 1e-9:
                continue
            direction = 1.0 if pnl_pct > 0 else -1.0
            magnitude = _clamp(abs(pnl_pct), 0.1, 8.0) / 4.0
            factor_scores = dict(trade.get("factor_scores") or {})
            for raw_name, raw_score in factor_scores.items():
                name = normalize_factor_name(raw_name)
                if not name:
                    continue
                centered = _clamp(_safe_float(raw_score, 5.0) - 5.0, -4.0, 4.0)
                contribution = centered * direction * magnitude
                contributions[name] += contribution
                counts[name] += 1

        if not counts:
            return dict(self.multipliers)

        for name, count in counts.items():
            avg = contributions[name] / max(1, count)
            prev = self._effectiveness.get(name, 0.0)
            self._effectiveness[name] = (1.0 - self.ema_alpha) * prev + self.ema_alpha * avg

        self._sample_count += sum(counts.values())
        self._rebalance()
        return dict(self.multipliers)

    def _rebalance(self) -> None:
        confidence = _clamp(self._sample_count / 160.0, 0.1, 1.0)
        for name, effect in self._effectiveness.items():
            scaled = _clamp(effect * (0.22 + confidence * 0.18), -0.55, 0.55)
            multiplier = math.exp(scaled)
            self.multipliers[name] = round(_clamp(multiplier, 0.7, 1.35), 4)

    def get_top_factors(self, n: int = 5) -> List[Tuple[str, float, float]]:
        ranked = sorted(self._effectiveness.items(), key=lambda item: item[1], reverse=True)
        return [
            (name, round(effect, 3), round(self.multipliers.get(name, 1.0), 4))
            for name, effect in ranked[:n]
        ]

    def get_noise_factors(self, n: int = 3) -> List[Tuple[str, float, float]]:
        ranked = sorted(self._effectiveness.items(), key=lambda item: item[1])
        rows: List[Tuple[str, float, float]] = []
        for name, effect in ranked:
            if effect >= -0.05:
                continue
            rows.append((name, round(effect, 3), round(self.multipliers.get(name, 1.0), 4)))
            if len(rows) >= n:
                break
        return rows

    def to_dict(self) -> Dict[str, Any]:
        return {
            "multipliers": dict(self.multipliers),
            "effectiveness": {name: round(value, 4) for name, value in self._effectiveness.items()},
            "sample_count": self._sample_count,
            "ema_alpha": self.ema_alpha,
            "top_factors": self.get_top_factors(5),
            "noise_factors": self.get_noise_factors(3),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FactorImportanceTracker":
        return cls(
            multipliers=dict(data.get("multipliers") or {}),
            effectiveness=dict(data.get("effectiveness") or {}),
            sample_count=int(data.get("sample_count", 0) or 0),
            ema_alpha=_safe_float(data.get("ema_alpha"), 0.18),
        )
