from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from loguru import logger

from config import RISK_CONTROL, TRADE_RULES
from strategy.runtime_rules import get_runtime_trade_rules


@dataclass
class BacktestTrade:
    date: str
    code: str
    name: str
    entry_price: float
    exit_price: float
    shares: int
    pnl: float
    pnl_pct: float
    signal_type: str
    exit_reason: str
    hold_days: int


@dataclass
class BacktestResult:
    trades: List[BacktestTrade]
    total_trades: int = 0
    win_trades: int = 0
    lose_trades: int = 0
    win_rate: float = 0.0
    avg_win_pct: float = 0.0
    avg_lose_pct: float = 0.0
    profit_ratio: float = 0.0
    total_pnl: float = 0.0
    max_drawdown_pct: float = 0.0
    capital_curve: List[float] = field(default_factory=list)
    monthly_returns: Dict[str, float] = field(default_factory=dict)
    passed: bool = False
    fail_reasons: List[str] = field(default_factory=list)


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _simulate_trade(signal: Dict, capital: float) -> Dict:
    entry_price = float(signal.get("entry_price", 0) or 0)
    if entry_price <= 0:
        return {}

    zone = signal.get("zone", "attack")
    emotion = signal.get("emotion", "")
    score = float(signal.get("score", 0.0) or 0.0)
    pick_type = str(signal.get("pick_type", "") or "")
    if zone == "risk":
        return {}
    rules = get_runtime_trade_rules(zone, emotion, score, pick_type)
    position_policy = rules.get("position_policy") or {}

    target_position_pct = float(signal.get("target_position_pct", 0.0) or 0.0)
    if target_position_pct <= 0:
        target_position_pct = float(position_policy.get("max_single_pct", 0.3) or 0.3)
    target_position_pct = _clamp(target_position_pct, 0.1, 0.7)

    shares = int(capital * target_position_pct / entry_price / 100) * 100
    if shares <= 0:
        return {}

    stop_price = float(signal.get("stop_price", 0) or 0) or round(
        entry_price * (1 + float(rules["stop_loss_pct"])), 3
    )
    tp1_price = float(signal.get("tp1_price", 0) or 0) or round(
        entry_price * (1 + float(rules["take_profit_1_pct"])), 3
    )
    tp2_price = float(signal.get("tp2_price", 0) or 0) or round(
        entry_price * (1 + float(rules["take_profit_2_pct"])), 3
    )
    hold_days = int(signal.get("hold_days_max", rules["max_hold_days"]) or rules["max_hold_days"])

    low_3d = float(signal.get("low_3d", entry_price) or entry_price)
    high_3d = float(signal.get("high_3d", entry_price) or entry_price)
    close_d3 = float(signal.get("close_d3", entry_price) or entry_price)

    buy_fee_rate = float(rules.get("buy_fee_rate", TRADE_RULES["buy_fee_rate"]))
    sell_fee_rate = float(rules.get("sell_fee_rate", TRADE_RULES["sell_fee_rate"]))

    buy_cost = entry_price * shares * (1 + buy_fee_rate)
    remaining_shares = shares
    sell_value = 0.0
    exit_price = close_d3
    exit_reason = "TIME_EXIT"

    if low_3d <= stop_price:
        sell_value = stop_price * shares * (1 - sell_fee_rate)
        exit_price = stop_price
        exit_reason = "STOP_LOSS"
    else:
        if high_3d >= tp1_price:
            tp1_shares = max((shares // 2) // 100 * 100, 100) if shares > 100 else shares
            tp1_shares = min(tp1_shares, remaining_shares)
            if tp1_shares > 0:
                sell_value += tp1_price * tp1_shares * (1 - sell_fee_rate)
                remaining_shares -= tp1_shares
                exit_reason = "TAKE_PROFIT_1"
                exit_price = tp1_price

        if remaining_shares > 0 and high_3d >= tp2_price:
            sell_value += tp2_price * remaining_shares * (1 - sell_fee_rate)
            exit_price = tp2_price
            exit_reason = "TAKE_PROFIT_2"
            remaining_shares = 0

        if remaining_shares > 0:
            sell_value += close_d3 * remaining_shares * (1 - sell_fee_rate)
            exit_price = close_d3

    pnl = round(sell_value - buy_cost, 2)
    pnl_pct = round(pnl / buy_cost * 100, 2) if buy_cost > 0 else 0.0

    return {
        "shares": shares,
        "entry_price": entry_price,
        "exit_price": round(exit_price, 2),
        "exit_reason": exit_reason,
        "hold_days": hold_days,
        "pnl": pnl,
        "pnl_pct": pnl_pct,
    }


def run_backtest(signals: List[Dict], initial_capital: float = 10000.0) -> BacktestResult:
    trades: List[BacktestTrade] = []
    capital = initial_capital
    capital_curve = [round(capital, 2)]

    for signal in signals:
        result = _simulate_trade(signal, capital)
        if not result:
            continue

        trades.append(BacktestTrade(
            date=str(signal.get("date", "")),
            code=str(signal.get("code", "")),
            name=str(signal.get("name", "")),
            entry_price=result["entry_price"],
            exit_price=result["exit_price"],
            shares=result["shares"],
            pnl=result["pnl"],
            pnl_pct=result["pnl_pct"],
            signal_type=str(signal.get("signal_type", "adaptive")),
            exit_reason=result["exit_reason"],
            hold_days=result["hold_days"],
        ))
        capital += result["pnl"]
        capital_curve.append(round(capital, 2))

    outcome = BacktestResult(trades=trades)
    outcome.total_trades = len(trades)
    outcome.capital_curve = capital_curve
    if not trades:
        return outcome

    wins = [trade for trade in trades if trade.pnl > 0]
    losses = [trade for trade in trades if trade.pnl <= 0]
    outcome.win_trades = len(wins)
    outcome.lose_trades = len(losses)
    outcome.win_rate = outcome.win_trades / outcome.total_trades if outcome.total_trades else 0.0
    outcome.avg_win_pct = sum(trade.pnl_pct for trade in wins) / len(wins) if wins else 0.0
    outcome.avg_lose_pct = sum(trade.pnl_pct for trade in losses) / len(losses) if losses else 0.0
    outcome.profit_ratio = abs(outcome.avg_win_pct / outcome.avg_lose_pct) if outcome.avg_lose_pct else 0.0
    outcome.total_pnl = round(sum(trade.pnl for trade in trades), 2)

    peak = capital_curve[0]
    max_drawdown = 0.0
    for value in capital_curve:
        peak = max(peak, value)
        drawdown = (peak - value) / peak * 100 if peak > 0 else 0.0
        max_drawdown = max(max_drawdown, drawdown)
    outcome.max_drawdown_pct = round(max_drawdown, 2)

    monthly: Dict[str, float] = {}
    for trade in trades:
        month = trade.date[:7] if len(trade.date) >= 7 else "unknown"
        monthly[month] = monthly.get(month, 0.0) + trade.pnl
    outcome.monthly_returns = {month: round(value, 2) for month, value in monthly.items()}

    outcome.passed = True
    if outcome.win_rate < RISK_CONTROL["backtest_min_win_rate"]:
        outcome.passed = False
        outcome.fail_reasons.append(
            f"win_rate {outcome.win_rate * 100:.1f}% < {RISK_CONTROL['backtest_min_win_rate'] * 100:.0f}%"
        )
    if outcome.profit_ratio < RISK_CONTROL["backtest_min_profit_ratio"]:
        outcome.passed = False
        outcome.fail_reasons.append(
            f"profit_ratio {outcome.profit_ratio:.2f} < {RISK_CONTROL['backtest_min_profit_ratio']}"
        )
    if outcome.max_drawdown_pct > RISK_CONTROL["backtest_max_total_dd"]:
        outcome.passed = False
        outcome.fail_reasons.append(
            f"max_drawdown {outcome.max_drawdown_pct:.2f}% > {RISK_CONTROL['backtest_max_total_dd']}%"
        )
    if outcome.total_trades < RISK_CONTROL["backtest_min_samples"]:
        outcome.fail_reasons.append(
            f"samples {outcome.total_trades} < {RISK_CONTROL['backtest_min_samples']}"
        )

    logger.info(
        f"[backtest] trades={outcome.total_trades} "
        f"win_rate={outcome.win_rate * 100:.1f}% "
        f"profit_ratio={outcome.profit_ratio:.2f} "
        f"dd={outcome.max_drawdown_pct:.2f}% "
        f"pnl={outcome.total_pnl:+.2f}"
    )
    return outcome
