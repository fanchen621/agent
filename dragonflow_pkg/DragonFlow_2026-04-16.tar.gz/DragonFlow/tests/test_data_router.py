from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
import sys

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from feeds.data_router import CacheManager  # noqa: E402
import openclaw_adapter  # noqa: E402


class DataRouterTests(unittest.TestCase):
    def test_default_cache_dir_prefers_workspace_data_dir(self):
        with patch.dict(os.environ, {}, clear=False):
            cache_dir = CacheManager.default_cache_dir()
        self.assertNotIn("/root/.openclaw", cache_dir)
        self.assertTrue(cache_dir.endswith(str(Path("data") / "cache")))

    def test_cache_manager_falls_back_when_primary_dir_invalid(self):
        with tempfile.TemporaryDirectory() as tmp:
            old_cwd = os.getcwd()
            os.chdir(tmp)
            try:
                with patch("feeds.data_router.os.makedirs", side_effect=PermissionError("denied")):
                    manager = CacheManager(cache_dir=str(Path(tmp) / "blocked" / "cache"))
            finally:
                os.chdir(old_cwd)

        self.assertIn("data", manager.cache_dir)
        self.assertTrue(manager.cache_dir.endswith(str(Path("data") / "cache")))

    def test_ensure_router_ready_probes_only_once(self):
        fake_router = MagicMock()
        openclaw_adapter._router = None
        openclaw_adapter._router_probe_attempted = False

        with patch("feeds.data_router.get_router", return_value=fake_router):
            self.assertTrue(openclaw_adapter.ensure_router_ready(force=True))
            self.assertTrue(openclaw_adapter.ensure_router_ready())

        self.assertEqual(fake_router.probe_all.call_count, 1)


if __name__ == "__main__":
    unittest.main()
