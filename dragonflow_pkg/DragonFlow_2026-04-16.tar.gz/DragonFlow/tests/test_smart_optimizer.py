from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from evolution.smart_optimizer import FactorImportanceTracker, compress_trade_details  # noqa: E402
from strategy.multi_factor import FactorScore, _apply_adaptive_multipliers  # noqa: E402


class SmartOptimizerTests(unittest.TestCase):
    def test_compress_trade_details_collapses_repeated_code_samples(self):
        compressed = compress_trade_details([
            {
                "date": "2026-04-14",
                "code": "AAA",
                "pick_type": "low_position_trend",
                "zone": "attack",
                "pnl": 120.0,
                "pnl_pct": 4.0,
                "factor_scores": {"mf_alpha": 8.0},
            },
            {
                "date": "2026-04-14",
                "code": "AAA",
                "pick_type": "low_position_trend",
                "zone": "attack",
                "pnl": 80.0,
                "pnl_pct": 2.0,
                "factor_scores": {"mf_alpha": 6.0},
            },
            {
                "date": "2026-04-14",
                "code": "BBB",
                "pick_type": "base_pivot_trend",
                "zone": "attack",
                "pnl": -60.0,
                "pnl_pct": -1.5,
                "factor_scores": {"mf_alpha": 3.0},
            },
        ])

        self.assertEqual(len(compressed), 2)
        leader = next(item for item in compressed if item["code"] == "AAA")
        self.assertEqual(leader["sample_repeat_count"], 2)
        self.assertAlmostEqual(leader["pnl"], 200.0, places=6)
        self.assertAlmostEqual(leader["pnl_pct"], 3.0, places=6)
        self.assertAlmostEqual(leader["factor_scores"]["mf_alpha"], 7.0, places=6)

    def test_factor_tracker_learns_only_from_mf_breakdown_keys(self):
        tracker = FactorImportanceTracker()
        multipliers = tracker.update_from_trades([
            {
                "pnl_pct": 4.0,
                "factor_scores": {
                    "mf_alpha": 9.0,
                    "mf_beta": 6.0,
                    "route_weight": 4.0,
                },
            },
            {
                "pnl_pct": -3.0,
                "factor_scores": {
                    "mf_alpha": 8.0,
                    "mf_beta": 9.0,
                    "adaptive_score": 80.0,
                },
            },
        ])

        self.assertIn("alpha", multipliers)
        self.assertIn("beta", multipliers)
        self.assertNotIn("route_weight", multipliers)
        self.assertGreater(multipliers["alpha"], 1.0)
        self.assertLess(multipliers["beta"], 1.0)

    def test_apply_adaptive_multipliers_rebalances_weights(self):
        scores = [
            FactorScore(name="alpha", score=8.0, weight=0.2, note=""),
            FactorScore(name="beta", score=6.0, weight=0.8, note=""),
        ]

        _apply_adaptive_multipliers(scores, {"alpha": 1.5, "beta": 0.75})

        total = sum(item.weight for item in scores)
        self.assertAlmostEqual(total, 1.0, places=6)
        self.assertGreater(scores[0].weight, 0.2)
        self.assertLess(scores[1].weight, 0.8)


if __name__ == "__main__":
    unittest.main()
