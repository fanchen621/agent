from __future__ import annotations

import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
import sys

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.evolution_mode import EvolutionModeRuntime, _cycle_repair_reasons, _default_profile  # noqa: E402


def _trade(
    code: str,
    pick_type: str,
    pnl: float,
    pnl_pct: float,
    *,
    base_score: float,
    volume_ratio: float,
    turnover_pct: float,
    trend_alignment: float,
    data_confidence: float,
    distance_to_high: float,
    capital_flow: float,
    chip_factor: float = 0.0,
):
    return SimpleNamespace(
        code=code,
        pick_type=pick_type,
        pnl=pnl,
        pnl_pct=pnl_pct,
        zone="attack",
        emotion="warm",
        context={
            "code": code,
            "pick_type": pick_type,
            "base_score": base_score,
            "effective_score": base_score + 1.0,
            "volume_ratio": volume_ratio,
            "turnover_pct": turnover_pct,
            "trend_alignment": trend_alignment,
            "data_confidence": data_confidence,
            "distance_to_high_20d_pct": distance_to_high,
            "breakdown": {
                "capital_flow": capital_flow,
                "chip_factor": chip_factor,
                "adaptive_score": base_score,
                "multi_factor_score": base_score + 4.0,
            },
        },
    )


class EvolutionModeLearningTests(unittest.TestCase):
    def test_cycle_learning_expands_after_repeated_losses(self):
        runtime = EvolutionModeRuntime()
        previous = _default_profile()
        trades = [
            _trade("AAA", "base_pivot_trend", -200, -3.8, base_score=74, volume_ratio=1.4, turnover_pct=1.8, trend_alignment=0.33, data_confidence=0.58, distance_to_high=22, capital_flow=-2.5),
            _trade("AAA", "base_pivot_trend", -180, -3.2, base_score=73, volume_ratio=1.5, turnover_pct=1.9, trend_alignment=0.34, data_confidence=0.57, distance_to_high=23, capital_flow=-2.0),
            _trade("AAA", "base_pivot_trend", -160, -2.9, base_score=72, volume_ratio=1.3, turnover_pct=1.7, trend_alignment=0.32, data_confidence=0.56, distance_to_high=24, capital_flow=-1.8),
            _trade("BBB", "low_position_trend", 120, 2.1, base_score=68, volume_ratio=2.2, turnover_pct=3.6, trend_alignment=0.44, data_confidence=0.72, distance_to_high=12, capital_flow=2.0),
            _trade("CCC", "low_position_trend", 110, 1.8, base_score=69, volume_ratio=2.0, turnover_pct=3.2, trend_alignment=0.42, data_confidence=0.70, distance_to_high=13, capital_flow=1.6),
            _trade("DDD", "low_position_trend", 90, 1.6, base_score=67, volume_ratio=1.9, turnover_pct=3.0, trend_alignment=0.41, data_confidence=0.69, distance_to_high=14, capital_flow=1.2),
        ]

        profile, patterns, analysis, summary = runtime._build_cycle_learning(trades, previous)

        self.assertEqual(summary["state"], "recover")
        self.assertEqual(profile["max_code_repeat"], 1)
        self.assertGreater(profile["exploration_rate"], previous["exploration_rate"])
        self.assertLess(profile["pick_type_bias"]["base_pivot_trend"], 0.0)
        self.assertGreater(profile["pick_type_bias"]["low_position_trend"], 0.0)
        self.assertIn("diversity ratio", analysis)
        self.assertIn("factor bias:", analysis)
        self.assertTrue(patterns)

    def test_rank_candidates_prefers_novel_factor_aligned_names(self):
        runtime = EvolutionModeRuntime()
        profile = _default_profile()
        profile["pick_type_bias"] = {"low_position_trend": 0.6}
        profile["factor_bias"] = {"capital_flow": 1.0}
        profile["exploration_rate"] = 0.55
        ranked = runtime._rank_candidates(
            candidates=[
                {
                    "code": "AAA",
                    "name": "old",
                    "score": 74.0,
                    "pick_type": "low_position_trend",
                    "volume_ratio": 2.0,
                    "turnover_pct": 3.0,
                    "trend_alignment": 0.42,
                    "data_confidence": 0.72,
                    "distance_to_high_20d_pct": 11.0,
                    "breakdown": {"capital_flow": 0.5},
                    "_memory_seen_count": 6,
                },
                {
                    "code": "BBB",
                    "name": "new",
                    "score": 71.0,
                    "pick_type": "low_position_trend",
                    "volume_ratio": 2.3,
                    "turnover_pct": 3.4,
                    "trend_alignment": 0.46,
                    "data_confidence": 0.74,
                    "distance_to_high_20d_pct": 10.0,
                    "breakdown": {"capital_flow": 3.2},
                    "_memory_seen_count": 1,
                },
            ],
            profile=profile,
            zone="attack",
            emotion="warm",
            code_exposure={"AAA": 1},
            pick_type_exposure={"low_position_trend": 1},
        )

        self.assertEqual(ranked[0]["code"], "BBB")
        self.assertGreater(ranked[0]["_effective_score"], ranked[1]["_effective_score"])

    def test_cycle_learning_compresses_repeated_code_samples(self):
        runtime = EvolutionModeRuntime()
        previous = _default_profile()
        trades = [
            _trade("AAA", "base_pivot_trend", -100, -2.0, base_score=73, volume_ratio=1.4, turnover_pct=1.8, trend_alignment=0.31, data_confidence=0.58, distance_to_high=21, capital_flow=-2.0),
            _trade("AAA", "base_pivot_trend", -90, -1.8, base_score=72, volume_ratio=1.5, turnover_pct=1.9, trend_alignment=0.32, data_confidence=0.58, distance_to_high=21, capital_flow=-1.8),
            _trade("AAA", "base_pivot_trend", -80, -1.6, base_score=72, volume_ratio=1.6, turnover_pct=1.9, trend_alignment=0.33, data_confidence=0.59, distance_to_high=22, capital_flow=-1.7),
            _trade("AAA", "base_pivot_trend", -70, -1.5, base_score=71, volume_ratio=1.5, turnover_pct=1.8, trend_alignment=0.32, data_confidence=0.57, distance_to_high=22, capital_flow=-1.6),
            _trade("BBB", "low_position_trend", 120, 2.2, base_score=69, volume_ratio=2.3, turnover_pct=3.4, trend_alignment=0.46, data_confidence=0.73, distance_to_high=10, capital_flow=2.4),
        ]

        profile, _, analysis, summary = runtime._build_cycle_learning(trades, previous)

        self.assertEqual(summary["raw_trades"], 5)
        self.assertEqual(summary["normalized_trades"], 2)
        self.assertGreater(summary["dominant_code_share"], 0.75)
        self.assertEqual(profile["max_code_repeat"], 1)
        self.assertIn("raw trades: 5", analysis)
        self.assertIn("normalized trades: 2", analysis)

    def test_rank_candidates_normalizes_legacy_trend_floor_scale(self):
        runtime = EvolutionModeRuntime()
        profile = _default_profile()
        profile["trend_floor"] = 35.0  # legacy persisted scale

        ranked = runtime._rank_candidates(
            candidates=[
                {
                    "code": "AAA",
                    "name": "steady",
                    "score": 74.0,
                    "pick_type": "low_position_trend",
                    "volume_ratio": 2.0,
                    "turnover_pct": 3.1,
                    "trend_alignment": 0.4,
                    "data_confidence": 0.72,
                    "distance_to_high_20d_pct": 12.0,
                    "breakdown": {},
                    "_memory_seen_count": 1,
                },
                {
                    "code": "BBB",
                    "name": "weak",
                    "score": 74.0,
                    "pick_type": "low_position_trend",
                    "volume_ratio": 2.0,
                    "turnover_pct": 3.1,
                    "trend_alignment": 0.18,
                    "data_confidence": 0.72,
                    "distance_to_high_20d_pct": 12.0,
                    "breakdown": {},
                    "_memory_seen_count": 1,
                },
            ],
            profile=profile,
            zone="attack",
            emotion="warm",
            code_exposure={},
            pick_type_exposure={},
        )

        self.assertEqual(ranked[0]["code"], "AAA")
        self.assertFalse(any("trend<35%" in note for note in ranked[0]["_bias_notes"]))
        self.assertTrue(any("trend<35%" in note for note in ranked[1]["_bias_notes"]))

    def test_cycle_repair_reasons_detects_dirty_legacy_cycle(self):
        cycle = SimpleNamespace(
            buy_count=326,
            sell_count=326,
            open_positions=0,
            status="sell_day",
            end_date=None,
            analysis="",
        )

        reasons = _cycle_repair_reasons(
            cycle,
            actual_buy_count=40,
            actual_sell_count=38,
            actual_open_positions=0,
            archived=False,
        )

        self.assertIn("buy_count_mismatch", reasons)
        self.assertIn("sell_count_mismatch", reasons)
        self.assertIn("needs_finalize", reasons)
        self.assertIn("missing_archive", reasons)
        self.assertIn("missing_analysis", reasons)

    def test_run_startup_maintenance_is_idempotent_after_first_run(self):
        runtime = EvolutionModeRuntime()
        expected = {"repaired": 1}

        with patch.object(runtime, "_repair_legacy_cycles", return_value=expected) as mock_repair:
            first = runtime.run_startup_maintenance(today=None)
            second = runtime.run_startup_maintenance(today=None)

        self.assertEqual(first, expected)
        self.assertEqual(second, expected)
        self.assertEqual(mock_repair.call_count, 1)


if __name__ == "__main__":
    unittest.main()
