from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
import sys

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.realtime_watch import RealtimeWatchEngine  # noqa: E402


class RealtimeWatchTests(unittest.TestCase):
    def test_rank_exploration_picks_lowers_floor_when_primary_empty(self):
        engine = RealtimeWatchEngine(candidate_limit=4, exploration_limit=6)

        with patch("engine.realtime_watch.rank_candidates") as mock_rank:
            recovered = [object()]
            mock_rank.side_effect = [[], recovered]

            picks, floor = engine._rank_exploration_picks(
                candidates=[object()],
                zone="attack",
                emotion="neutral",
                sentiment_modifier=1.0,
            )

        self.assertEqual(picks, recovered)
        self.assertEqual(mock_rank.call_count, 2)
        self.assertGreater(
            mock_rank.call_args_list[0].kwargs["score_floor_override"],
            mock_rank.call_args_list[1].kwargs["score_floor_override"],
        )
        self.assertTrue(mock_rank.call_args_list[0].kwargs["quiet"])

    def test_effective_limits_shrink_after_slow_refresh(self):
        engine = RealtimeWatchEngine(feature_limit=70, advanced_limit=18)
        engine._refresh_latency_ms = 98000.0
        engine._slow_refresh_streak = 2

        self.assertLess(engine._effective_feature_limit(), 70)
        self.assertLess(engine._effective_advanced_limit(), 18)


if __name__ == "__main__":
    unittest.main()
