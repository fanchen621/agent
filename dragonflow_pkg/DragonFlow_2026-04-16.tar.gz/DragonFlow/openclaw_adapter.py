"""
OpenClaw 适配层
═══════════════════════════════════════════════════════════════════════════
所有与 OpenClaw 平台交互的调用（消息推送、Webview、日志、数据目录）
统一封装，上层业务代码零感知差异。

运行模式：
  - OpenClaw 环境 → 调用真实 OpenClaw API
  - 独立环境（开发/测试） → Rich 终端输出 + 文件日志
"""
from __future__ import annotations

import os
import sys
import json
import socket
import asyncio
import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from loguru import logger
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel

# ─── 运行时检测 ──────────────────────────────────────────────────────────────
_IN_OPENCLAW = os.environ.get("OPENCLAW_SKILL_ID") is not None
_SKILL_ROOT = Path(__file__).parent
_DATA_DIR = _SKILL_ROOT / "data"
_router = None
_router_probe_attempted = False

# ─── 数据源路由层初始化（启动时探活）─────────────────────────────────────────────
_REPORT_DIR = _DATA_DIR / "reports"
_LOG_DIR = _DATA_DIR / "logs"

for _d in (_DATA_DIR, _REPORT_DIR, _LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

_console = Console()

# ─── WebSocket 广播注册 ────────────────────────────────────────────────────
_ws_broadcast: Optional[Callable] = None


def ensure_router_ready(force: bool = False) -> bool:
    global _router, _router_probe_attempted
    if _router_probe_attempted and not force:
        return _router is not None

    _router_probe_attempted = True
    try:
        from feeds.data_router import get_router

        _router = get_router()
        _router.probe_all()
        logger.info("[router] 启动探活完成")
        return True
    except Exception as e:
        _router = None
        logger.debug(f"[router] lazy init failed: {e}")
        return False


def register_ws_broadcast(fn: Callable):
    global _ws_broadcast
    _ws_broadcast = fn


# ════════════════════════════════════════════════════════════════════════════
# 日志系统
# ════════════════════════════════════════════════════════════════════════════

def _setup_logging():
    log_file = _LOG_DIR / "dragonflow_{time:YYYY-MM-DD}.log"
    logger.remove()

    logger.add(sys.stderr, level="INFO",
               format="<green>{time:HH:mm:ss}</green> | "
                      "<level>{level: <8}</level> | "
                      "<cyan>{name}</cyan> - <level>{message}</level>",
               colorize=True)

    logger.add(str(log_file), level="DEBUG",
               rotation="1 day", retention="30 days", encoding="utf-8",
               format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name} | {message}")

    if _IN_OPENCLAW:
        oc_log_endpoint = os.environ.get("OPENCLAW_LOG_ENDPOINT")
        if oc_log_endpoint:
            logger.add(_openclaw_log_sink, level="INFO", serialize=False)

    logger.info(f"[DragonFlow] 日志已初始化 | 目录: {_LOG_DIR}")


def _openclaw_log_sink(message):
    try:
        record = message.record
        payload = {
            "level": record["level"].name,
            "time": record["time"].isoformat(),
            "name": record["name"],
            "message": record["message"],
        }
        endpoint = os.environ.get("OPENCLAW_LOG_ENDPOINT", "")
        if endpoint and endpoint.startswith("http"):
            import requests
            requests.post(endpoint, json=payload, timeout=2)
    except Exception:
        pass


_setup_logging()


# ════════════════════════════════════════════════════════════════════════════
# 三分身量化协同
# ════════════════════════════════════════════════════════════════════════════
def _get_tripartite_analysis(event_type, code="", name="", price=0, pct=0, score=0, reason=""):
    """触发三分身协同分析，返回格式化的三人意见"""
    try:
        import subprocess
        result = subprocess.run(
            ["python3",
             "/root/.openclaw/skills/quant-tripartite/tripartite_alert.py",
             event_type, code, name, str(price), str(pct), str(score), reason],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            return result.stdout
        return ""
    except Exception:
        return ""


# ─── DragonFlow signal hook ───────────────────────────────────────────────
_TRIPARTITE_ROUTER_HOOK_SET = False


def enable_tripartite_hook():
    global _TRIPARTITE_ROUTER_HOOK_SET
    _TRIPARTITE_ROUTER_HOOK_SET = True


def _tripartite_broadcast_wrapper(json_str: str):
    """DragonFlow _emit 回调：解析并触发三分身分析"""
    global _TRIPARTITE_ROUTER_HOOK_SET
    if not _TRIPARTITE_ROUTER_HOOK_SET:
        return  # 还没注入，跳过
    try:
        import sys as _sys, json as _json
        # 确保 quant_tripartite 可导入（支持 quant-tripartite 和 quant_tripartite 两种命名）
        for _p in ("/root/.openclaw/skills", "/root/.openclaw/skills/quant-tripartite"):
            if _p not in _sys.path:
                _sys.path.insert(0, _p)
        from quant_tripartite.tripartite_signal_router import dragonflow_signal_hook
        msg = _json.loads(json_str)
        event = msg.get("event", "")
        data = msg.get("data", {})
        if event == "trade_signal":
            result = dragonflow_signal_hook(data)
            if result:
                # 打印三分身报告到日志
                from quant_tripartite.tripartite_signal_router import format_tripartite_report
                logger.info("\n" + format_tripartite_report(result))
        elif event == "market_tick":
            from quant_tripartite.tripartite_signal_router import dragonflow_tick_hook
            dragonflow_tick_hook(data)
    except Exception as exc:
        logger.warning(f"[_tripartite] hook error: {exc}")


def push_message(content: str, msg_type: str = "markdown",
                 title: str = "", urgent: bool = False) -> bool:
    if _IN_OPENCLAW:
        return _push_openclaw(content, msg_type, title, urgent)
    return _push_terminal(content, title, urgent)


def _push_openclaw(content: str, msg_type: str,
                   title: str, urgent: bool) -> bool:
    try:
        endpoint = os.environ.get("OPENCLAW_MSG_ENDPOINT", "")
        if not endpoint:
            return _push_terminal(content, title, urgent)
        import requests
        resp = requests.post(endpoint, json={
            "type": msg_type,
            "title": title or "DragonFlow",
            "content": content,
            "urgent": urgent,
            "skill_id": os.environ.get("OPENCLAW_SKILL_ID", "dragonflow"),
            "timestamp": datetime.datetime.now().isoformat(),
        }, timeout=5)
        return resp.status_code == 200
    except Exception as e:
        logger.warning(f"[推送] OpenClaw推送失败: {e}，降级到终端")
        return _push_terminal(content, title, urgent)


def _push_terminal(content: str, title: str, urgent: bool) -> bool:
    border = "red bold" if urgent else "cyan"
    header = title or "DragonFlow"
    try:
        _console.print(Panel(Markdown(content), title=header, border_style=border))
    except Exception:
        print(f"\n{'='*60}\n{header}\n{content}\n{'='*60}")
    return True


async def push_message_async(content: str, msg_type: str = "markdown",
                              title: str = "", urgent: bool = False):
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, push_message, content, msg_type, title, urgent)


def push_alert_message(event_type: str, code: str = "", name: str = "",
                      price: float = 0, pct: float = 0, score: float = 0,
                      reason: str = "", content: str = "",
                      msg_type: str = "markdown", title: str = "",
                      urgent: bool = False) -> bool:
    """推送带三分身协同分析的告警消息（走真实路由）"""
    # 构建标准信号格式
    signal_dict = {
        "code": code,
        "name": name,
        "direction": "BUY" if "BUY" in event_type else ("SELL" if "SELL" in event_type else "UNKNOWN"),
        "price": price,
        "pct": pct,
        "signal_reason": reason,
        "zone": "unknown",
        "emotion": "unknown",
        "score": score,
        "runtime_rules": {},
    }
    tripartite = ""
    try:
        import sys as _sys
        for _p in ("/root/.openclaw/skills", "/root/.openclaw/skills/quant-tripartite"):
            if _p not in _sys.path:
                _sys.path.insert(0, _p)
        from quant_tripartite.tripartite_signal_router import dragonflow_signal_hook, format_tripartite_report
        result = dragonflow_signal_hook(signal_dict)
        if result:
            tripartite = format_tripartite_report(result)
    except Exception as exc:
        logger.warning(f"[push_alert] router error: {exc}")
        tripartite = _get_tripartite_analysis(event_type, code, name, price, pct, score, reason)
    full_content = tripartite
    if content:
        full_content += "\n\n" + content
    return push_message(full_content, msg_type, title or event_type, urgent)


# ════════════════════════════════════════════════════════════════════════════
# 三分身市场评估（供午盘/收盘报告调用）
# ════════════════════════════════════════════════════════════════════════════
def get_tripartite_market_report(zone: str = "neutral", emotion: str = "neutral",
                                score: float = 50, zone_notes: list = None,
                                indices: list = None, positions: list = None,
                                candidates: list = None) -> str:
    """生成三分身市场评估报告，嵌入午盘/收盘报告"""
    zone_notes = zone_notes or []
    indices = indices or []

    # ── 吴帅·市场决策 ──
    if zone in ("super_attack", "attack"):
        wushuai = "「市场强势，攻击区间。吴帅下令：持仓不动，积极寻找买入机会。」"
    elif zone == "range":
        wushuai = "「市场震荡，吴帅判断：轻仓观察，等待趋势明朗。」"
    elif zone == "risk":
        wushuai = "「市场风险区间。吴帅警告：禁止开新仓，持仓准备止损。」"
    else:
        wushuai = "「市场方向不明。吴帅指令：静观其变，不盲目出击。」"

    # ── 柳贯一·执行检查 ──
    checks = []
    if zone in ("super_attack", "attack"):
        checks.append("区间状态：攻击区间，执行优先")
    elif zone == "risk":
        checks.append("区间状态：风险区间，禁止开仓")
    if emotion in ("高潮", "沸腾"):
        checks.append("情绪周期：高潮/沸腾，谨慎追高")
    elif emotion in ("冰点",):
        checks.append("情绪周期：冰点区，关注超跌反弹")
    if positions:
        holding_codes = [p.code for p in positions]
        checks.append(f"持仓状态：{len(positions)}只个股持仓中 {holding_codes}")
    else:
        checks.append("持仓状态：空仓")
    if candidates:
        top3 = [f"{c.get('code','')}{c.get('name','')}{c.get('pct',0)}%" for c in candidates[:3]]
        checks.append(f"候选股：{len(candidates)}只 TOP3:{top3}")
    else:
        checks.append("候选股：暂无")
    liuguanyi = "柳贯一执行检查：\n" + "\n".join(["• " + c for c in checks])

    # ── 房睇长·策略评估 ──
    if zone in ("super_attack", "attack"):
        fang_prob = "75%"
        fang_advice = "积极寻找量价齐升的突破标的，仓位可提升至50%。"
    elif zone == "range":
        fang_prob = "45%"
        fang_advice = "区间震荡，高抛低吸。优先选择防御性板块。"
    else:
        fang_prob = "25%"
        fang_advice = "市场方向不明，耐心等待。保存实力，等待明确信号。"
    if emotion in ("高潮", "沸腾"):
        fang_advice += " 情绪偏热，注意回调风险。"
    elif emotion in ("冰点",):
        fang_advice += " 情绪冰点，超跌板块可能率先反弹。"
    fangtichang = ("房睇长策略评估：\n"
                  "- 市场方向概率：" + fang_prob + "\n"
                  "- 情绪状态：" + emotion + "\n"
                  "- 建议：" + fang_advice)

    divider = "─" * 40
    return (f"\n{divider}\n"
            f"🐉 吴帅（市场决策）\n   {wushuai}\n\n"
            f"⚔️ 柳贯一（执行检查）\n   {liuguanyi}\n\n"
            f"🧠 房睇长（策略评估）\n   {fangtichang}\n"
            f"{divider}")


# ════════════════════════════════════════════════════════════════════════════
# WebView 控制
# ════════════════════════════════════════════════════════════════════════════

def open_webview(url: str, title: str = "DragonFlow Dashboard",
                 width: int = 1200, height: int = 800) -> bool:
    if _IN_OPENCLAW:
        try:
            endpoint = os.environ.get("OPENCLAW_WEBVIEW_ENDPOINT", "")
            if endpoint:
                import requests
                resp = requests.post(endpoint, json={
                    "url": url, "title": title, "width": width, "height": height,
                }, timeout=5)
                return resp.status_code == 200
        except Exception as e:
            logger.error(f"[Webview] 打开失败: {e}")
            return False
    _console.print(Panel(
        f"[bold cyan]Dashboard URL:[/bold cyan]\n\n  [link={url}]{url}[/link]",
        title=f"  {title}", border_style="green"))
    return True


# ════════════════════════════════════════════════════════════════════════════
# 路径 & 目录
# ════════════════════════════════════════════════════════════════════════════

def get_data_dir() -> Path:
    if _IN_OPENCLAW:
        oc_data = os.environ.get("OPENCLAW_DATA_DIR")
        if oc_data:
            p = Path(oc_data)
            p.mkdir(parents=True, exist_ok=True)
            return p
    return _DATA_DIR


def get_reports_dir() -> Path:
    d = get_data_dir() / "reports"
    d.mkdir(exist_ok=True)
    return d


def get_skill_root() -> Path:
    return _SKILL_ROOT


def get_templates_dir() -> Path:
    return _SKILL_ROOT / "api" / "templates"


# ════════════════════════════════════════════════════════════════════════════
# 端口管理
# ════════════════════════════════════════════════════════════════════════════

_ACTIVE_PORT: Optional[int] = None


def find_available_port(start: int = 8888, end: int = 8999) -> int:
    global _ACTIVE_PORT
    if _ACTIVE_PORT and _is_port_free(_ACTIVE_PORT):
        return _ACTIVE_PORT
    for port in range(start, end + 1):
        if _is_port_free(port):
            _ACTIVE_PORT = port
            logger.info(f"[端口] 自动选定: {port}")
            return port
    raise RuntimeError(f"端口 {start}-{end} 全部被占用")


def _is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def get_dashboard_url() -> str:
    return f"http://127.0.0.1:{_ACTIVE_PORT or 8888}"


def set_active_port(port: int):
    global _ACTIVE_PORT
    _ACTIVE_PORT = port


# ════════════════════════════════════════════════════════════════════════════
# Dashboard 广播（WebSocket）
# ════════════════════════════════════════════════════════════════════════════

async def broadcast_to_dashboard(event: str, data: Any):
    if _ws_broadcast is not None:
        try:
            payload = {"event": event, "data": data,
                       "ts": datetime.datetime.now().isoformat()}
            await _ws_broadcast(json.dumps(payload, ensure_ascii=False, default=str))
        except Exception as e:
            logger.warning(f"[WS广播] {event} 失败: {e}")


# ════════════════════════════════════════════════════════════════════════════
# 交易日判断
# ════════════════════════════════════════════════════════════════════════════

def is_trading_day(date: Optional[datetime.date] = None) -> bool:
    if date is None:
        date = datetime.date.today()
    try:
        import chinese_calendar as cc
        return cc.is_workday(date) and not cc.is_holiday(date)
    except ImportError:
        return date.weekday() < 5


def is_trading_hours(now: Optional[datetime.datetime] = None) -> bool:
    if now is None:
        now = datetime.datetime.now()
    t = now.time()
    return ((datetime.time(9, 30) <= t <= datetime.time(11, 30))
            or (datetime.time(13, 0) <= t <= datetime.time(15, 0)))


def is_pre_market(now: Optional[datetime.datetime] = None) -> bool:
    """竞价时段 9:15-9:30"""
    if now is None:
        now = datetime.datetime.now()
    t = now.time()
    return datetime.time(9, 15) <= t <= datetime.time(9, 30)


def next_trading_day(from_date: Optional[datetime.date] = None) -> datetime.date:
    if from_date is None:
        from_date = datetime.date.today()
    d = from_date + datetime.timedelta(days=1)
    while not is_trading_day(d):
        d += datetime.timedelta(days=1)
    return d


def get_next_schedule_info() -> dict:
    now = datetime.datetime.now()
    today = now.date()
    schedules = [
        ("早盘速递", datetime.time(8, 50)),
        ("午盘分析", datetime.time(11, 35)),
        ("收盘报告", datetime.time(15, 35)),
    ]
    for name, t in schedules:
        scheduled = datetime.datetime.combine(today, t)
        if scheduled > now and is_trading_day(today):
            return {"name": name, "time": scheduled.strftime("%H:%M"),
                    "date": today.isoformat()}
    nxt = next_trading_day(today)
    return {"name": "早盘速递", "time": "08:50", "date": nxt.isoformat()}


# ════════════════════════════════════════════════════════════════════════════
# 系统状态
# ════════════════════════════════════════════════════════════════════════════

_SYSTEM_STATE: dict = {
    "started_at": None,
    "scheduler_running": False,
    "autopilot_running": False,
    "web_running": False,
    "last_morning": None,
    "last_midday": None,
    "last_closing": None,
    "current_zone": "unknown",
    "current_emotion": "unknown",
    "db_size_mb": 0.0,
}


def update_state(**kwargs):
    _SYSTEM_STATE.update(kwargs)


def get_state() -> dict:
    db_path = get_data_dir() / "dragonflow.db"
    if db_path.exists():
        _SYSTEM_STATE["db_size_mb"] = round(db_path.stat().st_size / 1024 / 1024, 2)
    return dict(_SYSTEM_STATE)


def format_status_message() -> str:
    s = get_state()
    nxt = get_next_schedule_info()
    td = "Y" if is_trading_day() else "N"
    th = "交易中" if is_trading_hours() else "休市"
    url = get_dashboard_url()
    zone_emoji = {"super_attack": "S", "attack": "A",
                  "range": "R", "risk": "X"}.get(s["current_zone"], "?")

    return f"""## DragonFlow 系统状态

| 项目 | 状态 |
|------|------|
| 调度器 | {"运行中" if s['scheduler_running'] else "未启动"} |
| AutoPilot | {"运行中" if s['autopilot_running'] else "未启动"} |
| Web | {"运行 " + url if s['web_running'] else "未启动"} |
| 交易日 | {td} | 时段 | {th} |
| 市场区间 | [{zone_emoji}] {s['current_zone']} |
| 情绪周期 | {s['current_emotion']} |
| 数据库 | {s['db_size_mb']} MB |

**最近执行**: 早盘{s.get('last_morning') or '-'} / 午盘{s.get('last_midday') or '-'} / 收盘{s.get('last_closing') or '-'}
**下次任务**: {nxt['date']} {nxt['time']} {nxt['name']}
**Dashboard**: {url}
"""


# ══════════════════════════════════════════════════════════════════════════════
# 快速候选股扫描器（绕过SOCKS5慢代理，直接抓取东财）
# ══════════════════════════════════════════════════════════════════════════════
def quick_scan_candidates(min_pct: float = 3.0, max_pct: float = 9.5, limit: int = 8) -> List[Dict]:
    """
    直接从东财获取强势股候选，不走SOCKS5代理。
    返回: [{"code": "600519", "name": "贵州茅台", "pct": 5.2, "score": 78.5, ...}]
    """
    import urllib.request, json as _json
    from models import get_session, MarketSnapshot, Position
    from datetime import datetime, date

    ALLOWED = ("600", "601", "603", "000", "001", "002")

    # 1. 获取指数判断zone - 用curl确保可访问
    try:
        import subprocess as _subprocess, shlex as _shlex
        idx_url = "https://push2.eastmoney.com/api/qt/ulist.np/get?fields=f2,f3,f12&secids=1.000001,0.399006"
        idx_curl = f"curl -s --max-time 6 -A 'Mozilla/5.0' -H 'Referer: https://quote.eastmoney.com' '{idx_url}'"
        idx_raw = _subprocess.check_output(idx_curl, shell=True, stderr=_subprocess.DEVNULL)
        import json as _json
        idx_data = _json.loads(idx_raw.decode("utf-8", errors="ignore"))
        indices = {item["f12"]: item for item in idx_data.get("data", {}).get("diff", [])}
        cy_pct = float(indices.get("399006", {}).get("f3", 0)) / 100
    except Exception:
        cy_pct = 0.5

    zone = "attack" if cy_pct >= 3 else "buildup" if cy_pct >= 1.5 else "neutral" if cy_pct >= 0 else "caution"

    # 2. 获取涨幅3-9.5%的股票 - 新浪API（东财直连被阻，改用新浪）
    try:
        import subprocess as _subprocess
        # 新浪涨幅榜：沪深A股按涨跌幅降序
        url = (
            "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php"
            "/Market_Center.getHQNodeData?node=hs_a&num=80&sort=changepercent"
            "&asc=0&page=1")
        curl_cmd = [
            "curl", "-s", "--max-time", "8",
            "-H", "Referer: https://finance.sina.com.cn/",
            url
        ]
        raw = _subprocess.check_output(curl_cmd, stderr=_subprocess.DEVNULL)
        items = _json.loads(raw.decode("utf-8", errors="ignore")) or []
    except Exception as e:
        logger.warning(f"[quick_scan] 新浪涨幅榜获取失败: {e}")
        return []

    # 3. 排除持仓
    session = get_session()
    positions = session.query(Position).all()
    pos_codes = {p.code for p in positions}
    session.close()

    # 4. 过滤：沪深主板 + 非涨停 + 涨幅门槛 + 排除持仓
    candidates = []
    for item in items:
        # 新浪字段: code="sz301696", changepercent, volume, trade(现价), name
        raw_code = str(item.get("code", "")).strip()
        # 去掉前缀得到纯代码
        if raw_code.startswith(("sh", "sz", "bj", "bj")):
            code = raw_code[2:]
        else:
            code = raw_code
        code = code.zfill(6)
        prefix = code[:3]
        if prefix not in ALLOWED:
            continue
        if code in pos_codes:
            continue
        raw_change = float(item.get("changepercent", 0) or 0)
        if raw_change < min_pct:
            continue
        if raw_change >= max_pct:
            continue  # 排除涨停

        # 换手率从成交量估算
        volume = float(item.get("volume", 0) or 0)
        amount = float(item.get("amount", 0) or 0)
        close = float(item.get("trade", 0) or 0)
        turnover = (amount / close / 100000000 * 100) if close > 0 else 0  # 估算换手率%
        name = item.get("name", code)
        score = min(raw_change * 8 + min(turnover / 10000, 10) * 1.2, 99)
        candidates.append({
            "code": code, "name": name,
            "pct": round(raw_change, 2), "score": round(score, 1),
            "close": round(close, 2),
            "turnover": round(turnover, 2),
            "reason": f"强势股 涨幅{raw_change:.1f}%"
        })

    candidates.sort(key=lambda x: x["score"], reverse=True)
    top = candidates[:limit]

    # 5. 生成TradePlan写入DB（供autopilot._check_buys使用）
    _write_candidate_plans(top, zone)

    logger.info(f"[quick_scan] zone={zone} 扫描完成: {len(top)} 只候选")
    return top


def _write_candidate_plans(candidates: List[Dict], zone: str):
    """将候选股写入MarketSnapshot供autopilot读取"""
    from models import get_session, MarketSnapshot
    from strategy.signal import TradePlan
    from datetime import datetime, date

    session = get_session()
    try:
        # 生成TradePlan对象（autopilot期望的类型）
        plans = []
        for c in candidates:
            plan = TradePlan(
                code=c['code'],
                name=c['name'],
                sector=c.get('sector', ''),
                zone=zone,
                emotion='neutral',
                target_position_pct=10.0,
                entry_price=c.get('close', 0) or 0,
                add_price=0,
                stop_price=0,
                tp1_price=0,
                tp2_price=0,
                hold_days_max=3,
                pick_type='quick_scan',
                score=float(c.get('score', 0)),
                reasons=[c.get('reason', '')],
                source='quick_scan',
            )
            plans.append(plan)

        snap_data = {
            "ts": datetime.now().isoformat(),
            "zone": zone, "emotion": "neutral",
            "candidate_count": len(candidates),
            "universe_size": len(candidates) * 5,
            "watchlist_size": 0, "position_size": 0,
            "candidates": candidates,
            "plans": [{'code': p.code, 'name': p.name, 'sector': p.sector, 'zone': p.zone, 'emotion': p.emotion, 'target_position_pct': p.target_position_pct, 'entry_price': p.entry_price, 'add_price': p.add_price, 'stop_price': p.stop_price, 'tp1_price': p.tp1_price, 'tp2_price': p.tp2_price, 'hold_days_max': p.hold_days_max, 'pick_type': p.pick_type, 'score': p.score, 'reasons': list(p.reasons), 'source': p.source} for p in plans],
            "plan_count": len(plans),
            "latency_ms": 0,
        }
        snap = MarketSnapshot(
            snapshot_type="realtime_watch",
            timestamp=datetime.now(),
            date=date.today(),
            zone=zone, emotion="neutral",
            data=snap_data,
        )
        session.add(snap)
        session.commit()
    finally:
        session.close()
